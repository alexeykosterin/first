----������ �� ������ � ���������, ��� ��� ��� �� �������

declare
v_cnt number(10,5);
v_cnt2 number(10);
v_cnt3 number(10);
begin
  for rec10 in (select distinct pack_id from aak_all_1) loop
  for rec1 in (select * from time_classes where rtpl_rtpl_id = 228) loop
  for rec2 in (select distinct * from aak_all_1 join rate_plan_directions on name_r like name_loc and pack_pack_id = rec10.pack_id 
    and pack_id = rec10.pack_id and zone_id = 1) loop
  for rec3 in (select * from logic_calls where lcal_id in (5,6)) loop
  for rec4 in (select * from serv_lists where srls_id in (104,105)) loop
    if rec4.srls_id = 104 then
      select rec2.price_avt into v_cnt from dual;
    end if;
    if rec4.srls_id = 105 then
      select rec2.price_zak into v_cnt from dual;
    end if;
with t as (
select 
rec1.tmcl_id as tmcl_tmcl_id, 1 as number_history, v_cnt as price_$, 2 as pphm_pphm_id, rec2.rpdr_id as rpdr_rpdr_id, 
1 as cur_cur_id, 1 as xtyp_xtyp_id, rec3.lcal_id as lcal_lcal_id, 
0 as connection_$, 'Y' as enable_faf, rec4.srls_id as srls_srls_id, 0 as cou_cou_id, 0 as pack_pack_id, 0 as rtpl_rtpl_id
from dual)
select count(1) into v_cnt3 from t
where not exists (select * from trafics_by_directions dd where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = rec10.pack_id)
and t.rpdr_rpdr_id = dd.rpdr_rpdr_id
and t.tmcl_tmcl_id = dd.tmcl_tmcl_id
and t.price_$ = dd.price_$
and t.lcal_lcal_id = dd.lcal_lcal_id
and t.srls_srls_id = dd.srls_srls_id
and t.pack_pack_id = dd.pack_pack_id
and t.number_history = dd.number_history
and t.pphm_pphm_id = dd.pphm_pphm_id
and t.xtyp_xtyp_id = dd.xtyp_xtyp_id
and t.connection_$ = dd.connection_$
and t.enable_faf = dd.enable_faf
and t.cou_cou_id = dd.cou_cou_id
and t.rtpl_rtpl_id = dd.rtpl_rtpl_id
and t.cur_cur_id = dd.cur_cur_id
)
;
if v_cnt3 = 0 then
dbms_output.put_line(rec10.pack_id||' '||rec2.rpdr_id||' ������ ��� ����������');
else
insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select 
rec1.tmcl_id, 1, v_cnt, 2, null, rec2.rpdr_id, null, to_date('01.01.2010','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 1, 1, rec3.lcal_id, 
0, 'Y', null, null, rec4.srls_id, 0, null, null, null, null, null, 0, null, 
null, null, null, null, null, 0
from dual;
end if;
  end loop;
  end loop;
  end loop;
  end loop;
  end loop;
end;


select * from trafics_by_directions where navi_date = trunc(sysdate)

---�������� ������
select * from trafics_by_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by tmcl_tmcl_id, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, end_date, function_name, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, 
add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id) as min_rw
from trafics_by_directions
) where rw <> min_rw)

delete from trafics_by_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by tmcl_tmcl_id, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, 
add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id) as min_rw
from trafics_by_directions
) where rw <> min_rw)





create table aak_480 (name_loc varchar2(200),zone_id number(10), price_avt number(10,5), price_zak number(10,5))

create table aak_277 (name_loc varchar2(200),zone_id number(10), price_avt number(10,5), price_zak number(10,5))
select * from aak_277 for update
truncate table aak_277
select * from aak_480
for update
truncate table aak_305
drop table aak_277_1

create table aak_277_1 as
select distinct 305 as pack_id, 
(case when name_loc like '%���%' and name_loc not like '%�����%' then regexp_replace(regexp_replace(name_loc, ('[+,-]*'), ''),'8_��� �� |32_��� �� |32_8_��� �� |32_��� �� |8_��� �� |9_��� �� |9_��� �� |��� �� ','')
when name_loc like '%�����%' then regexp_replace(regexp_replace(name_loc, ('[+.,()-]*'), ''),'8_��� �� |32_��� �� |32_8_��� �� |32_��� �� |8_��� �� |9_��� �� |9_��� �� |��� �� |�����|�������','')||'DEF'
end) as name_loc
, price_avt, price_zak from aak_277


select * from rate_plan_directions where pack_pack_id = 480


select distinct * from aak_277_1
join rate_plan_directions on name_r like name_loc
and pack_pack_id = 480
--31839


select * from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 277)
and rpdr_rpdr_id = 40798

delete from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 277)


declare
v_cnt number(10,5);
begin
  for rec1 in (select * from time_classes where rtpl_rtpl_id = 228) loop
  for rec2 in (select distinct * from aak_277_1 join rate_plan_directions on name_r like name_loc and pack_pack_id = 277) loop
  for rec3 in (select * from logic_calls where lcal_id in (5,6)) loop
  for rec4 in (select * from serv_lists where srls_id in (104,105)) loop
    if rec4.srls_id = 104 then
      select rec2.price_avt into v_cnt from dual;
    end if;
    if rec4.srls_id = 105 then
      select rec2.price_zak into v_cnt from dual;
    end if;
    insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select 
rec1.tmcl_id, 1, v_cnt, 2, null, rec2.rpdr_id, null, to_date('01.01.2015','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 1, 1, rec3.lcal_id, 
0, 'Y', null, null, rec4.srls_id, 0, null, null, null, null, null, 0, null, 
null, null, null, null, null, 0
from dual;
  end loop;
  end loop;
  end loop;
  end loop;
end;


select * from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 504) 
select distinct * from aak_498_1 join rate_plan_directions on name_r like name_loc and pack_pack_id = 498


select * from subs_packs where subs_subs_id = 143499
select * from pstn_calls_00_082018
where subs_subs_id = 145523
select * from rate_plan_directions where pack_pack_id = 498;
select * from rate_plan_directions where pack_pack_id = 504;
504=498


begin
  for rec in (select * from rate_plan_directions where pack_pack_id = 498) loop
insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select rpdr_seq.nextval, 0, 0, rec.name_e, rec.name_r, rec.name_1, rec.name_2, 'AAK', trunc(sysdate), 1, 504, null
from dual;
end loop;
end;

select * from pset_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 498)
select * from pset_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 504)


begin
  for rec in (select * from pset_directions
join aak_rp on rpdr_rpdr_id = RPDR1 where drct_drct_id is null) loop
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    select
    psdr_seq.nextval, 1, rec.pset_pset_id, rec.rpdr2, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
    from dual;
  end loop;
end;


select * from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 498)

create table aak_498 as select * from aak_480 
where 1=2


select * from aak_498 for update


--92548
select  psdr_seq.nextval from dual
select max(psdr_id) from pset_directions

select * from pset_directions where rpdr_rpdr_id in (select rpdr_rpdr_id from pset_directions
join aak_rp on rpdr_rpdr_id = RPDR2)


create table aak_rp as
select r.rpdr_id RPDR1, rr.rpdr_id RPDR2  from rate_plan_directions r
left join rate_plan_directions rr on r.name_r like rr.name_r
where r.pack_pack_id = 498
and rr.pack_pack_id = 504

select * from aak_rp

select * from pset_directions
join aak_rp on rpdr_rpdr_id = RPDR1



select * from pstn_calls_00_082018
where file_name like '%MN%'
and subs_subs_id = 145523


delete from pstn_calls_00_082018
where file_name like '%MN%'


select * from pset_directions
where pset_pset_id = 42414
for update
  
insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
select psdr_seq.nextval, 1, 42414, 40629, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
from dual

33695
40629

select * from rate_plan_directions where rpdr_id = 31257
select * from rate_plan_directions where pack_pack_id in (498,504)

select distinct name_loc from aak_498
select distinct name_loc from aak_498_1


select * from cou_drct


select distinct cou_id from aak_498_1
join cou_drct on name_r like name_loc



---1877
select * from prefix_sets where cou_cou_id in (select distinct cou_id from aak_498_1
join cou_drct on name_r like name_loc)


select * from prefix_sets where cou_cou_id = 7

select * from countries
---1923
select distinct * from pset_directions where pset_pset_id in (select pset_id from prefix_sets where cou_cou_id in (select distinct cou_id from aak_498_1
join cou_drct on name_r like name_loc)
)
and rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 498)


select * from rate_plan_directions where pack_pack_id = 498

--1944
select distinct * from pset_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 498)



select * from aak_498_1
join directions on name_r = name_loc



---1763
--110
create table aak_not_in as
select * from pset_directions where pset_pset_id in (
select pset_id from prefix_sets where drct_drct_id in (select drct_id from aak_498_1
join directions on name_r = name_loc))
and rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 498)

select * from prefix_sets where cou_cou_id in (select distinct cou_id from aak_498_1
join cou_drct on name_r like name_loc)



select * from prefix_sets where drct_drct_id in (select drct_id from aak_498_1
join directions on name_r = name_loc)
and pset_id not in (select pset_pset_id from aak_not_in)

create table aak_pset1 as
select * from aak_498_1
join directions on name_r = name_loc

create table aak_pset2 as
select drct_drct_id, name_loc, pset_id, price_avt, price_zak  from prefix_sets 
join aak_pset1 on drct_id = drct_drct_id
where drct_drct_id in (select drct_id from aak_498_1
join directions on name_r = name_loc)
and pset_id not in (select pset_pset_id from aak_not_in)

select * from aak_498_1
---------------
select * From aak_pset2
join rate_plan_directions on name_loc like name_r
where pack_pack_id = 498
---------------
create table aak_pset3 as
select drct_drct_id, name_loc, pset_id, price_avt, price_zak  from prefix_sets 
join aak_pset1 on drct_id = drct_drct_id
where drct_drct_id in (select drct_id from aak_480_1
join directions on name_r = name_loc)
and pset_id not in (select pset_pset_id from aak_not_in)

select * From aak_pset3
join rate_plan_directions on name_loc like name_r
where pack_pack_id = 480
---------------


declare
v_cnt number(10,5);
begin
  for rec1 in (select * from time_classes where rtpl_rtpl_id = 228) loop
  for rec2 in (select * From aak_pset3
join rate_plan_directions on name_loc like name_r
where pack_pack_id = 479) loop
  for rec3 in (select * from logic_calls where lcal_id in (5,6)) loop
  for rec4 in (select * from serv_lists where srls_id in (104,105)) loop
    if rec4.srls_id = 104 then
      select rec2.price_avt into v_cnt from dual;
    end if;
    if rec4.srls_id = 105 then
      select rec2.price_zak into v_cnt from dual;
    end if;
    insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select 
rec1.tmcl_id, 1, v_cnt, 2, null, rec2.rpdr_id, null, to_date('01.01.2015','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 1, 1, rec3.lcal_id, 
0, 'Y', null, null, rec4.srls_id, 0, null, null, null, null, null, 0, null, 
null, null, null, null, null, 0
from dual;
  end loop;
  end loop;
  end loop;
  end loop;
end;


select * from trafics_by_directions
where rpdr_rpdr_id in (select rpdr_id From aak_pset2
join rate_plan_directions on name_loc like name_r
where pack_pack_id = 504)




join directions on drct_id = drct_drct_id


select * from pset_directions where drct_drct_id is not null



select * from prefix_sets where cou_cou_id = 7
select distinct * from aak_498_1 join cou_drct on name_r like name_loc

select * from aak_498_1

��������
select * from cou_drct
for update

countries
 
480 pack
45787 pset




