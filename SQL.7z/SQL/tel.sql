SET heading OFF;
SET echo OFF;
SET feedback OFF;
SET trimspool ON;
SET newpage NONE;
SET verify OFF;
SET define OFF;
SET termout OFF;
SET timing OFF;
--------------------------------------------------------
--�������-------------------------------------------
--------------------------------------------------------
spool C:\Users\A.Kosterin\Desktop\Distrib\Test\tel_202001.txt;
Select cdr from (select distinct t.phonea,t.talkdate,'01,,,,,'||t.phonea||','||t.phoneb||','||TO_CHAR(t.talkdate, 'yyyymmddHH24MISS')||','||t.dlit||',,06,,,,,00,01,N,Y,,,,,,,,'||t.phoneb||',,,,,,,,,,,,,,,'''||rtrim(to_char(t.summp, 'fm9999d999','NLS_NUMERIC_CHARACTERS = ''. '''), '.,')||';68;'||dg.detg_id||';'||t.Id_Connect||';'||t.plan_id||''',,,' as cdr 
from T_APUS t 
left join T_APUS_VIEW tav on tav.ceil_id=t.ceil_id
left join T_OTHER_SVC tas on tav.OTH_SVC_ID=tas.OTH_SVC_ID
LEFT JOIN t_svc_ref tsr on tsr.svc_id=tas.SVC_ID
LEFT JOIN ps_migr.detail_groups dg on dg.svc_id=tas.SVC_ID
left join ps_migr.migr_clnt_stage_statuses@BIS_ALPHA.BS.DS.SIBIRTELECOM.RU mcs
on mcs.ext_batch_id = bl.batch_batch_id
and mcs.ext_clnt_id = bl.clnt_clnt_id
JOIN rtk_migr_batch_lists bl ON t.user_id=bl.user_id 
where 1=1 and t.BILLING_ID='202001'  AND bl.batch_batch_id=3000 
--and t.plan_id=4
and (mcs.in_bis = 0 or mcs.in_bis is null)
order by t.phonea,t.talkdate asc);
spool off;
--------------------------------------------------------
--���-------------------------------------------------
--------------------------------------------------------
spool C:\Users\A.Kosterin\Desktop\Distrib\Test\vzn_202001.txt;
Select cdr from (select distinct VNZONE,phonefrom,t.codetown||phoneto,talkdate,NVL(S.MTR_ID,0) as MTR_ID,NVL(ts.vnset_id,0) as vnset_id,
'01,,,,,'||phonefrom||','||(case when LENGTH(phoneto)=8 then '7' else '' end)||(case when (t.codetown)='0560' then '' when (t.codetown)='056' then '' else t.codetown end)||phoneto||','||TO_CHAR(talkdate, 'yyyymmddHH24MISS')||','||trim(to_char(real_dlit*60,'00000'))||',,06,,,,,00,20,N'
||','||(case when (t.mts_svc_cod)<>'1' then 'N' else 'Y' end)||',,,,,,,,'||(case when vid_cod=8 then '7' else '' end)||(case when (t.codetown)='0560' then ''else t.codetown end)||phoneto||',,,,,,,,,,,,,,,'''||rtrim(to_char(summ, 'fm9999d999','NLS_NUMERIC_CHARACTERS = ''. '''), '.,')||';'||(case when is_mobile='Y' then '67' when is_mobile='N' then '68' end)||';'||dg.detg_id||';'||S.MTR_ID||';'||ts.vnset_id||''',,,' as cdr 
FROM T_MTS_SIG t 
JOIN T_MTS_RES s on t.mtr_id=s.mtr_id
JOIN rtk_migr_batch_lists bl ON s.user_id=bl.user_id  AND bl.batch_batch_id=3000
JOIN t_mts_zone mz ON s.mts_zone_id=mz.mts_zone_id AND mz.VNZONE='Y'
JOIN t_services ts ON ts.user_id=s.user_id AND ts.phone=t.phonefrom and ts.date_end is null
JOIN t_svc_ref tsr on tsr.svc_id=mz.a_svc_id
JOIN ps_migr.detail_groups dg on dg.svc_id=mz.a_svc_id
left join ps_migr.migr_clnt_stage_statuses@BIS_ALPHA.BS.DS.SIBIRTELECOM.RU mcs
on mcs.ext_batch_id = bl.batch_batch_id
and mcs.ext_clnt_id = bl.clnt_clnt_id
JOIN T_MTS_SVC_ADD SA on S.MTR_ID = SA.MTR_ID 
JOIN T_MTS_C_REF L1 on SA.MTS_C_ID = L1.MTS_C_ID  
JOIN T_MTS_COD_REF CR on CR.MTS_COD_ID = L1.MTS_COD_ID
JOIN T_MTS_VNSET_REF ntt ON ts.vnset_id=ntt.vnset_id 
WHERE t.BILLING_ID=202001 AND s.billing_id=t.BILLING_ID  
and t.vid_cod in ('1','31','7','18') 
and (mcs.in_bis = 0 or mcs.in_bis is null)
--AND ts.vnset_id IN (90557663) 
order by phonefrom,talkdate asc)
where vnset_id>0 and MTR_ID>0;
spool off;

--------------------------------------------------------
--��--------------------------------------------------
---------------------------------------------------------
spool C:\Users\A.Kosterin\Desktop\Distrib\Test\mg_202001.txt;
Select cdr from (select distinct VNZONE,phonefrom,t.codetown||phoneto,talkdate,NVL(S.MTR_ID,0) as MTR_ID,NVL(ts.vnset_id,0) as vnset_id,
(select bis_id from migr_mapping where start_type='MTS_COD_MG' and start_name=mz.cod||'-'||CR.NAMe) as DRCT, mz.cod||'-'||CR.NAMe as alias,
'01,,,,,'||phonefrom||','||'7'||(case when (t.codetown)='0560' then '' when (t.codetown)='083' then ''  when (t.codetown)='0640' then '' when (t.codetown)='062' then ''when (t.codetown)='0570' then '' when (t.codetown)='0650' then '' when (t.codetown)='0340' then '' when (t.codetown)='0500' then '' when (t.codetown)='0420' then '' when (t.codetown)='0540' then '' when (t.codetown)='0440' then '' when (t.codetown)='045' then '' when (t.codetown)='0670' then '' when (t.codetown)='067' then '' when (t.codetown)='054' then '' when (t.codetown)='0190' then '' when (t.codetown)='0410' then '' when (t.codetown)='0770' then '' when (t.codetown)='0730' then '' when (t.codetown)='0710' then '' when (t.codetown)='0450' then '' when (t.codetown)='069' then '' when (t.codetown)='0780' then '' when (t.codetown)='0750' then '' when (t.codetown)='0270' then '' when (t.codetown)='0390' then '' when (t.codetown)='0220' then '' when (t.codetown)='0280' then '' when (t.codetown)='0170' then '' when (t.codetown)='0830' then '' when (t.codetown)='0040' then '' when (t.codetown)='0260' then '' when (t.codetown)='0180' then '' when (t.codetown)='0539' then '' when (t.codetown)='0210' then '' when (t.codetown)='077' then '' when (t.codetown)='0720' then '' when (t.codetown)='0250' then '' when (t.codetown)='0470' then '' when (t.codetown)='0370' then ''when (t.codetown)='0250' then '' when (t.codetown)='0240' then '' when (t.codetown)='0810' then '' when (t.codetown)='053' then '' when (t.codetown)='0620' then '' else t.codetown end)||phoneto||','||TO_CHAR(talkdate, 'yyyymmddHH24MISS')||','||trim(to_char(real_dlit*60,'0000'))||',,05,,,,,00,20,N,'||(case when (t.mts_svc_cod)<>'1' then 'N' else 'Y' end)||',,,,,,,,'||'7'||(case when (t.codetown)='0560' then ''   when (t.codetown)='0640' then '' when (t.codetown)='062' then ''when (t.codetown)='0570' then '' when (t.codetown)='0650' then '' when (t.codetown)='0500' then '' when (t.codetown)='0420' then '' when (t.codetown)='0540' then '' when (t.codetown)='0440' then '' when (t.codetown)='045' then '' when (t.codetown)='0670' then '' when (t.codetown)='067' then '' when (t.codetown)='054' then '' when (t.codetown)='0190' then '' when (t.codetown)='0410' then '' when (t.codetown)='0770' then '' when (t.codetown)='0730' then '' when (t.codetown)='0710' then '' when (t.codetown)='0450' then '' when (t.codetown)='069' then '' when (t.codetown)='0780' then '' when (t.codetown)='0750' then '' when (t.codetown)='0270' then '' when (t.codetown)='0390' then '' when (t.codetown)='0220' then '' when (t.codetown)='0280' then '' when (t.codetown)='0170' then '' when (t.codetown)='0830' then '' when (t.codetown)='0040' then '' when (t.codetown)='0260' then '' when (t.codetown)='0180' then '' when (t.codetown)='0539' then '' when (t.codetown)='0210' then '' when (t.codetown)='077' then '' when (t.codetown)='0720' then '' when (t.codetown)='0250' then '' when (t.codetown)='0470' then '' when (t.codetown)='0370' then ''when (t.codetown)='0250' then '' when (t.codetown)='0240' then '' when (t.codetown)='0810' then '' when (t.codetown)='0340' then '' when (t.codetown)='053' then '' when (t.codetown)='0620' then '' when (t.codetown)='083' then '' else t.codetown end)||phoneto||',,,,,,,,,,,,,,,'''||rtrim(to_char(summ, 'fm9999d999','NLS_NUMERIC_CHARACTERS = ''. '''), '.,')||';'||(select bis_id from migr_mapping where start_type='MTS_COD_MG' and start_name=mz.cod||'-'||CR.NAMe)||';'||dg.detg_id||';'||S.MTR_ID||';'||ts.vnset_id||''',,,,,,,,,,,,,,,,,,,,,,,,,,' as cdr
FROM T_MTS_SIG t 
JOIN T_MTS_RES s on t.mtr_id=s.mtr_id
JOIN rtk_migr_batch_lists bl ON s.user_id=bl.user_id  AND bl.batch_batch_id=3000 
JOIN t_mts_zone mz ON s.mts_zone_id=mz.mts_zone_id --AND mz.isintl='N' -- ������������ (Y)-��, (N)-�� 
JOIN t_svc_ref tsr on tsr.svc_id=mz.a_svc_id
JOIN ps_migr.detail_groups dg on dg.svc_id=mz.a_svc_id
left join ps_migr.migr_clnt_stage_statuses@BIS_ALPHA.BS.DS.SIBIRTELECOM.RU mcs
on mcs.ext_batch_id = bl.batch_batch_id
and mcs.ext_clnt_id = bl.clnt_clnt_id
JOIN T_MTS_SVC_ADD SA on S.MTR_ID = SA.MTR_ID
JOIN T_MTS_C_REF L1 on SA.MTS_C_ID = L1.MTS_C_ID
JOIN T_MTS_COD_REF CR on CR.MTS_COD_ID = L1.MTS_COD_ID
JOIN t_services ts ON ts.user_id=s.user_id AND ts.phone=t.phonefrom and ts.date_end is null
JOIN T_MTS_VNSET_REF ntt ON ts.vnset_id=ntt.vnset_id 
WHERE t.BILLING_ID=202001 AND s.billing_id=t.BILLING_ID and t.vid_cod in ('2','32','3','7','18') 
and t.internl='N'
and (mcs.in_bis = 0 or mcs.in_bis is null)
and mz.cod not in('2290','2291','2291','2292','2293','2294','82290','82291','82291','82292','82293','82294') --��� ����������, ��.������, �������
--AND ts.vnset_id IN (29020297) 
order by phonefrom,talkdate asc)
where vnset_id>0 and MTR_ID>0;
spool off;

--------------------------------------------------------
--��--------------------------------------------------
---------------------------------------------------------

spool C:\Users\A.Kosterin\Desktop\Distrib\Test\mn_202001.txt;
Select cdr from (select distinct phonefrom,t.codetown||phoneto,talkdate,NVL(S.MTR_ID,0) as MTR_ID,NVL(ts.vnset_id,0) as vnset_id,
(select bis_id from migr_mapping where start_type='MTS_COD_MN' and start_name=mz.cod||'-'||CR.NAMe) as DRCT,
mz.cod||'-'||CR.NAMe as alias,
'01,,,,,'||phonefrom||',810'||t.codetown||phoneto||','||TO_CHAR(talkdate, 'yyyymmddHH24MISS')||','||trim(to_char(real_dlit*60,'0000'))||',,,,,,,00,20,N,'||(case when (t.mts_svc_cod)<>'1' then 'N' else 'Y' end)||',,,,,,,,810'||t.codetown||phoneto||',,,,,,,,,,,,,,,'''||rtrim(to_char(summ, 'fm9999d999','NLS_NUMERIC_CHARACTERS = ''. '''), '.,')||';'||(select bis_id from migr_mapping where start_type='MTS_COD_MN' and start_name=mz.cod||'-'||CR.NAMe)||';'||dg.detg_id||';'||S.MTR_ID||';'||ts.vnset_id||''',,,,,,,,,,,,,,,,,,,,,,,,,,' as cdr 
FROM T_MTS_SIG t 
JOIN T_MTS_RES s on t.mtr_id=s.mtr_id
JOIN rtk_migr_batch_lists bl ON s.user_id=bl.user_id  AND bl.batch_batch_id=3000 
JOIN t_mts_zone mz ON s.mts_zone_id=mz.mts_zone_id --AND mz.isintl='Y' -- ������������ (Y)-��, (N)-�� 
JOIN t_svc_ref tsr on tsr.svc_id=mz.a_svc_id
JOIN ps_migr.detail_groups dg on dg.svc_id=mz.a_svc_id
JOIN T_MTS_SVC_ADD SA on S.MTR_ID = SA.MTR_ID
JOIN T_MTS_C_REF L1 on SA.MTS_C_ID = L1.MTS_C_ID
left join ps_migr.migr_clnt_stage_statuses@BIS_ALPHA.BS.DS.SIBIRTELECOM.RU mcs 
on mcs.ext_batch_id = bl.batch_batch_id and mcs.ext_clnt_id = bl.clnt_clnt_id
JOIN T_MTS_COD_REF CR on CR.MTS_COD_ID = L1.MTS_COD_ID
JOIN t_services ts ON ts.user_id=s.user_id AND ts.phone=t.phonefrom and ts.date_end is null
JOIN T_MTS_VNSET_REF ntt ON ts.vnset_id=ntt.vnset_id 
WHERE t.BILLING_ID=202001 AND s.billing_id=t.BILLING_ID and  t.vid_cod in ('2','3','7','18') --22 ���� �����, ����� ����������� �����
and t.internl='Y'
and (mcs.in_bis = 0 or mcs.in_bis is null)
--AND ts.vnset_id IN (29020297) 
order by phonefrom,talkdate asc)
where vnset_id>0 and MTR_ID>0
--���������� ����������, �������, ����� ������
Union
Select cdr from (
select distinct phonefrom,t.codetown||phoneto,talkdate,NVL(S.MTR_ID,0) as MTR_ID,NVL(ts.vnset_id,0) as vnset_id,
(select bis_id from migr_mapping where start_type='MTS_COD_MG' and start_name=mz.cod||'-'||CR.NAMe) as DRCT,
mz.cod||'-'||CR.NAMe as alias,
'01,,,,,'||phonefrom||',8107'||t.codetown||phoneto||','||TO_CHAR(talkdate, 'yyyymmddHH24MISS')||','||trim(to_char(real_dlit*60,'0000'))||',,,,,,,00,20,N,'||(case when (t.mts_svc_cod)<>'1' then 'N' else 'Y' end)||',,,,,,,,8107'||t.codetown||phoneto||',,,,,,,,,,,,,,,'''||rtrim(to_char(summ, 'fm9999d999','NLS_NUMERIC_CHARACTERS = ''. '''), '.,')||';'||(select bis_id from migr_mapping where start_type='MTS_COD_MG' and start_name=mz.cod||'-'||CR.NAMe)||';'||dg.detg_id||';'||S.MTR_ID||';'||ts.vnset_id||''',,,,,,,,,,,,,,,,,,,,,,,,,,' as cdr 
FROM T_MTS_SIG t 
JOIN T_MTS_RES s on t.mtr_id=s.mtr_id
JOIN rtk_migr_batch_lists bl ON s.user_id=bl.user_id  AND bl.batch_batch_id=3000 
JOIN t_mts_zone mz ON s.mts_zone_id=mz.mts_zone_id --AND mz.isintl='N' -- ������������ (Y)-��, (N)-�� 
JOIN t_svc_ref tsr on tsr.svc_id=mz.a_svc_id
JOIN ps_migr.detail_groups dg on dg.svc_id=mz.a_svc_id
JOIN T_MTS_SVC_ADD SA on S.MTR_ID = SA.MTR_ID
left join ps_migr.migr_clnt_stage_statuses@BIS_ALPHA.BS.DS.SIBIRTELECOM.RU mcs 
on mcs.ext_batch_id = bl.batch_batch_id and mcs.ext_clnt_id = bl.clnt_clnt_id
JOIN T_MTS_C_REF L1 on SA.MTS_C_ID = L1.MTS_C_ID
JOIN T_MTS_COD_REF CR on CR.MTS_COD_ID = L1.MTS_COD_ID
JOIN t_services ts ON ts.user_id=s.user_id AND ts.phone=t.phonefrom and ts.date_end is null
JOIN T_MTS_VNSET_REF ntt ON ts.vnset_id=ntt.vnset_id 
WHERE t.BILLING_ID=202001 AND s.billing_id=t.BILLING_ID and t.vid_cod in ('2','32','3','7','18') 
and t.internl='N'
and mz.cod in('2290','2291','2291','2292','2293','2294','82290','82291','82291','82292','82293','82294') --��� ����������, ��.������, �������
--AND ts.vnset_id IN (29020297) 
and (mcs.in_bis = 0 or mcs.in_bis is null)
order by phonefrom,talkdate asc)
where vnset_id>0 and MTR_ID>0;
spool off;
