select * from packs where pack_id in (3515, 3516, 3517, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731)

select * from rate_plan_directions where rtpl_rtpl_id = 217

select * from BIS.PACK_TYPES
select * from PACKS  where pack_id in (3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730)
select * from PACK_RTPL where pack_pack_id in (3515, 3516, 3517, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731) and rtpl_rtpl_id = 217
select t.rowid, (select name_r from packs where pack_id = pack_pack_id), t.* from TARIF_HISTORIES t where pack_pack_id in (3515, 3516, 3517, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731)
for update
select * from TRAFIC_HISTORIES where pack_pack_id in (3515, 3516, 3517, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731)
select * from PACK_ZONE_HISTORIES where pack_pack_id in (3515, 3516, 3517, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731)
select * from PACK_PRIORITY_HISTORIES where pack_pack_id in (3515, 3516, 3517, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731)
select * from PACK_TYPES_RESTRICTIONS



select * from tarification_regions
---------
select * from PACK_RTPL where pack_pack_id in (3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731) order by pack_pack_id
for update
select * from zones where zone_id = 103
select * from PACK_RTPL where pack_pack_id in (3515, 3516, 3517) for update

select * from TARIF_HISTORIES where pack_pack_id in (3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730)
for update
select * from trafic_histories where rtpl_rtpl_id = 217 and zone_zone_id = 103
for update
select * from tarification_regions
select * from rating_groups

select * from price_list
select * from discount_plan_region_values
select * from dcpl_rtpl
----�������� tarif_hist
begin
for rec in (select * from packs where pack_id in (3719, 3720, 3721, 3722, 3724, 3725, 3726, 3727, 3728, 3729, 3730, 3731)) loop
insert into TARIF_HISTORIES (RTPL_RTPL_ID, NUMBER_HISTORY, SRLS_SRLS_ID, RNDT_RNDT_ID, MTCG_MTCG_ID, FIRST_RATE, MONTH_RATE, WARNING_$, BREAK_$, START_DATE, END_DATE, NAVI_USER, NAVI_DATE, XPNS_XPNS_ID, PACK_PACK_ID, MIN_VOLUME, MAX_VOLUME, MSRU_MSRU_ID, CUR_CUR_ID, XTYP_XTYP_ID, TRAF_BY_DIR_#, TAX_INCLUDED, TAX_TAX_ID, REALTIME_YN, ACTIVATE_$, MAIN_YN, TARIF_MODIFY, RATE_FOR_ONE_DAY, RT_BREAK_$, PACK_ORDER_CONNECT, PACK_REVOKE_DISCONNECT, EVAL_DISC_RATE, EVAL_DISC_DAYS, TAX_RATE, FEE_TAX_INCLUDED, FEE_WARNING_$, FEE_BREAK_$, FEE_ACTIVATE_$, FEE_PRIORITY_YN, FLOOR_CALC_TYPE, FLOOR_VALUE, FLOOR_PRICE_$, TVTP_TVTP_ID, ADVANCE_RATE, FLAG_CS)
select RTPL_RTPL_ID, 1, SRLS_SRLS_ID, RNDT_RNDT_ID, MTCG_MTCG_ID, FIRST_RATE, MONTH_RATE, WARNING_$, BREAK_$, START_DATE, END_DATE, 'AAK', SYSDATE, 
XPNS_XPNS_ID, REC.PACK_ID, MIN_VOLUME, MAX_VOLUME, MSRU_MSRU_ID, CUR_CUR_ID, XTYP_XTYP_ID, TRAF_BY_DIR_#, TAX_INCLUDED, TAX_TAX_ID, REALTIME_YN, ACTIVATE_$, MAIN_YN, 
TARIF_MODIFY, RATE_FOR_ONE_DAY, RT_BREAK_$, PACK_ORDER_CONNECT, PACK_REVOKE_DISCONNECT, EVAL_DISC_RATE, EVAL_DISC_DAYS, TAX_RATE, FEE_TAX_INCLUDED, FEE_WARNING_$, 
FEE_BREAK_$, FEE_ACTIVATE_$, FEE_PRIORITY_YN, FLOOR_CALC_TYPE, FLOOR_VALUE, FLOOR_PRICE_$, TVTP_TVTP_ID, ADVANCE_RATE, FLAG_CS from TARIF_HISTORIES where pack_pack_id in (3723);
end loop;
end;
----�������� trafic_histories
select t.rowid,(select name_r from packs where pack_id = pack_pack_id),t.* from trafic_histories t where rtpl_rtpl_id = 217 and zone_zone_id = 103 
--and rtgr_rtgr_id = 14 
for update

select * from serv_lists where srls_id = 210  

select distinct pack_pack_id from trafic_histories where rtpl_rtpl_id = 217 and zone_zone_id = 103 

select * from trafic_histories where pack_pack_id in (3719, 3720, 3721, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730)

begin
      for rec in (select * from PACKS  where pack_id in (3719) 
        --, 3721, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730)) 
       ) loop
    insert into bis.trafic_histories
(SRLS_SRLS_ID, ZNTP_ZNTP_ID, NUMBER_HISTORY, TMCL_TMCL_ID, BSS_BSS_ID, ZONE_ZONE_ID, LCAL_LCAL_ID, RTPL_RTPL_ID, PACK_PACK_ID, PSET_PSET_ID, PRICE_$, PSET_COST_$, CONNECTION_$, FUNCTION_NAME, START_DATE, END_DATE, NAVI_USER, NAVI_DATE, FAFT_FAFT_ID, SCPR_SCPR_ID, RTGR_RTGR_ID, PTTP_PTTP_ID, COU_COU_ID, RMOP_RMOP_ID, AOB_AOB_ID, RTCM_RTCM_ID, VUNT_VUNT_ID, FLAG_CS, TFRG_TFRG_ID, HOME_TFRG_ID, HOME_RMOP_ID, RMTP_RMTP_ID, ACTN_ACTN_ID, MUNT_MUNT_ID, MSRU_MSRU_ID)
select
SRLS_SRLS_ID, ZNTP_ZNTP_ID, 1, TMCL_TMCL_ID, BSS_BSS_ID, ZONE_ZONE_ID, LCAL_LCAL_ID, RTPL_RTPL_ID, rec.pack_id, PSET_PSET_ID, PRICE_$, PSET_COST_$, CONNECTION_$, FUNCTION_NAME, START_DATE, END_DATE, 'AAK', SYSDATE, FAFT_FAFT_ID, SCPR_SCPR_ID, RTGR_RTGR_ID, PTTP_PTTP_ID, COU_COU_ID, RMOP_RMOP_ID, AOB_AOB_ID, RTCM_RTCM_ID, VUNT_VUNT_ID, FLAG_CS, TFRG_TFRG_ID, HOME_TFRG_ID, HOME_RMOP_ID, RMTP_RMTP_ID, ACTN_ACTN_ID, MUNT_MUNT_ID, MSRU_MSRU_ID
from trafic_histories where rtpl_rtpl_id = 217 and zone_zone_id = 103;
end loop;
end;
select * from pstn_calls_00_052018 

select * from packs where pack_id = 3722

select FEEINADVANCE_FUNC_CHARGES_MTH from dual
select CHECK_CHARGES_MTH from dual

select * from dba_objects 
where 1=1
and lower(object_name) like '%mth%' 
and owner = 'BIS'
and object_type = 'FUNCTION'

select * from v$version

select BIS_ENGINE.get_subs_by_msisdn(35131) from dual

select * from dba_objects where lower(object_name) like '%mod%'
and owner like 'BIS'
and object_type = 'TABLE'


select 'select * from '||OBJECT_NAME||';' from dba_objects where lower(object_name) like '%price%'
and owner like 'BIS'
and object_type = 'TABLE'





select * from detail_groups

select * from CIS_BONUSES;
select * from rate_plans where lower(name_r) like '%���%'

-----
select * from discount_plans
where pack_pack_id in (3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730)
for update

select * from DCPL_RTPL_HISTORIES t
where t.dcpl_dcpl_id = :m_dcpl_id


---3731 ���������

create table for_test (bis_id number(10),
BIS_NAME varchar2(100)
)

select * from for_test 
for update 

truncate table for_test

--Webstream 3000 ��

----��������� discount_plans
declare
v_cnt number :=0;
begin
      for rec in (select * from for_test where bis_id != 3723) loop
    insert into bis.discount_plans
          (DCPL_ID, DEF, RTPL_RTPL_ID, PACK_PACK_ID, DCTP_DCTP_ID, DCMR_DCMR_ID, DCMR_DCMR_ID1, DCMR_DCMR_ID2, DATP_DATP_ID, DCCL_DCCL_ID, DCST_DCST_ID, DCPA_DCPA_ID, DCCA_DCCA_ID, DCPL_COMMENT, DCGR_DCGR_ID, AUTOMATIC_YN, BRT_INFORM, BRT_ACTION, PRIORITY, BRT_MIN_QUOTA, DPCT_DPCT_ID, DBSL_DBSL_ID, HISTORY_PERIOD, DELETE_UNUSED, DENY_PACK_ID, ALIGN_TUNT_ID, RNDT_RNDT_ID, COMMON_CLCR_DCTR_VOLUME_YN, BIS_INFORM, MSRR_MSRR_ID, DMCT_DMCT_ID, IGNORE_SUBS_PACK_CHARGES, ALIGN_QUOTA_BY_DCTV, IS_FINAL, ROLL_OVER_ALLOWED, ROLL_OVER_PACK_ID)
          select distinct (select nvl(max(DCPL_ID)+1,0) from discount_plans) DCPL_ID, 'Webstream '||rec.bis_name, RTPL_RTPL_ID, rec.bis_id, DCTP_DCTP_ID, DCMR_DCMR_ID, DCMR_DCMR_ID1, DCMR_DCMR_ID2, DATP_DATP_ID, DCCL_DCCL_ID, DCST_DCST_ID, DCPA_DCPA_ID, DCCA_DCCA_ID, DCPL_COMMENT, DCGR_DCGR_ID, AUTOMATIC_YN, BRT_INFORM, BRT_ACTION, PRIORITY, BRT_MIN_QUOTA, DPCT_DPCT_ID, DBSL_DBSL_ID, HISTORY_PERIOD, DELETE_UNUSED, DENY_PACK_ID, ALIGN_TUNT_ID, RNDT_RNDT_ID, COMMON_CLCR_DCTR_VOLUME_YN, BIS_INFORM, MSRR_MSRR_ID, DMCT_DMCT_ID, IGNORE_SUBS_PACK_CHARGES, ALIGN_QUOTA_BY_DCTV, IS_FINAL, ROLL_OVER_ALLOWED, ROLL_OVER_PACK_ID
            from discount_plans
           where pack_pack_id in (3722);
            -- ORDER BY DCPL_ID
             --OFFSET v_cnt ROWS FETCH NEXT 1 ROWS ONLY;
             v_cnt:=v_cnt+1;
             dbms_output.put_line(v_cnt);
           --  commit;
    end loop;
    end;

----


select * from DISCOUNT_THREADS where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select distinct bis_id from for_test)))
for update

select * from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select distinct bis_id from for_test))
and dcpl_id in (312,358)


-----��������� DISCOUNT_THREADS

declare
v_cnt number :=0;
begin
      for rec in (select * from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select distinct bis_id from for_test))
and dcpl_id != 312) loop
    insert into bis.DISCOUNT_THREADS
          (DCTR_ID, PHONE_NUMBER, CIRCUIT_IN, CIRCUIT_OUT, SRLS_SRLS_ID, ZNTP_ZNTP_ID, LCAL_LCAL_ID, ZONE_ZONE_ID, TMCL_TMCL_ID, DCTC_DCTC_ID, DCPL_DCPL_ID, FUNCTION_NAME, DISCOUNT_ZERO_PRICE, MTH_SRLS_ID, BRT_WARNING, NAVI_USER, NAVI_DATE, DEL_USER, DEL_DATE, BRT_PRIORITY, DEF, DTRE_DTRE_ID, DVCN_DVCN_ID, DVCN_VOLUME, NO_RESERVE, IGNORE_DEBET, IGNORE_BALANCE_LOCK)
          select distinct (select nvl(max(DCTR_ID)+1,0) from DISCOUNT_THREADS) DCTR_ID, PHONE_NUMBER, CIRCUIT_IN, CIRCUIT_OUT, SRLS_SRLS_ID, ZNTP_ZNTP_ID, LCAL_LCAL_ID, ZONE_ZONE_ID, TMCL_TMCL_ID, DCTC_DCTC_ID, rec.dcpl_id, FUNCTION_NAME, DISCOUNT_ZERO_PRICE, MTH_SRLS_ID, BRT_WARNING, 'AAK', SYSDATE, DEL_USER, DEL_DATE, BRT_PRIORITY, rec.def, DTRE_DTRE_ID, DVCN_DVCN_ID, DVCN_VOLUME, NO_RESERVE, IGNORE_DEBET, IGNORE_BALANCE_LOCK
            from DISCOUNT_THREADS
           where dcpl_dcpl_id in (312);
             v_cnt:=v_cnt+1;
             dbms_output.put_line(v_cnt);
           --  commit;
    end loop;
    end;


---------

select * from discount_thread_volumes 
where dctr_dctr_id in 
(
select dctr_id from DISCOUNT_THREADS t
where t.dcpl_dcpl_id in (
select dcpl_id from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select distinct bis_id from for_test)
))
)
for update
  

select * from DISCOUNT_THREADS where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select distinct bis_id from for_test))
and dcpl_id != 312)

----��������� discount_thread_volumes


declare
v_cnt number :=0;
begin
      for rec in (select * from DISCOUNT_THREADS where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select distinct bis_id from for_test))
and dcpl_id != 312)) loop
    insert into bis.discount_thread_volumes
          (DCTV_ID, DCTR_DCTR_ID, VALUE_#, START_VALUE, END_VALUE, NAVI_USER, NAVI_DATE, DEL_USER, DEL_DATE, VALUE_CONNECTION_#, VALUE_IN_BALANCE_#, CONNECTION_$, PRICE_$, DVCN_DVCN_ID, NEXT_DCTV_ID, CHILD_DCTV_ID, BREAK_$, JOIN_$, REPORT_THRESHOLD)
          select distinct (select nvl(max(DCTV_ID)+1,0) from discount_thread_volumes) DCTV_ID, rec.dctr_id, VALUE_#, START_VALUE, END_VALUE, 'AAK '||rec.def, SYSDATE, DEL_USER, DEL_DATE, VALUE_CONNECTION_#, VALUE_IN_BALANCE_#, CONNECTION_$, PRICE_$, DVCN_DVCN_ID, NEXT_DCTV_ID, CHILD_DCTV_ID, BREAK_$, JOIN_$, REPORT_THRESHOLD
            from discount_thread_volumes
           where dctr_dctr_id in (317);
             v_cnt:=v_cnt+1;
             dbms_output.put_line(v_cnt);
           --  commit;
    end loop;
    end;

select * from  discount_thread_volumes
where dctr_dctr_id in (317,364,368,370,365,367,369,359,366,363,361,362)
for update

select * from macroregions

------------��������� discount_plan_histories
select * from discount_plan_histories where dcpl_dcpl_id in (select dcpl_id from discount_plans
where pack_pack_id in (3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730))
for update
--where dcpl_dcpl_id = 312

begin
      for rec in (select * from discount_plans
where pack_pack_id in (3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728, 3729, 3730) and dcpl_id !=312) loop
    insert into bis.discount_plan_histories
          (DCPL_DCPL_ID, NUMBER_HISTORY, DURATION, DURATION_WAIT, START_USE, END_USE, START_DATE, END_DATE, NAVI_USER, NAVI_DATE, CLCR_VOLUME)
          select rec.dcpl_id,1, DURATION, DURATION_WAIT, START_USE, END_USE, START_DATE, END_DATE, 'AAK '||rec.def, SYSDATE, CLCR_VOLUME from discount_plan_histories 
          where dcpl_dcpl_id = 312;

end loop;
end;


------��������� discount_plan_region_values ���� ���������
select * from discount_plan_region_values



