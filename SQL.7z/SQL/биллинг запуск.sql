delete From bgi_req_done where bgirq_bgirq_id in (select s.bgirq_bgirq_id from bis.bt_sets s, bis.bt_states st where s.btst_btst_id = st.btst_id and btts_btts_id=1291) ;
delete from bt_btse_clnt where btts_btts_id=1291;
select * from bill_substractions t where t.bill_bill_id=181202900004001
select * from bill_details b 
/
begin
bis.pack_billing_aggregate.aggregate_data(ip_blgr_id_lst => 1, agr_bill_date => trunc(sysdate,'mm')-1/24/60/60);
end;
/
begin
bis.pack_billing_aggregate.AGGREGATE_ROAM_DATA(agr_bill_date => trunc(sysdate,'mm')-1/24/60/60);
end;
/
begin
bis.PACK_BILLING_DISC_PARAMS.CALCULATE_DISC_PARS(ip_date =>  trunc(sysdate,'mm')-1/24/60/60,ip_RUN_AGGREGATE_BILLING => true,ip_RUN_AGGREGATE_BILLING_ROAM => true);
end;
/
select trunc(sysdate,'mm')-1/24/60/60 from dual
select * from billing_groups for update
delete from billing_groups where blgr_id = 1
select * from cycle_statuses

select (select def from cycle_statuses where clst_clst_id = clst_id), bc.*, rowid from bill_cycles bc where cycle_date = trunc(sysdate,'mm')-1/24/60/60 order by cycle_date desc
for update

select * From BILL_CYCLE_DETAILS where blcl_blcl_id = 181231000001369

SELECT NVL(MAX(BCD_ID),0)+1 FROM BILL_CYCLE_DETAILS;

INSERT INTO BILL_CYCLE_DETAILS(BCD_ID, BLCL_BLCL_ID, CLNT_CLNT_ID) VALUES (1165, 181231000001369, 67241);

select * From bill_cycles 
where blgr_blgr_id = 1
order by blcl_id desc

select gt.blcl_blcl_id, gt.* from bis.bills gt 
where 1=1 --gt.bill_date > to_date('01.12.2018','dd.mm.yyyy')
and gt.blcl_blcl_id = 181231000001349-- desc


select BTTS_seq.nextval from duaL
select blcl_seq.nextval from duaL

select * from bt_tasks for update;
select bc.*, rowid from bill_cycles bc where cycle_date = trunc(sysdate,'mm')-1/24/60/60 and bct_bct_id = 1 order by cycle_date desc;

select * from bill_cycles bc, bill_cycle_details bcd where bcd.blcl_blcl_id=bc.blcl_id and bcd.clnt_clnt_id in (67220)-- and bc.clst_clst_id in (3, 9);
select * From bill_cycle_details where clnt_clnt_id = 67220
for update

select * From bill_cycles
select * From billing_groups 
for update
select blgr_seq.nextval from dual

select * from client_histories where clnt_clnt_id = 67220 for update

begin
bis.PACK_BILLING_DISC_PARAMS.CALCULATE_DISC_PARS(ip_date =>  trunc(sysdate,'mm')-1/24/60/60,ip_RUN_AGGREGATE_BILLING => true,ip_RUN_AGGREGATE_BILLING_ROAM => true);
end;


select trunc(sysdate,'mm')-1/24/60/60 from dual


begin
  bis.PACK_BILLING_TASK.BT_INIT(0);
end;




select * from bis.BT_TASKS for update;
select * from bis.BT_SETS for update;
select * from bis.BT_BTSE_CLNT for update;
select * from bill_cycles where cycle_date=trunc(sysdate,'mm')-1/24/60/60 and bct_bct_id=1 and blgr_blgr_id = 0-- for update
select * from bill_cycles where blcl_id like '1801%' for update

for update
select * from cycle_statuses

begin
  bis.PACK_BILLING_TASK.BT_INIT(0);
end;

select trunc(sysdate,'mm')-1/24/60/60 from dual
select to_date('31.01.2018 23:59:59','dd.mm.yyyy hh24:mi:ss') from dual

declare
v_blcl_id number;
begin
  select blcl_id into v_blcl_id from bill_cycles where blcl_id = 181231000001349;
  bis.PACK_BILLING_TASK.BT_ADD_TASK(p_bill_date => to_date('31.12.2018 23:59:59','dd.mm.yyyy hh24:mi:ss'),--trunc(sysdate,'mm')-1/24/60/60,
                                    p_blcl_id => v_blcl_id, 
                                    p_sets_max => 100000,
                                    P_START_CLNT_ID => 67220, P_END_CLNT_ID =>67220);
end;


begin
  bis.PACK_BILLING_TASK.BT_ADD_IND;
end;


select * from app_parameters where appl_appl_id=1 and prmt_id=10237 for update
begin
  bis.PACK_BILLING_TASK.RUN_PACK_BILLING;
end;

begin
  for rec in (select * from bis.BT_TASKS) loop 
  pack_billing_task_bgi.start_bgi_proccess(p_btts_id => rec.btts_id);
  end loop;
end;

select * from charges where subs_subs_id in (select subs_id from subscribers where clnt_clnt_id = 67220)

select b.btts_btts_id, b.try_count, b.bgirq_bgirq_id, bs.name
  from bt_sets b, bt_states bs
 where bs.btst_id = b.btst_btst_id; 



-------------
DECLARE
  MAX_CLNT clients.clnt_id%type;
  MIN_CLNT clients.clnt_id%type;
BEGIN
  PACK_BILLING_TASK_BGI.BT_INIT(P_CHEK_STATE => 0);
  for cur in (select blcl_id, blgr_blgr_id
                from bill_cycles
               where cycle_date = to_date('31.12.2018 23:59:59', 'DD.MM.YYYY HH24:MI:SS')
                 and bct_bct_id = 1
                 and clst_clst_id = 3 and blcl_id=181231000001369) loop
    select min(clnt_clnt_id), max(clnt_clnt_id)
      into MIN_CLNT, MAX_CLNT
      from client_histories
     where clnt_clnt_id between 67241 and 67241;
    pack_billing_task_bgi.g_PARALLEL := 1;
    PACK_BILLING_TASK_BGI.BT_ADD_TASK(P_BILL_DATE     => to_date('31.12.2018 23:59:59',
                                                                 'DD.MM.YYYY HH24:MI:SS'),
                                      P_BLCL_ID       => cur.blcl_id,
                                      P_PRIORITY      => 1,
                                      P_BRNC_ID       => 1609,
                                      P_BLGR_ID       => cur.blgr_blgr_id,
                                      P_AFKT_ID       => NULL,
                                      P_START_CLNT_ID => MIN_CLNT,
                                      P_END_CLNT_ID   => MAX_CLNT,
                                      P_START_ASSC_ID => NULL,
                                      P_END_ASSC_ID   => NULL,
                                      P_SETS_MAX      => 1000);
  end loop;
  PACK_BILLING_TASK_BGI.BT_ADD_IND;
END;

 
begin
  pack_billing_task_bgi.start_bgi_proccess(p_btts_id => 1922);
end; 




/* POSTING*/
begin
        bill_posting.start_bill_posting(190930000001909,
                                        0,
                                        1,
                                        0,
                                        NULL,
                                        67241,
                                        67241,
                                        50000,
                                        0);
UPDATE bill_cycles
SET clst_clst_id = 4
WHERE blcl_id = 190930000001909;
COMMIT; 
end;

select * From bill_cycles where blcl_id = 181231000001289

select * from charges where subs_subs_id in (select subs_id from subscribers where clnt_clnt_id = 67241)
select * from bills b where bill_id = 181202900004001

select * from charges where subs_subs_id = 233864;
select * from bills where bill_id in (select bill_bill_id from charges where subs_subs_id = 233864);

select * from bill_details b where b.bill_bill_id=181202900004001;
select * from bill_substractions t where t.bill_bill_id=181202900004001; 


and bill_id = 181202895002001

select st.name, s.* from bis.bt_sets s, bis.bt_states st where s.btst_btst_id = st.btst_id;


select * from bvd_discount_tables


select (select name from bvd_discount_tables t where BVDT_ID = bvdt_bvdt_id) name_r, t.bvdt_bvdt_id, DETG_DETG_ID, tt.clnt_clnt_id, 
count(tt.CLNT_CLNT_ID) OVER (PARTITION BY DETG_DETG_ID) COUNT_DETG,
count(t.CLNT_CLNT_ID) OVER (PARTITION BY BVDT_BVDT_ID) COUNT_BVDT_BVDT_ID,
tt.* from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where t.clnt_clnt_id in (select t.clnt_clnt_id from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173')
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
--and t.navi_user like 'PS_MIGR173'
and bill_bill_id is not null
order by COUNT_BVDT_BVDT_ID desc

select * from bill_details b 
where bill_bill_id in (select tt.bill_bill_id from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where 1=1--clnt_clnt_id in (select t.clnt_clnt_id from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173')
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
--and t.navi_user like 'PS_MIGR173'
and bill_bill_id is not null
)
and detg_detg_id = 62901



select * from bvd_bvvd_detg
where detg_detg_id in (select detg_detg_id from bill_details b 
where bill_bill_id in (select tt.bill_bill_id from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where 1=1--clnt_clnt_id in (select t.clnt_clnt_id from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173')
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
--and t.navi_user like 'PS_MIGR173'
and bill_bill_id is not null
))


select * from subscribers where subs_id = 7160355
--397065
select * from bvd_clnt_bvdt where clnt_clnt_id = 397065



















