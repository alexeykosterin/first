create table aak_ma (clst_name varchar2(300), fake varchar2(300), id_name varchar2(300), name_r varchar2(300), id_number number(10))

drop table aak_ma

select * from aak_ma for update

select * from serv_lists where def like '%����%����������%'
select * from packs where name_r like '%350%'



SRLS_MTH	�������. ����. ����������	?
PACK	350 ����� (����� ������� �� ������� ��)	?
SRLS_MTH	������ ������������	?
RTPL	������ ������������	?
BNDL/STCK	������ ������������	?

SRLS_MTH	�������. ����. ���. ����. ��� ���������	978
SRLS_MTH	����. ����. ���. ���� � �����. ����	977



select * from serv_lists
select distinct * from aak_ma
where id_name like 'PACKAGE'
--164
select distinct id_name from aak_ma
PRCL
PACK
PACKAGE
SRLS
RTPL
SRLS_MTH



with t as (
select distinct 
(case when upper(id_name) like '%PRCL%' then (select def from price_list where id_number = prcl_id) 
when upper(id_name) like '%PACK%' then (select name_r from packs where id_number = pack_id)
when upper(id_name) like '%PACKAGE%' then (select name_r from packs where id_number = pack_id)
when upper(id_name) like '%SRLS%' then (select def from serv_lists where id_number = srls_id)
when upper(id_name) like '%RTPL%' then (select name_r from rate_plans where id_number = rtpl_id)
when upper(id_name) like '%SRLS%MTH%' then (select def from serv_lists where id_number = srls_id)
end) as PP,
a.* from aak_ma a)
select * from t
where PP is not null



--select PP as BIS_BD, NAME_R as MAPPING, a.id_name, a.id_number  from t a where PP != name_r


select * from serv_lists where srls_id in (977, 978)
for update

select * from aak_ma where id_number in (977, 978)



truncate table aak_ma;
truncate table aak_ma2;


alter table aak_ma drop column clst_id varchar(10)

select * from aak_ma for update

select * from mth_clusters

create table aak_ma2 (clst_name varchar2(300), id_price varchar2(300), fake1 varchar2(300), fake2 varchar2(300), fake3 varchar2(300), price number(10,5))

select * from aak_ma2 for update



select clst_name, id_price, price from aak_ma2
where price is not null
and price != 0 
for update

select regexp_SUBSTR(clst_name,'[^;]+',1,2,'i') from aak_ma2
where price is not null
and price != 0 




select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,2,'i'),';',','), '[[:space:]]+', '') from aak_ma2
where price is not null
and price != 0


with digit_str as (
select '�-���-1' as str from dual
)
select regexp_substr(str, '([^,]+)(,|$)', 1, rownum, 'c', 1) ok
from digit_str
connect by level <= regexp_count(str, '[^,]+(,|$)')


create table aak_test (clst_id varchar2(300), name_1 varchar2(300), id_price varchar2(300), price number(10,5))


alter table aak_test add id_price varchar2(300)
alter table aak_test add price number(10,5)
alter table aak_test drop column price



select max(length(regexp_replace(clst_name,'[^;]','',1,0,'i')))+1 from aak_ma2;
---+++++++++++++++++++++
with table_c as (
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,1,'i'),';',','), '[[:space:]]+', '') as A, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,2,'i'),';',','), '[[:space:]]+', '') as B, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,3,'i'),';',','), '[[:space:]]+', '') as B, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,4,'i'),';',','), '[[:space:]]+', '') as B, ID_PRICE, PRICE from aak_ma2
where price is not null)
select rownum Numbe, cc.* from table_c cc where A is not null

-------
with t as (
select distinct 
(case when upper(id_name) like '%PRCL%' then (select def from price_list where id_number = prcl_id) 
when upper(id_name) like '%PACK%' then (select name_r from packs where id_number = pack_id)
when upper(id_name) like '%PACKAGE%' then (select name_r from packs where id_number = pack_id)
when upper(id_name) like '%SRLS%' then (select def from serv_lists where id_number = srls_id)
when upper(id_name) like '%RTPL%' then (select name_r from rate_plans where id_number = rtpl_id)
when upper(id_name) like '%SRLS%MTH%' then (select def from serv_lists where id_number = srls_id)
end) as PP,
a.* from aak_ma a)
select * from t
join
(with table2 as (select rownum Numbe, regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,1,'i'),';',','), '[[:space:]]+', '') as A, ID_PRICE, PRICE from aak_ma2
where price is not null
--and price != 0
union all 
select rownum+6 Numbe, regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,2,'i'),';',','), '[[:space:]]+', '') as A, ID_PRICE, PRICE from aak_ma2
where price is not null
--and price != 0
) select * from table2 t) tt on tt.ID_PRICE =  CLST_NAME
join mth_clusters mm on mm.def = A
where PP is not null
order by id_price, clst_id

---+++++++++++++++++++++

select * from mth_tarif_histories 
where rtpl_rtpl_id = 211 and srls_srls_id in (1282,1337) 


select * From mth_clusters where def like '�-���-1%'


select * from aak_ma2 
for update;
select * from aak_ma 
for update;
truncate table aak_ma2;
truncate table aak_ma;
truncate table aak_test;


----------------
begin
  for rec in (select rownum Numbe, regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,2,'i'),';',','), '[[:space:]]+', '') as A, ID_PRICE, PRICE   from aak_ma2
where price is not null
and price != 0) loop
insert into aak_test 
with digit_str as (
select rec.A as str from dual
)
select regexp_substr(str, '([^,]+)(,|$)', 1, rownum, 'c',1) ok, rec.id_price, rec.price
from digit_str
connect by level <= regexp_count(str, '[^,]+(,|$)');
end loop;
commit;
end;
--------------

with digit_str as (
select (select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,2,'i'),';',','), '[[:space:]]+', '') as A from aak_ma2
where price is not null
and price != 0 and rownum =1) as str from dual
)
select regexp_substr(str, '([^,]+)(,|$)', 1, rownum, 'c',1) ok
from digit_str
connect by level <= regexp_count(str, '[^,]+(,|$)');


---278
select * from aak_ma2 where price is not null and price != 0

truncate table aak_test
select * from aak_test

select distinct B from aak_test



select rownum Numbe, regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^.]+',1,2,'i'),';',','), '[[:space:]]+', '') as A  from aak_ma2
where price is not null
and price != 0

----856
select CLST_ID, NAME_1, id_price, price from aak_test 
join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%')
where name_1 is not null
and clst_id between 1000 and 2000
------------------------------------------

with t as (
select CLST_ID, NAME_1, id_price, price from aak_test
join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%')
where name_1 is not null
and clst_id between 1000 and 2000
)
select distinct * from t,aak_ma
where clst_name = id_price
and ID_NAME not like 'SRLS'



select * from packs where pack_id = 3879

select * from mth_tarif_histories

-----------
declare 
v_cnt number(10);
v_cnt2 number(10);
v_cnt3 number(10);
v_cnt4 number(10);
begin
for rec in (select distinct clst_id from mth_clusters
where clst_id between 1000 and 2000) loop

for rec2 in (select distinct clst_name from aak_ma) loop

select count(1) into v_cnt3 from (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null and clst_id between 1000 and 2000)
select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name and clst_id = rec.clst_id and ID_NAME like '%PACK%');

for rec3 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name and clst_id = rec.clst_id
and ID_NAME like '%PACK%') loop
v_cnt3 := rec3.id_number;


for rec4 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name and clst_id = rec.clst_id
and ID_NAME like 'SRLS_MTH') loop

select count(1) into v_cnt2 from (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name
and clst_id = rec.clst_id and ID_NAME like 'RTPL'); 

if v_cnt2 = 0 then v_cnt := 0;
insert into aak_tarif_histories (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
v_cnt, v_cnt3, rec4.id_number, 0, 600, null, rec3.clst_id, 3, rec3.price, 'N', 'N', rec3.clst_name, to_date('01.07.2016','dd.mm.yyyy'), 
to_date('31.12.2099','dd.mm.yyyy'), 'AAK7', sysdate, 'N'
from dual;

else
for rec5 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS'
and clst_name like rec2.clst_name and clst_id = rec.clst_id and ID_NAME like 'RTPL'
) loop

insert into aak_tarif_histories (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
rec5.id_number, v_cnt3, rec4.id_number, 0, 600, null, rec3.clst_id, 3, rec3.price, 'N', 'N', rec3.clst_name, to_date('01.07.2016','dd.mm.yyyy'), 
to_date('31.12.2099','dd.mm.yyyy'), 'AAK7', sysdate, 'N'
from dual;

end loop;
end if;
end loop;
end loop;
end loop;
end loop;
end;
-----------------------2---------

declare 
v_cnt number(10);
v_cnt2 number(10);
v_cnt3 number(10);
v_cnt4 number(10);
begin
for rec in (select distinct clst_id from mth_clusters
where clst_id between 1000 and 2000) loop
for rec2 in (select distinct clst_name from aak_ma) loop
for rec3 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name and clst_id = rec.clst_id
and ID_NAME like '%SRLS_MTH') loop
select count(1) into v_cnt3 from (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null and clst_id between 1000 and 2000)
select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name and clst_id = rec.clst_id and ID_NAME like '%PACK%');
if v_cnt3 = 0 then v_cnt4 := 0;
select count(1) into v_cnt2 from (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name
and clst_id = rec.clst_id and ID_NAME like 'RTPL'); 
if v_cnt2 = 0 then v_cnt := 0;
insert into aak_tarif_histories2 (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
v_cnt, v_cnt4, rec3.id_number, 0, 600, null, rec3.clst_id, 3, rec3.price, 'N', 'N', rec3.clst_name, to_date('01.07.2016','dd.mm.yyyy'), 
to_date('31.12.2099','dd.mm.yyyy'), 'AAK7', sysdate, 'N'
from dual;
else
for rec5 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS'
and clst_name like rec2.clst_name and clst_id = rec.clst_id and ID_NAME like 'RTPL'
) loop
insert into aak_tarif_histories2 (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
rec5.id_number, v_cnt4, rec3.id_number, 0, 600, null, rec3.clst_id, 3, rec3.price, 'N', 'N', rec3.clst_name, to_date('01.07.2016','dd.mm.yyyy'), 
to_date('31.12.2099','dd.mm.yyyy'), 'AAK7', sysdate, 'N'
from dual;
end loop;
end if;
else
for rec4 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name and clst_id = rec.clst_id
and ID_NAME like 'PACK%') loop
v_cnt4 := rec4.id_number;
select count(1) into v_cnt2 from (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS' and clst_name like rec2.clst_name
and clst_id = rec.clst_id and ID_NAME like 'RTPL'); 
if v_cnt2 = 0 then v_cnt := 0;
insert into aak_tarif_histories2 (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
v_cnt, v_cnt4, rec3.id_number, 0, 600, null, rec3.clst_id, 3, rec3.price, 'N', 'N', rec3.clst_name, to_date('01.07.2016','dd.mm.yyyy'), 
to_date('31.12.2099','dd.mm.yyyy'), 'AAK7', sysdate, 'N'
from dual;
else
for rec5 in (with t as (select CLST_ID, NAME_1, id_price, price from aak_test join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%') where name_1 is not null
and clst_id between 1000 and 2000) select distinct * from t,aak_ma where clst_name = id_price and ID_NAME not like 'SRLS'
and clst_name like rec2.clst_name and clst_id = rec.clst_id and ID_NAME like 'RTPL'
) loop
insert into aak_tarif_histories2 (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
rec5.id_number, v_cnt4, rec3.id_number, 0, 600, null, rec3.clst_id, 3, rec3.price, 'N', 'N', rec3.clst_name, to_date('01.07.2016','dd.mm.yyyy'), 
to_date('31.12.2099','dd.mm.yyyy'), 'AAK7', sysdate, 'N'
from dual;
end loop;
end if;
end loop;
end if;
end loop;
end loop;
end loop;
commit;
end;

----------------------Webstream
select * from aak_test
select * from aak_ma
select * from aak_ma2



begin
for rec2 in (select srls_id from serv_lists where srls_id in (210,211,212)) loop
for rec in (
with t as (
select CLST_ID, NAME_1, id_price, price from aak_test
join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%')
where name_1 is not null
and clst_id between 1000 and 2000
)
select distinct * from t,aak_ma
where clst_name = id_price
and ID_NAME like 'PACK%'
and id_number in (select pack_id from packs where navi_user like '%AAK%' and name_r like 'Webst%')
) loop
insert into aak_tarif_histories (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, comments, start_date, end_date, navi_user, navi_date, tarif_modify)
select 
217, rec.id_number, rec2.srls_id, 0, 600, null, rec.clst_id, 3, rec.price, 'N', 'N', rec.name_r||' '||rec.id_price, to_date('01.07.2016','dd.mm.yyyy'), to_date('31.12.2099','dd.mm.yyyy'), 'AAK', sysdate, 'N'
from dual;
end loop;
end loop;
end;


select * From aak_tarif_histories
select * from mth_tarif_histories where navi_user like 'AAK%'

insert into mth_tarif_histories
select * From aak_tarif_histories
select * from standarts


 
select * from subscribers where subs_id = 4859934
for update


select * from packs where pack_id = 3524

select * from trafics_by_directions where pack_pack_id = 305

select * from subs_histories where subs_subs_id = 4859934
select * from subs_packs where subs_subs_id = 4859934
select * from charges where clnt_clnt_id in 
(select clnt_clnt_id from subscribers where subs_id = 4859934)
select * from pack_rtpl where rtpl_rtpl_id = 171
for update
select * from serv_histories where subs_subs_id = 4859934
begin
  bis_engine.order_pack_service(psubs_id => 4859934, ppack_id => 504,operation_date => sysdate);
end;
begin
bis_month_charge.bis_subs_charges(startdate => to_date('01.09.2018','dd.mm.yyyy'), enddate => to_date('30.09.2018','dd.mm.yyyy'),subsid => 4859934);
end;

select * from charges where clnt_clnt_id in 
(select clnt_clnt_id from subscribers where subs_id = 4859934)
for update

select * from rate_plans where rtpl_id = 171 
for update
9996

select * from standarts

where rtpl_rtpl_id = 0
for update

95 - 301208
96
91
92



order by amount, clst_clst_id
for update


select * from serv_lists where srls_id in (210,211,212)



select (select name_r from packs where pack_id = pack_pack_id), p.* from aak_tarif_histories p
where navi_user like 'AAK7'


select * from packs where pack_id = 3721


select * from aak_ma where clst_name like '�-00023'

with t as (
select CLST_ID, NAME_1, id_price, price from aak_test
join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%')
where name_1 is not null
and clst_id between 1000 and 2000
)
select distinct * from t,aak_ma
where clst_name = id_price
and ID_NAME not like 'SRLS'




and ID_NAME not like 'RTPL'


with t as (
select CLST_ID, NAME_1, id_price, price from aak_test
join mth_clusters on lower(NAME_1) like ('%' || lower(DEF) || '%')
where name_1 is not null
and clst_id between 1000 and 2000
)
select distinct * from t,aak_ma
where clst_name = id_price
and ID_NAME not like 'SRLS'


and clst_name = '�-00012'
and clst_id = 1003
and ID_NAME like 'RTPL'
