/*
&bid=201909
&bath_id=2702
*/
WITH bl AS
 (
  
  SELECT bl.account
         ,bl.user_id
         ,bl.clnt_clnt_id ext_clnt_id
         ,cm.clnt_clnt_id clnt_id
  FROM rtk_migr_batch_lists@nsk4al bl
  LEFT JOIN bis.clnt_migration cm ON cm.ext_clnt_id = bl.clnt_clnt_id
                                     AND cm.mist_mist_id IN (2, 4)
  WHERE bl.batch_batch_id = &bath_id
        AND bl.fin_export_status = 'OK'
        AND (('ALL' = 'ALL' /*&pALL*/
        ) OR (cm.clnt_clnt_id IS NULL))
--  AND bl.account='654000009248' 
  ),

discounts_bis AS
 (SELECT bl.account
        ,bl.clnt_id
        ,dt.name bvdt_bvdt_id_name
        ,bd.detg_detg_id
         
        ,0 strt_amount_disc_$
        ,SUM((bd.amount_$_orig - bd.amount_$)) bis_amount_disc_$
  FROM bills b
  INNER JOIN bl ON b.clnt_clnt_id = bl.clnt_id
                   AND b.bltp_bltp_id <> 0
  INNER JOIN bvd_clnt_bvdt bdc ON bl.clnt_id = bdc.clnt_clnt_id
                                  AND bdc.start_date <= b.old_date
  INNER JOIN bvd_discount_table_histories bdh ON bdh.bvdt_bvdt_id =
                                                 bdc.bvdt_bvdt_id
                                                 AND bdh.start_date <=
                                                 b.old_date
  INNER JOIN bvd_bvdh_detg bbg ON bbg.bvdh_bvdh_id = bdh.bvdh_id
  INNER JOIN bvd_discount_tables dt ON dt.bvdt_id = bdc.bvdt_bvdt_id
  INNER JOIN bill_details bd ON bd.bill_bill_id = b.bill_id
                                AND bd.detg_detg_id = bbg.detg_detg_id
                                AND bd.subs_subs_id IS NULL
  
  WHERE 1 = 1
        AND to_char(b.old_date, 'yyyymm') = &bid
  GROUP BY bl.account, bl.clnt_id, dt.name, bd.detg_detg_id
  
  ),

discounts_strt AS
 (SELECT a.name_user
        ,a.account
        ,a.clnt_id
        ,a.svc_id
        ,a.strt_name_svc
        ,a.strt_disc_id
        ,a.strt_name_disc
        ,SUM((SELECT SUM(c.total)
             FROM cpa_charge@nsk4al c
             WHERE c.user_id = a.user_id
                   AND c.svc_id = a.svc_id
                   AND c.bid = a.billing_id
                   AND c.charge_kind = 'ch')) strt_sum_charges
        ,SUM(sum_skidka) strt_sum_discounts
        ,a.dsc_type strt_dsc_type
  
  FROM (SELECT dr.billing_id
              ,u.user_id
              ,u.account
              ,bl.clnt_id
              ,u.name name_user
              ,u.iscorp
              ,svc.svc_id
              ,svc.name AS strt_name_svc
              ,d.discount_id strt_disc_id
              ,d.name strt_name_disc
              ,SUM(dr.summ) sum_skidka
              ,1 dsc_type
        FROM t_discounts_result@nsk4al dr
        INNER JOIN t_discounts@nsk4al d ON dr.discount_id = d.discount_id
        INNER JOIN bl bl ON bl.user_id = dr.user_id
        INNER JOIN t_users@nsk4al u ON u.user_id = dr.user_id,
         t_svc_ref@nsk4al svc,
         t_tax_tarif_ref@nsk4al ttr
        WHERE 1 = 1
              AND dr.billing_id = &bid
              AND ttr.user_type_id = nvl(u.user_type_id, u.user_type_id)
              AND last_day(to_date(&bid, 'yyyymm')) BETWEEN ttr.date_begin AND
              nvl(ttr.date_end, last_day(to_date(&bid, 'yyyymm')))
        GROUP BY dr.billing_id
                ,u.user_id
                ,u.account
                ,bl.clnt_id
                ,u.name
                ,u.iscorp
                ,svc.svc_id
                ,svc.name
                ,svc.isconst
                ,d.discount_id
                ,d.name
        
        UNION ALL
        
        SELECT sc.billing_id
              ,u.user_id
              ,u.account
              ,bl.clnt_id
              ,u.name name_user
              ,u.iscorp
              ,svc.svc_id
              ,svc.name AS strt_name_svc
              ,d.discount_id strt_disc_id
              ,d.name strt_name_disc
              ,SUM(sc.summ) sum_skidka
              ,2 dsc_type
        FROM t_svc_correction@nsk4al sc
        INNER JOIN bl bl ON bl.user_id = sc.user_id, t_discounts@nsk4al d,
         t_users@nsk4al u, t_svc_ref@nsk4al svc,
         t_tax_tarif_ref@nsk4al ttr
        WHERE 1 = 1
              AND u.user_id = sc.user_id
              AND sc.billing_id = &bid
              AND sc.info = '������ ' || d.name
              AND sc.svc_id = svc.svc_id
              AND ttr.user_type_id = nvl(u.user_type_id, u.user_type_id)
              AND last_day(to_date(&bid, 'yyyymm')) BETWEEN ttr.date_begin AND
              nvl(ttr.date_end, last_day(to_date(&bid, 'yyyymm')))
              AND NOT EXISTS (SELECT 1
               FROM stc_dsc_calc_list@nsk4al cl
               WHERE cl.billing_id = &bid
                     AND cl.corr_id = sc.corr_id)
              AND NOT EXISTS (SELECT 1
               FROM t_discounts_result@nsk4al dr
               WHERE dr.billing_id = &bid
                     AND dr.user_id = sc.user_id
                     AND dr.svc_id = sc.svc_id)
        GROUP BY sc.billing_id
                ,u.user_id
                ,u.account
                ,bl.clnt_id
                ,u.name
                ,u.iscorp
                ,svc.svc_id
                ,svc.name
                ,svc.isconst
                ,d.discount_id
                ,d.name
        
        UNION ALL
        
        SELECT stc_dsc_kernel.fGetGoalBillingId@nsk4al(dcl.dsci_id) billing_id
              ,u.user_id
              ,u.account
              ,bl.clnt_id
              ,u.name name_user
              ,u.iscorp
              ,svc.svc_id
              ,svc.name AS strt_name_svc
              ,ddr.discount_id strt_disc_id
              ,ddr.name strt_name_disc
              ,SUM(dcl.dsc_summ * ((ttr.value + 100) / 100)) sum_skidka
              ,3 dsc_type
        FROM stc_dsc_calc_list@nsk4al dcl
        INNER JOIN bl bl ON bl.user_id = dcl.user_id,
         stc_dsc_discounts_ref@nsk4al ddr,
         t_svc_correction@nsk4al sc, t_users@nsk4al u,
         t_svc_ref@nsk4al svc, t_tax_tarif_ref@nsk4al ttr
        WHERE 1 = 1
              AND u.user_id = dcl.user_id
              AND dcl.billing_id = &bid
              AND dcl.discount_id = ddr.discount_id
              AND dcl.corr_id = sc.corr_id
              AND sc.svc_id = svc.svc_id
              AND ttr.user_type_id = nvl(u.user_type_id, u.user_type_id)
              AND last_day(to_date(&bid, 'yyyymm')) BETWEEN ttr.date_begin AND
              nvl(ttr.date_end, last_day(to_date(&bid, 'yyyymm')))
        GROUP BY stc_dsc_kernel.fGetGoalBillingId@nsk4al(dcl.dsci_id)
                ,u.user_id
                ,u.account
                ,bl.clnt_id
                ,u.name
                ,u.iscorp
                ,svc.svc_id
                ,svc.name
                ,svc.isconst
                ,ddr.discount_id
                ,ddr.name
        
        ) a
  GROUP BY a.name_user
          ,a.account
          ,a.clnt_id
          ,a.svc_id
          ,a.strt_name_svc
          ,a.strt_disc_id
          ,a.strt_name_disc
          ,a.dsc_type),

discounts AS
 (SELECT d.account
        ,d.clnt_id
        ,d.strt_name_disc     bvdt_bvdt_id_name
        ,dg.detg_id           detg_detg_id
        ,d.strt_sum_discounts strt_amount_disc_$
        ,0                    bis_amount_disc_$
  FROM discounts_strt d
  INNER JOIN detail_groups@nsk4al dg ON dg.svc_id = d.svc_id
  WHERE 1 = 1
  UNION ALL
  SELECT db.*
  FROM discounts_bis db)
-- compare
SELECT d.account
      ,d.clnt_id
      ,d.bvdt_bvdt_id_name
      ,d.detg_detg_id
      ,SUM(d.strt_amount_disc_$) strt_amount_disc_$
      ,SUM(d.bis_amount_disc_$) bis_amount_disc_$
      ,SUM(d.strt_amount_disc_$) - SUM(d.bis_amount_disc_$) err_$
FROM discounts d
GROUP BY d.account, d.clnt_id, d.bvdt_bvdt_id_name, d.detg_detg_id
ORDER BY d.account, d.clnt_id, d.bvdt_bvdt_id_name, d.detg_detg_id

--SELECT * FROM discounts_strt
