
-----[][][][][][][][][][][][]




select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate
----4605


select count(1) from aak_number_pool_values;
--40780
select count(1) from aak_number_pool;
--5751

---����������� ��� � IUM 1147
select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate);
----1146

--select value_1, value_2 from aak_number_pool_values where end_date > sysdate and uniq_id not in (select number_id From aak_tmp) and value_1 not like 'D%'
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 not like 'D%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate);
----35791


drop table aak_number_pool_tmp


create table aak_number_pool_tmp as 
with t as (
 select (case when beginn like '7%' then substr(beginn,2) end) beg From aak_number_pool
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg From aak_number_pool
INTERSECT
select distinct value_1 from aak_number_pool_values where end_date > sysdate)
union all
select (case when endd like '7%' then substr(endd,2) end) beg From aak_number_pool
minus
(select (case when endd like '7%' then substr(endd,2) end) beg From aak_number_pool
INTERSECT
select distinct value_2 from aak_number_pool_values where end_date > sysdate)
          ),
     x as (
           select  regexp_replace(beg,'\d+$') alpha,
                   to_number(regexp_replace(beg,'^[[:alpha:]]+')) num
             from  t
             where beg is not null
          ),
     y as (
           select  num,
                   alpha || (num - row_number() over(partition by alpha order by num)) grp
             FROM  x
          )
select  --rtrim(xmlagg(xmlelement(i,min(alpha) || min(num) || '-' || min(alpha) || max(num),',').extract('//text()') order by grp),',') grp_list
num, grp, count(num) OVER (PARTITION BY grp) count_num  
from y
--group by grp

--create table aak_number_pool_2 as select * from aak_number_pool where 1=2
---create table aak_number_pool_2 as select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool

---drop table aak_number_pool_2
select * from aak_number_pool_2
select * from aak_number_pool_tmp

select min(num), max(num) from aak_number_pool_tmp where count_num > 1
group by grp


----��� 1
begin 
  for rec in (with t as (select min(num) a , max(num) b from aak_number_pool_tmp where count_num > 1 group by grp) select * from t) loop
    execute immediate 'update aak_number_pool_2 set en = '|| rec.b ||' where en between '|| rec.a||' and '||rec.b;
    execute immediate 'update aak_number_pool_2 set beg = '||rec.b ||' where beg between '|| rec.a||' and '||rec.b;
  end loop;
end;

3812220000  3812220107
3812220108  3812220108
3812220109  3812220110
3812220111  3812220111
3812220112  3812271999

3812220000  3812220112
3812220112  3812220112
3812220112  3812220112
3812220112  3812220112
3812220112  3812271999

select distinct * from aak_number_pool_2 order by beg

begin
  for rec in (select distinct * from aak_number_pool_2 order by beg) loop
    
  for rec1 in (select distinct beg from aak_number_pool_2 where beg = rec.en) loop
      execute immediate 'update aak_number_pool_2 set beg = '||rec.beg||' where beg = '||rec.en;
  end loop;
  end loop;
end;

3812220000  3812220112
3812220000  3812271999

select distinct beg, max(en) from aak_number_pool_2
group by beg
order by beg

3812220000  3812271999

select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate;
---4605

with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select * from t 
join aak_number_pool_values on beg = value_1
where en = value_2
---4838



select * from aak_number_pool_values 
where uniq_id not in (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select uniq_id from t 
join aak_number_pool_values on beg = value_1
where en = value_2);
--35886
select * from aak_number_pool_2;
--5751


select distinct * from aak_number_pool_2 where beg like '381%' and beg between
'3812289000' and  '3812289299'


select * from aak_number_pool_2 
outer join (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select value_1, value_2 from t 
join aak_number_pool_values on beg = value_1
where en = value_2) t  on beg = t.value_1
where en != t.value_2
;
---35 ������� � ������� EN > VALUE_2

drop table aak_number_pool_values
create table aak_number_pool_values as select * from number_pool_values


begin
  for rec in (select * from aak_number_pool_2 
outer join (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select value_1, value_2 from t 
join aak_number_pool_values on beg = value_1
where en = value_2) t  on beg = t.value_1
where en != t.value_2) loop
    if (rec.beg = rec.value_1 and rec.en < rec.value_2 )then
      execute immediate 'update aak_number_pool_2 set en = '|| rec.value_2||' where beg = '|| rec.beg;
    elsif (rec.beg = rec.value_1 and rec.en > rec.value_2 ) then
      execute immediate 'update aak_number_pool_values set value_2 = '|| rec.en||' where value_1 = '|| rec.beg;---�������� �� number_pool
    end if;
  end loop;
end;

---��������� ��� 35 �������
select * from aak_number_pool_2 
outer join (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select value_1, value_2 from t 
join aak_number_pool_values on beg = value_1
where en = value_2) t  on beg = t.value_1
and en != t.value_2
--and beg like '3816554100'
---��������� = �����

---��������������� ������, ���� ���������
select * from aak_number_pool_2 as of scn timestamp_to_scn(sysdate-INTERVAL '1000' SECOND)

select * from aak_number_pool_2 for update

select (sysdate-INTERVAL '900' SECOND) from dual


---������� 50 �������, ������� ��� � aak_number_pool_values
select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate)


---13 �������, � ������� ��������� VALUE_2 � EN, �� ������ BEGIN
with t as (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate))
select * from t
join aak_number_pool_values on en = value_2
and beg != value_1


begin
  for rec in (with t as (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate))
select * from t
join aak_number_pool_values on en = value_2
and beg != value_1) loop
if rec.beg > rec.value_1 then
    execute immediate 'update aak_number_pool_2 set beg = '|| rec.value_1 ||' where en = '||rec.value_2;
end if;
  end loop;
end;

---������� 37 �������, ������� ��� � aak_number_pool_values
select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate)


3812366914  3812370005
3812360000  3812377999



select * from aak_number_pool_values where end_date > sysdate
and '3812366914' between value_1 and value_2

begin
  for rec in (with t as (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate))
select * from t
join aak_number_pool_values on beg = value_1
and en != value_2) loop
    if (rec.beg = rec.value_1 and rec.en < rec.value_2) then
      execute immediate 'update aak_number_pool_2 set en = '|| rec.value_2 ||' where beg ='|| rec.beg;
    elsif (rec.beg = rec.value_1 and rec.en > rec.value_2) then
      execute immediate 'update aak_number_pool_values set value_2 = '||rec.en||' where to_char(value_1) = to_char('||rec.value_1||')';--�������� �� number_pool
    end if;
  end loop;
end;


select distinct count(1) from aak_number_pool_values;
select distinct count(1) from back_number_pool_values;
select distinct count(1) from number_pool_values;

select * from aak_number_pool_values
join aak_number_pool_2 on beg = value_1
where en = value_2
---5751 �����, ������� 5554
----��� 195 ����� ���������� � number_pool_values
select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate)


select count(1) from aak_number_pool_values t2
join number_pool_values t on t.value_1 = t2.value_1
and t.value_2 = t2.value_2
and t.value_1 not like 'D%'
---40349

select * from aak_number_pool_values;
select * from number_pool_values;

create table back_number_pool_values as select * from number_pool_values;
truncate table number_pool_values;

insert into number_pool_values (
npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date, navi_user, navi_date, uniq_id)
select * from aak_number_pool_values;

select * from aak_number_pool_values where uniq_id not in (
select t.uniq_id from aak_number_pool_values t2
join number_pool_values t on t.value_1 = t2.value_1
and t.value_2 = t2.value_2
and t.value_1 not like 'D%')


3023630000	3023639999
3023630000	3023630879

select * from number_pool_values where uniq_id = 1003

declare
v_uniq_seq number(10);
begin
  for rec in (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate)) loop
select max(uniq_id) into v_uniq_seq from number_pool_values;
v_uniq_seq := v_uniq_seq+1;
    insert into aak_number_pool_values (npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date, navi_user, navi_date, uniq_id)
    select 1,2,0,null,rec.beg, rec.en,to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'),'BIS',trunc(sysdate),v_uniq_seq from dual;
  end loop;
end;

select * from dba_objects where object_type like 'SEQ%' and object_name like '%UN%'




