
with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select * from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rpdr_id in (
select distinct rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
and rw = min_rw




select * from rate_plan_directions where navi_user like '%����2063%'


--------------
delete from matrix_dir_histories where rpdr_rpdr_id in (
with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rpdr_id in (
select distinct rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
and rw <> min_rw
)

--------------
delete from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rpdr_id in (
select distinct rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
and rw <> min_rw
)
------------
---638
---�� 319 46516
---16506 8523
delete from matrix_dir_histories
where rpdr_rpdr_id in (
with table1 as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate))
select rpdr_id from table1 t where count_id = 5
and mtxl_mtxl_id not in (1,3)
and rpdr_id not in (
select rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
and rw <> min_rw
)


delete from rate_plan_directions where rpdr_id in 
(
with table1 as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate))
select rpdr_id from table1 t where count_id = 2
and mtxl_mtxl_id not in (1,3)
and rpdr_id not in (
select rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
and rw = min_rw
)



with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select * from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rw <> min_rw

delete from matrix_dir_histories where rpdr_rpdr_id in (with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rw <> min_rw)



select * from trafics_by_directions where rpdr_rpdr_id in (with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rw = min_rw)

delete from rate_plan_directions where rpdr_id in (with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rw <> min_rw)


---359
421
select * from rate_plan_directions where navi_user like '%2063%'
and rpdr_id not in (select rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where navi_user like '%2063%'))





