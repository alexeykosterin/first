select * from rtpl_srls_substitution where result_rtpl_id = 228 and end_date > sysdate;
select * From rate_plans where rtpl_id in (228,448,558);
select * from time_classes where rtpl_rtpl_id in (228);
select * From tarif_histories where rtpl_rtpl_id in (228) and end_date > sysdate;
select * From trafic_histories where rtpl_rtpl_id in (228) and end_date > sysdate;
select * from trafics_by_directions where end_date > sysdate and rtpl_rtpl_id = 228;
select * from link_mtrx_histories where end_date > sysdate and rtpl_rtpl_id = 228;
select * from pack_rtpl where rtpl_rtpl_id = 228;
select * from aak_tmcl_rtpl;


---1)


begin
  for rec_rtpl in (with digit_str as (
  select '448,558' as str
  from  dual
)
select regexp_substr(str, '(\d+)(,|$)', 1, rownum, 'c', 1) rtpl_id
from digit_str
connect by level <= regexp_count(str, '\d+(,|$)')) loop
  for rec in (select * from rtpl_srls_substitution where result_rtpl_id = 228 and end_date > sysdate) loop
    insert into rtpl_srls_substitution (srls_srls_id, source_rtpl_id, result_rtpl_id, start_date, end_date, navi_user, navi_date)
    select rec.srls_srls_id,rec.source_rtpl_id,rec_rtpl.rtpl_id,rec.start_date,rec.end_date,'AAK',trunc(sysdate) from dual;
  end loop;
  end loop;
end;



select * from serv_lists where srls_id in (104,105)

select * from pack_rtpl where pack_pack_id = 279

select * FROM RMS_ATTRIBUTE_VALUES




