declare
v_cnt number(10,5);
table_not_exists exception;
pragma exception_init(table_not_exists,-942);
begin
  for rec10 in (select distinct pack_id from aak_all_1) loop
execute immediate 'drop table aak_vsp purge';
execute immediate 'create table aak_vsp as
select distinct * from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and pack_id = '||rec10.pack_id||' and zone_id = 2';
for rec11 in (select distinct rpdr_rpdr_id, drct_drct_id,d.price_avt, price_zak, d.pack_id from rate_plan_directions rd 
inner join matrix_dir_histories on rpdr_id = rpdr_rpdr_id
inner join aak_vsp d on d.rpdr_id = rpdr_rpdr_id
where rd.mtxl_mtxl_id = 3 and rd.rpdr_id in (select distinct rpdr_id from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and zone_id = 2 and pack_id = rec10.pack_id)) loop
dbms_output.put_line(rec11.rpdr_rpdr_id||' '||rec10.pack_id);
for rec1 in (select * from time_classes where rtpl_rtpl_id = 228) loop
for rec3 in (select * from logic_calls where lcal_id in (5,6)) loop
for rec4 in (select * from serv_lists where srls_id in (104,105)) loop
if rec4.srls_id = 104 then
select rec11.price_avt into v_cnt from dual;
end if;
if rec4.srls_id = 105 then
select rec11.price_zak into v_cnt from dual;
end if;
insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select 
rec1.tmcl_id, 1, v_cnt, 2, rec11.drct_drct_id, rec11.rpdr_rpdr_id, null, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 1, 1, 
rec3.lcal_id, 
0, 'Y', null, null, rec4.srls_id, 0, null, null, null, null, null, rec10.pack_id, null, 
0, null, 60899, 100100, null, 228
from dual;
  end loop;
  end loop;
  end loop;
  end loop;
end loop;
exception 
when table_not_exists then null;
end;

---��������

---193256
select distinct pack_pack_id from aak_back ---59
select distinct pack_id from aak_all_1 ---62

select count(1), pack_pack_id from trafics_by_directions where pack_pack_id in (select distinct pack_id from aak_all_1)
and navi_date = trunc(sysdate)
group by pack_pack_id 

--341

select * from trafics_by_directions where pack_pack_id = 341
select * from aak_all_1 where pack_id = 341

select count(1), pack_pack_id from aak_back where pack_pack_id in (select distinct pack_id from aak_all_1)
group by pack_pack_id 

select count(1) from trafics_by_directions where navi_date = trunc(sysdate)
select * from aak_vsp

select distinct rpdr_rpdr_id, drct_drct_id,d.price_avt, price_zak, d.pack_id from rate_plan_directions rd 
inner join matrix_dir_histories on rpdr_id = rpdr_rpdr_id
inner join aak_vsp d on d.rpdr_id = rpdr_rpdr_id
where rd.mtxl_mtxl_id = 3 and rd.rpdr_id in (select distinct rpdr_id from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and zone_id = 2 and pack_id = 480)

select distinct rpdr_rpdr_id, drct_drct_id,d.price_avt, price_zak, d.pack_id from rate_plan_directions rd 
inner join matrix_dir_histories on rpdr_id = rpdr_rpdr_id
inner join aak_vsp d on d.rpdr_id = rpdr_rpdr_id
where rd.mtxl_mtxl_id = 3 and rd.rpdr_id in (select distinct rpdr_id from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and zone_id = 2 and pack_id = 277)



2)
select distinct rpdr_rpdr_id, drct_drct_id,d.price_avt, price_zak, d.pack_id from rate_plan_directions rd 
inner join matrix_dir_histories on rpdr_id = rpdr_rpdr_id
inner join aak_vsp d on d.rpdr_id = rpdr_rpdr_id
where rd.mtxl_mtxl_id = 3 and rd.rpdr_id in (select distinct rpdr_id from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and zone_id = 2 and pack_id = 277)

1) ������� ��������������� ��������
create table aak_vsp as
select distinct * from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and zone_id = 2 and pack_id = 277


3) �������

--create table aak_back as
select * from trafics_by_directions where pack_pack_id in (select distinct pack_id from aak_all_1)
and rpdr_rpdr_id in (select rpdr_id from aak_vsp)
and drct_drct_id in (
select distinct drct_drct_id from rate_plan_directions rd 
inner join matrix_dir_histories on rpdr_id = rpdr_rpdr_id
inner join aak_vsp d on d.rpdr_id = rpdr_rpdr_id
where rd.mtxl_mtxl_id = 3 and rd.rpdr_id in (select distinct rpdr_id from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and mtxl_mtxl_id = 3 and zone_id = 2 and pack_id in (select distinct pack_id from aak_all_1)))

