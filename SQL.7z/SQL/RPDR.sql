select * from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate;

--select * from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate);

select * from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
order by name_1;

�� 101 �� 600 �� ABC --0
�� 3001 �� 5000 �� ABC --1120
�� 3001 �� 5000 �� DEF --2752
�� 601 �� 1200 �� ABC  --1996
�� 1201 �� 3000 �� ABC --1368
�� 1201 �� 3000 �� DEF --3768
�� 601 �� 1200 �� DEF --3728
�� 101 �� 600 �� DEF --104
����� 5000 �� ABC --8
---14844

select * from trafics_by_directions where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
--and name_1 like '����� 5000 �� ABC'
)
and end_date > sysdate
;
 
select * from (
with t as (
SELECT 
(select name_1 from rate_plan_directions where rpdr_rpdr_id = rpdr_id) name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id
FROM trafics_by_directions
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
)
and end_date > sysdate)
select name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id,
count(1) OVER (PARTITION BY tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,name_rpdr) as_count
from t 
order by as_count,price_$ desc)
where pack_pack_id = 424
;

select * from trafics_by_directions where rpdr_rpdr_id in (47789,47702)
select * from matrix_dir_histories








---------------

declare
p_pack number(10) := 424;
v_cnt number(10);
v_cnt2 number(10);
begin
  for rec in (
select distinct as_count from (
with t as (
SELECT 
(select name_1 from rate_plan_directions where rpdr_rpdr_id = rpdr_id) name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id
FROM trafics_by_directions
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
)
and end_date > sysdate)
select name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id,
count(1) OVER (PARTITION BY tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,name_rpdr) as_count
from t 
order by as_count desc)
where 1=1 --as_count > 1
and pack_pack_id = p_pack
)
loop
select distinct max(rpdr_rpdr_id) into v_cnt from (
with t as (
SELECT 
(select name_1 from rate_plan_directions where rpdr_rpdr_id = rpdr_id) name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id
FROM trafics_by_directions
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
)
and end_date > sysdate)
select name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id,
count(1) OVER (PARTITION BY tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,name_rpdr) as_count
from t 
order by as_count desc)
where as_count = rec.as_count
and pack_pack_id = p_pack;
dbms_output.put_line('��� rpdr_id='||v_cnt||' � ���������� = '||rec.as_count||':');

for rec2 in (select distinct rpdr_rpdr_id from (
with t as (
SELECT 
(select name_1 from rate_plan_directions where rpdr_rpdr_id = rpdr_id) name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id
FROM trafics_by_directions
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
)
and end_date > sysdate)
select name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id,
count(1) OVER (PARTITION BY tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,name_rpdr) as_count
from t 
order by as_count,price_$ desc)
where as_count = rec.as_count
and pack_pack_id = p_pack
and rpdr_rpdr_id != v_cnt) loop
  
select count(1) into v_cnt2 from trafics_by_directions where pack_pack_id = p_pack and rpdr_rpdr_id = rec2.rpdr_rpdr_id;
if v_cnt2 = 8 then
dbms_output.put_line(rec2.rpdr_rpdr_id||' '||v_cnt2);
else
dbms_output.put_line('ALARM!!!!!!!!!!!!!!! '||rec2.rpdr_rpdr_id||' '||v_cnt2);
end if;

end loop;
end loop;
end;


47797 1
47789 2
47801 5
47788 4
47801 7







select * from (
with t as (
SELECT 
(select name_1 from rate_plan_directions where rpdr_rpdr_id = rpdr_id) name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id
FROM trafics_by_directions
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
)
and end_date > sysdate)
select name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id,
count(1) OVER (PARTITION BY tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,name_rpdr) as_count
from t 
order by as_count desc)
where as_count = 7
and pack_pack_id = 282
and rpdr_rpdr_id = 47801








select count(1) OVER (PARTITION BY tmcl_tmcl_id,price_$,srls_srls_id,lcal_lcal_id,pack_pack_id) sum_id, tr.* from trafics_by_directions tr where rpdr_rpdr_id in (
select distinct rpdr_rpdr_id from (
with t as (
SELECT 
(select name_1 from rate_plan_directions where rpdr_rpdr_id = rpdr_id) name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id
FROM trafics_by_directions
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (select distinct mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate)
)
and end_date > sysdate)
select name_rpdr,
tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,rpdr_rpdr_id,
count(1) OVER (PARTITION BY tmcl_tmcl_id, pack_pack_id, price_$, lcal_lcal_id, srls_srls_id,name_rpdr) as_count
from t 
order by as_count,price_$ desc)
where pack_pack_id = 424
and as_count = 62)


--50343 16
--50470 46
--50375 62
--50443 11
--50406 51
--50401 62

select tmcl_tmcl_id, lcal_Lcal_id, srls_srls_id,rpdr_rpdr_id, price_$ from trafics_by_directions tr where rpdr_rpdr_id in (50343,50470,50375,50443,50406,50401)
order by tmcl_tmcl_id, lcal_Lcal_id, srls_srls_id



