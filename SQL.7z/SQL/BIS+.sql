---������������

select 
'70,,4224,,,3832111111,internet,'||to_char(ADD_MONTHS(TWSC_SESSION_DATE,+1),'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,07,,,,,,,,,,,'||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end)||',,,,,,,,,,,,,,'
from aak_calls where ab_id in (2113725)-- and TWSC_CALLED_STATION like '%Z99%'
order by TWSC_SESSION_DATE

select distinct AB_ID from aak_calls where US_TFP_CODE = '80LART_70060'
select * from aak_calls 

select distinct count(1),AB_ID,TWSC_CALLED_STATION from aak_calls 
where US_TFP_CODE like '%80LART_70060%'
group by AB_ID,TWSC_CALLED_STATION
order by AB_ID

select distinct count(1),AB_ID,TWSC_CALLED_STATION,TWSC_COST from aak_calls 
where US_TFP_CODE like '%80LART_70060%'
and AB_ID = 2113725
group by AB_ID,TWSC_CALLED_STATION,TWSC_COST
order by AB_ID




----��������
--select (TWSC_INPUTOCTETS+TWSC_OUTPUTOCTETS)/1048576 as duration,TWSC_COST from aak_calls where ab_id = 1066354 and TWSC_CALLED_STATION like '%Z99%' order by TWSC_SESSION_DATE;
select duration/1048576, in_balance_$ from bba_calls_00_082018 tt order by start_time;
--select TWSC_INPUTOCTETS/1048576 as duration,TWSC_COST from aak_calls where ab_id = 1066354 and TWSC_CALLED_STATION like '%Z99%' order by TWSC_SESSION_DATE;
select TWSC_OUTPUTOCTETS/1048576 as duration,TWSC_COST from aak_calls where ab_id = 964159 and TWSC_CALLED_STATION like '%Z99%' order by TWSC_SESSION_DATE;

select sum(tt.in_balance_$) from bba_calls_00_082018 tt;
select sum(tt.duration) from bba_calls_00_082018 tt;
select count(1) from bba_calls_00_082018 tt;
select in_balance_$,duration,start_time from bba_calls_00_082018 tt;



--102173,33
--102177,01176699
select sum(twsc_cost) from aak_calls where ab_id = 2113725 --and TWSC_CALLED_STATION like '%Z99%';
select sum(TWSC_OUTPUTOCTETS) from aak_calls where ab_id = 2113725 and TWSC_CALLED_STATION like '%Z99%';
select count(1) from aak_calls where ab_id = 2113725 and TWSC_CALLED_STATION like '%Z99%';
select round(TWSC_COST,2),TWSC_OUTPUTOCTETS,TWSC_SESSION_DATE from aak_calls where ab_id = 2113725 and TWSC_CALLED_STATION like '%Z99%' and TWSC_COST != 0 order by TWSC_OUTPUTOCTETS desc;
select in_balance_$,duration,start_time from bba_calls_00_082018 tt where in_balance_$ != 0 order by duration desc;

6358,7
3989,71560572

2556195160
2586634834

select * from bba_calls_00_082018
join aak_calls on TWSC_OUTPUTOCTETS = DURATION
where ab_id = 2113725
--and in_balance_$ != 0
and in_balance_$ = round(TWSC_COST,2)
--and TWSC_COST !=0
and DURATION != 0
and TWSC_OUTPUTOCTETS != 0

select count(1) from bba_calls_00_082018
where DURATION != 0





select * from aak_calls where ab_id = 964159 --and TWSC_CALLED_STATION like '%Z99%'


truncate table aak_calls 
select * from aak_calls for update



with t as (
select AB_ID as subs_subs_id, US_TFP_CODE as pack_pack_id, (TWSC_INPUTOCTETS+TWSC_INPUTOCTETS) as duration, 
ADD_MONTHS(TWSC_SESSION_DATE,+1) as start_date, TWSC_COST as price, 
(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end) as rtgr_rtgr_id, TWSC_CALLED_STATION as trgr_id2
from aak_calls
)
select subs_subs_id,
(case 
when pack_pack_id like '%70060' then 3723 
when pack_pack_id like '%70061' then 3719 
when pack_pack_id like '%70063' then 3721 
when pack_pack_id like '%70066' then 3726
when pack_pack_id like '%70068' then 3731
when pack_pack_id like '%700500' then 3731 
when pack_pack_id like '%700510' then 3723 
end)
as pack_id, pack_pack_id, start_date, rtgr_rtgr_id, trgr_id2
, sum(duration), round(sum(price),2) from t rr
where 1=1
--and rr.duration > 0
--and subs_subs_id = 971705
--and to_char(start_date, 'hh24') between 1 and 8
--and PACK_PACK_ID = '80LART_70060'
group by subs_subs_id, pack_pack_id, start_date,rtgr_rtgr_id,trgr_id2
order by start_date

select distinct AB_ID from aak_calls where US_TFP_CODE = '80LART_70060'


select * from packs where pack_id in (3721,3731)



/*

with t as (
select AB_ID as subs_subs_id, US_TFP_CODE as pack_pack_id, (TWSC_INPUTOCTETS+TWSC_INPUTOCTETS) as duration, 
ADD_MONTHS(TWSC_SESSION_DATE,+1) as start_date, TWSC_COST as price, 
(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end) as rtgr_rtgr_id
from aak_calls)
select 
'70,,4224,,,3832111111,internet,'||to_char(start_date,'yyyymmddhh24miss')||','||duration||',,,,,,,07,07,,,,,,,,,,,'||rtgr_rtgr_id||',,,,,,,,,,,,,,'
from t rr
where rr.duration > 0
and subs_subs_id = 1066354
order by start_date

*/



--select (TWSC_INPUTOCTETS+TWSC_OUTPUTOCTETS)/1048576 as duration,TWSC_COST from aak_calls where ab_id = 1066354 and TWSC_CALLED_STATION like '%Z99%' order by TWSC_SESSION_DATE;
select duration/1048576, in_balance_$ from bba_calls_00_082018 tt order by start_time;
--select TWSC_INPUTOCTETS/1048576 as duration,TWSC_COST from aak_calls where ab_id = 1066354 and TWSC_CALLED_STATION like '%Z99%' order by TWSC_SESSION_DATE;
select TWSC_OUTPUTOCTETS/1048576 as duration,TWSC_COST from aak_calls where ab_id = 1066354 and TWSC_CALLED_STATION like '%Z99%' order by TWSC_SESSION_DATE;




select * from subs_histories where subs_subs_id = 145816-- for update
--and end_date > sysdate
for update

select * from call_credits where subs_subs_id = 145816 
and end_date > sysdate
for update
  
select * from subs_packs where subs_subs_id = 145816 
and end_date > sysdate

select * from subscribers where subs_id = 145816
-------------���������� ��������

declare
p_subs number := 145816;
p_pack number := 3731;
p_date date;
val varchar2(100);
begin 
select TRUNC(SYSDATE,'MM') into p_date from dual;
SELECT to_char(sysdate, 'mmyyyy') into val FROM dual;
update subs_packs set end_date = (start_date-1/86400) where subs_subs_id = p_subs;
delete from subscriber_discount_threads
where subs_subs_id = p_subs;
delete from call_credits where subs_subs_id = p_subs;
execute immediate 'truncate table bba_calls_00_'||val;
bis_engine.order_pack_service(psubs_id => p_subs, ppack_id => p_pack,operation_date => p_date);
UPDATE_SUBS_INFO(PSUBS => p_subs);
end;


--����� ��
begin
  bis.bis_engine.change_rate_plan(psubs_id => 7673,new_rtpl => 217);
end;
---����������� ������
begin
  bis_engine.order_pack_service(psubs_id => 145816, ppack_id => 3731,operation_date => to_date('01.08.2018','dd.mm.yyyy'));
end;
---���������� ������
begin
  bis_engine.revoke_pack_service(psubs_id => 7673, ppack_id => 3731);
end;


/*update subs_packs set start_date = to_date('01.08.2018','dd.mm.yyyy')
where subs_subs_id = 7673
and pack_pack_id in (112);*/

select * from subs_packs where subs_subs_id = 7673
and end_date > sysdate;
--for update
select * from call_credits where subs_subs_id = 7673 
and end_date > sysdate;

/*delete from call_credits where subs_subs_id = 7673 
update call_credits set start_date = to_date('01.08.2018','dd.mm.yyyy') where subs_subs_id = 7673 
select * from call_credits where subs_subs_id = 7673 
and end_date > sysdate
for update*/
select * from bis.SUBS_BRD_IDENTIFICATIONS
select * from subscribers where subs_id = 145820
---�������
/*begin
delete from subscriber_discount_threads
where subs_subs_id = 7673; commit; end;*/




select 
'70,,4224,,,3832111111,internet,'||to_char(ADD_MONTHS(TWSC_SESSION_DATE,+1),'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,07,,,,,,,,,,,'||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end)||',,,,,,,,,,,,,,'
from aak_calls where ab_id in (2113725)-- and TWSC_CALLED_STATION like '%Z99%'
order by TWSC_SESSION_DATE


select distinct ab_id from aak_calls




