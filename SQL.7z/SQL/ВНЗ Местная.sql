-----

declare
p_number_a varchar2(20) := 89607835705;
p_number_b varchar2(20) := 89607835705;
v_pset_id_a number(10);
v_pset_id_b number(10);
n_pset_diap number(10);
n_count_diap number(10);
n_catch_drct number(10);
n_catch_drct2 number(10);
v_name_r_pset_a varchar2(30);
v_count_a number(10);
v_count_b number(10);
l_rc sys_refcursor;
begin 
open l_rc for 
select 1 from dual;

if p_number_a like '8%' then 
  p_number_a := substr(p_number_a,2);
elsif p_number_a like '7%' then
  p_number_a := substr(p_number_a,2);
end if;

if p_number_b like '8%' then 
  p_number_b := substr(p_number_b,2);
elsif p_number_b like '7%' then
  p_number_b := substr(p_number_b,2);
end if;

select count(1) into v_count_a from prefix_sets where end_date > sysdate and prefix like p_number_a;
if v_count_a > 1 then
  dbms_output.put_line('�������� ������ 1 �������� ��� MSISDN_A'); 
end if;
WHILE v_count_a < 1
LOOP
  p_number_a := regexp_replace(p_number_a,'.$','');
  select count(1) into v_count_a from prefix_sets where end_date > sysdate and prefix like p_number_a;
END LOOP;
select pset_id into v_pset_id_a from prefix_sets where end_date > sysdate and prefix like p_number_a;
/*select substr(name_r, 1, instr(name_r,',')-1) into v_name_r_pset_a from prefix_sets join directions on drct_id=drct_drct_id where pset_id = v_pset_id_a;*/

select count(1) into v_count_b from prefix_sets where end_date > sysdate and prefix like p_number_b;
if v_count_b > 1 then
  dbms_output.put_line('�������� ������ 1 �������� ��� MSISDN_B'); 
end if;
WHILE v_count_b < 1
LOOP
  p_number_b := regexp_replace(p_number_b,'.$','');
  select count(1) into v_count_b from prefix_sets where end_date > sysdate and prefix like p_number_b;
END LOOP;
select pset_id into v_pset_id_b from prefix_sets where end_date > sysdate and prefix like p_number_b;
--  dbms_output.put_line(v_pset_id_b);

select count(drct_id) into n_count_diap From directions join 
(select substr(name_r, 1, instr(name_r,',')-1) as NAME_R2 from prefix_sets join directions on drct_id=drct_drct_id where pset_id = v_pset_id_a) on lower(name_r)
like ('%'||lower(name_r2)||'%');

if n_count_diap > 0 then
for rec_drct in (
select drct_id From directions join 
(select substr(name_r, 1, instr(name_r,',')-1) as NAME_R2 from prefix_sets join directions on drct_id=drct_drct_id where pset_id = v_pset_id_a) on lower(name_r)
like ('%'||lower(name_r2)||'%')
) loop
--dbms_output.put_line(rec_drct.drct_id);

select count(1) into n_catch_drct from prefix_sets where pset_id = v_pset_id_b and drct_drct_id = rec_drct.drct_id;
if n_catch_drct > 0 then
dbms_output.put_line('MSISDN_B �������� ��� MSISDN_A ��� ����������� ��� ���� ������� ���������');  
n_catch_drct2 := 1;
end if;

end loop;
end if;

end;
