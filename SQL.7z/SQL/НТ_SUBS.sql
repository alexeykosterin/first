with table_tmp as (
select 
(select max(COM_ORDER_ID) from subs_product_histories) as COMOrderId,
(select max(PROD_PROD_ID) from subs_product_histories) as CFSId, 
rownum,
ch.* from client_histories ch where account between '654000012605' and '654000012625' 
)
select to_char(COMOrderId)+rownum as COMOrderId,CFSId+rownum as CFSId, t.clnt_clnt_id, t.account, t.*
from table_tmp t




select * from subscribers where clnt_clnt_id in (select clnt_clnt_id from client_histories where account between '654000012605' and '654000012625')

select * from subscribers where clnt_clnt_id in (66696)

select * from subs_product_histories where clnt_clnt_id in (66696)

select * from phone_histories where subs_subs_id = 232893
select * from number_sets where nset_id in (select nset_nset_id from phone_histories where subs_subs_id in (232893,232894))
select * from switches
select * from number_sets where swch_swch_id = 1000 and nsts_nsts_id != 2 and msisdn like '9255497'
select * from number_statuses


select ns.msisdn, sb.clnt_clnt_id, ph.subs_subs_id,ph.nset_nset_id 
from phone_histories ph,number_sets ns,subscribers sb 
where ph.end_date > sysdate
and ns.nset_id = ph.nset_nset_id
and sb.subs_id=ph.subs_subs_id
and clnt_clnt_id = 66696

100001806
990001228
990001229

select max(PROD_PROD_ID) from subs_product_histories
--990001331 CFS
--100001806
select * from subs_product_histories where COM_ORDER_ID = 100001806

654000070589
654000012603

select max(account) from client_histories

select * from client_histories where account like '654105000821'


JUR_ADDRESSES.LGFM_LGFM_ID


select * from jur_addresses where clnt_clnt_id in (select clnt_clnt_id from client_histories where account in ('654105000821', '670009001126'))

JUR_ADDRESSES.INN

select acnt_seq.nextval from dual
select * from jur_addresses_view

select * from matrix_dir_histories
where end_date < sysdate

select * from client_histories where account 
like '%125__'

select * from client_histories 
where account like '670009001126'

12583

select acnt_seq.nextval from dual
