create table aak_prefix as
select * from prefix_sets --where pset_id = 44939
where navi_user like '%����� � ����%'


delete from prefix_sets
where navi_user like '%����� � ����%'


create table aak_direc as
select * from directions where navi_user like '%����� � ����%'
---[][][][][][
delete from 
directions where navi_user like '%����� � ����%'




where drct_drct_id in (select drct_id from directions where name_r like '%������%')
select * from rate_plan_directions where pack_pack_id in (3795) and name_r like '%������%'
select * from directions where name_r like '%������%'

select * from pset_directions
where 1=1
--and navi_user like '%AAK%' 
and drct_drct_id in (2132,1016,2056)
for update
  
31306
31372
--44462
2132  ����������� (�����.) DEF
1016  �����������
2056  ����������� ABC
---------------------31306
select * from trafics_by_directions 
where navi_user like '%AAK ����� � ������ �����%'
--where drct_drct_id in (2132,2056)


select * from rate_plan_directions where rpdr_id = 31306
select * from pset_directions where
--where drct_drct_id = 1016
navi_user like '%AAK%' 
for update
select * from trafics_by_directions where navi_user like '%�����%'
select * from prefix_sets where pset_id in (44462,44939)
select * from zones where def like '%���������%'
select * from zone_groups

select * from directions 
select * from rate_plan_directions where pack_pack_id = 3795
delete from direcions where navi_user like '%����� � ������ ������%'
select * from pset_directions where navi_user like '%AAK%'
select * from prefix_sets

select * from prefix_sets
left join rate_plan_directions on name_r like 


select * from prefix_sets where drct_drct_id = 1015
delete from pset_directions where drct_drct_id in (select drct_id from directions where navi_user like '%�����%'
)
----ABC
select prefix from prefix_sets where drct_drct_id = 1015
and length(PREFIX) in (select min(length(PREFIX)) from prefix_sets where drct_drct_id = 1015)
----DEF
select prefix from prefix_sets where drct_drct_id = 1015
and length(PREFIX) not in (select min(length(PREFIX)) from prefix_sets where drct_drct_id = 1015)

select * from directions 
select * from rate_plan_directions where pack_pack_id = 3795
delete from directions where navi_user like '%�����%'
select * from directions 
where navi_user like '%�����%' 
for update
  

select * from directions;
select * from rate_plan_directions where pack_pack_id = 3795;
select * from prefix_sets;
select * from aak_dir where name_coun like '%�����%' or name_coun like '%�����%';
select * from aak_dir where number_id not in (select number_id from aak_dir where name_coun like '%�����%' or name_coun like '%�����%');
---DEF
select * from prefix_sets where prefix in (select 810||number_id from aak_dir where name_coun like '%�����%' or name_coun like '%�����%')
---ABC
select * from prefix_sets where prefix in (select 810||number_id from aak_dir where number_id not in (select number_id from aak_dir where name_coun like '%�����%' or name_coun like '%�����%'))

---[][][
select * from rate_plan_directions where pack_pack_id = 3795;
select * from directions;

drop table aak_rate_plan_def

create table aak_rate_plan_abc
as 
select rpdr_id, lower(regexp_replace(name_r,'.$|ABC|DEF| ','')) as name_r from rate_plan_directions where pack_pack_id = 3795 and name_r like '%ABC';

create table aak_rate_plan_def
as 
select rpdr_id, lower(regexp_replace(name_r,'.$|ABC|DEF| ','')) as name_r from rate_plan_directions where pack_pack_id = 3795 and name_r like '%DEF';

select * from directions t
join aak_rate_plan_abc tt on lower(t.name_r) like (lower(tt.name_r) || '%')

select * from aak_rate_plan_abc

select * from aak_rate_plan_abc where name_r like '%�����%'

select * from aak_rate_plan_abc where rpdr_id not in (select rpdr_id from directions t
join aak_rate_plan_abc tt on lower(t.name_r) like (lower(tt.name_r) || '%')
)

select * from directions t where name_r like '%������%'


select distinct number_id, lower(regexp_replace(name_coun,'.$|(�����)|(�����.)','')) as name_r from aak_dir

select distinct * from aak_dir
where number_id = 9923453




select * from prefix_sets where prefix in (select distinct 810||number_id from aak_dir where name_coun like '%����%' or name_coun like '%�����%')
update prefix_sets set navi_user = navi_user||' DEF' where prefix in (select distinct 810||number_id from aak_dir where name_coun like '%����%' or name_coun like '%�����%')


select * from prefix_sets where prefix in (select distinct 810||number_id from aak_dir where number_id not in (select number_id from aak_dir where name_coun like '%����%' or name_coun like '%�����%'))
update prefix_sets set navi_user = navi_user||' ABC' where prefix in (select distinct 810||number_id from aak_dir where number_id not in (select number_id from aak_dir where name_coun like '%����%' or name_coun like '%�����%'))

select  * from prefix_sets where pset_comment like '��' for update


select * from directions where drct_id in (select drct_drct_id from prefix_sets where pset_comment like '��')
join aak_dir on lower(name_r) like ('%' || lower(name_coun) || '%')


select regexp_replace(name_coun,'.$|�����.','') from aak_dir

select REGEXP_REPLACE(name_coun,'.*(�����)|(�����.)','') from aak_dir;
select REGEXP_REPLACE(name_coun,'(^| )(�����|�����.)($|)') from aak_dir;

select regexp_replace(name_coun,'($| )((�����)( |$))+','\1') from aak_dir;

select regexp_replace(name_coun,'�����|�������','') from aak_dir;
regexp_replace(REGEXP_SUBSTR(def, '\([^)]*\)'), ('[+ ., �-� �-� ()-]*'), '')


select 
regexp_replace(REGEXP_SUBSTR('������� (�����.)', '\([^)]*\)'), ('[+ ., ()-]*'), '')
from dual;

select 
regexp_replace('������� (�����.)', ('[+ ., ()-]*'), '')
from dual;

drop table aak_dr
create table aak_dr as 
select distinct number_id, regexp_replace(regexp_replace(name_coun, ('[.()]*'), ''),'�����|�������|����| IFS','') as name_r from aak_dir;

select * from directions
select * from aak_dr

select * from directions t
join aak_dr tt on lower(t.name_r) like (lower(tt.name_r) || '%')


select * from aak_dir where name_coun like '%%'

select * from rate_plan_directions

select * from cities

create table aak_dr1 (code_id number(20),countr varchar2(300), prefix_id number(30),direct_id varchar2(300))
select * from aak_dr1 for update
select INITCAP(countr) from aak_dr1
create table aak_dr2 as
truncate table aak_dr1


select * from aak_dr1
where 1=1
--and direct_id like '%(%)%'
and direct_id not like '%�����%'
and direct_id not like '%�����%'

regexp_replace(regexp_replace(direct_id, ('[+ ., ()-]*'), ''),'�����|�������','')







create table aak_dr2 as
select distinct code_id,
(case when countr like '%���%' then countr 
when countr not like '%���%' then INITCAP(countr)
end) as countr,
prefix_id,
(case when direct_id like '%DEF%' then direct_id
when direct_id like '%ISF%' then direct_id
when direct_id like '%IFS%' then direct_id
when direct_id not like '%DEF%' then direct_id||' ABC'
end) as name_r
from aak_dr1



select * from countries
select * from cities
select * from aak_dr2
where lower(countr) like '%����%'

select distinct tt.cou_id, t.countr, tt.name_r from aak_dr2 t
join countries tt on lower(t.countr) like (lower(tt.name_r) || '%')


select distinct * from aak_dr2 t
join countries tt on lower(t.countr) like (lower(tt.name_r) || '%')


begin
  for rec in (select distinct * from aak_dr3
where lower(countr) != lower(name_r)) loop
begin
    insert into cities (cit_id, cou_cou_id, name_e, name_r, navi_user, navi_date, prov_prov_id, prods_prods_id, cttp_cttp_id, visible_yn, del_user, del_date)
    select cit_seq.nextval, rec.cou_id, translit(rec.name_r), rec.name_r, 'AAK', trunc(sysdate), null, null, null, 'Y', null, null
    from dual;
  exception
  when others then dbms_output.put_line (rec.name_r||' '||rec.cou_id);
    end;
    end loop;
end;

select * from cities 
for update
--2775

����� 66


select * from aak_dr3 where cou_id = 66
select * from cities where name_r like '%����%'


--select cit_seq.nextval from dual

create table aak_dr3 as
select distinct countr, regexp_replace(t.name_r,'.$| ABC| DEF| ISF| IFS','') as name_r,cou_id from aak_dr2 t
join countries tt on lower(t.countr) like (lower(tt.name_r) || '%')

select distinct countr, regexp_replace(t.name_r,'.$|ABC|DEF|ISF|IFS','') as name_r,cou_id from aak_dr2 t
join countries tt on lower(t.countr) like (lower(tt.name_r) || '%')

select distinct name_r, cou_id from aak_dr3
where lower(countr) != lower(name_r)


select * from cities
add constraint CIT_UK_1 unique (NAME_E, COU_COU_ID, PROV_PROV_ID, PRODS_PRODS_ID, CTTP_CTTP_ID, DEL_DATE)

select * from aak_dr2
select * from prefix_sets where pset_comment like '��'

begin
  for rec in () loop
    insert into prefix_sets (pset_id, number_history, oper_oper_id, prefix, start_date, end_date, navi_user, navi_date, drct_drct_id, cit_cit_id, cou_cou_id, pset_comment, odrc_odrc_id, zone_zone_id, aob_aob_id, rtcm_rtcm_id)
select pset_id, number_history, oper_oper_id, prefix, start_date, end_date, navi_user, navi_date, 
drct_drct_id, cit_cit_id, cou_cou_id, pset_comment, odrc_odrc_id, 
zone_zone_id, aob_aob_id, rtcm_rtcm_id
from dual;
  end loop;
end;

create table aak_dr4 as
select distinct prefix_id, cou_id, t.countr from aak_dr2 t
join countries tt on lower(t.countr) like (lower(tt.name_r) || '%')

select * from aak_dr2


select * from prefix_sets
select * from directions where name_1 like '��'

-----------------
create table aak_dr6 as
with t as (select distinct prefix_id, cou_id, t.countr from aak_dr2 t
join countries tt on lower(t.countr) like (lower(tt.name_r) || '%')
)
select * from t
join directions on lower(name_r) like (lower(countr) || '%')
--------------------
select distinct * from aak_dr5


select distinct countr from aak_dr2
where countr not in (select distinct name_r from aak_dr5)

select * from aak_dr2
select * from countries 
select * from directions

begin
  for rec in (select distinct countr from aak_dr2
where countr not in (select distinct name_r from aak_dr5)) loop
    insert into directions (drct_id, name_e, name_r, name_1, name_2, rndt_rndt_id, navi_user, navi_date)
    select drct_seq.nextval, translit(rec.countr), rec.countr, 'AAK', null, 0, 'AAK', trunc(sysdate) 
    from dual;
  end loop;
end;



select * from aak_dr6 
where prefix_id = 49351

select * from prefix_sets where prefix in (select 810||prefix_id from aak_dr6)


select * from aak_dr6 where 810||prefix_id not in (select prefix from prefix_sets)

select * from aak_dr6 where drct_id = 2185
for update

select * from prefix_sets where prefix like '81049351'
select * from directions where name_r like '%������%' for update

begin
  for rec in (select * from aak_dr6 where 810||prefix_id not in (select prefix from prefix_sets)) loop
    insert into prefix_sets (pset_id, number_history, oper_oper_id, prefix, start_date, end_date, navi_user, navi_date, drct_drct_id, cit_cit_id, cou_cou_id, pset_comment, odrc_odrc_id, zone_zone_id, aob_aob_id, rtcm_rtcm_id)
    select
    pset_seq.nextval, 1, 0, 810||rec.prefix_id, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 
    rec.drct_id, 0, rec.cou_id, '��', null, 0, null, null
    from dual;
  end loop;
end;

select * from prefix_sets where navi_user like '%AAK%'


select * from prefix_sets where prefix in (select 810||prefix_id from aak_dr6)
select * from pset_directions

select * from rate_plan_directions where pack_pack_id = 3795 and name_r like '%DEF'
select (select name_r from countries where ps.cou_cou_id = cou_id) as countr, (select name_r from directions where drct_id = drct_drct_id) direc,
ps.* from prefix_sets ps where pset_comment like '��' and navi_user like '%DEF%'

select * from prefix_sets where pset_comment like '��' and navi_user not like '%DEF%'
select * from rate_plan_directions where pack_pack_id = 3795 and name_r like '%ABC'




create table aak_dr7 as
select regexp_replace(name_r,'.$| ABC| DEF| ISF| IFS','') as name2, t.* from rate_plan_directions t where pack_pack_id = 3795 and name_r like '%ABC'




select * from directions


create table aak_dr8 as
with t as (
select (select lower(name_r) from countries where ps.cou_cou_id = cou_id) as countr, (select name_r from directions where drct_id = drct_drct_id) direc,
ps.* from prefix_sets ps where pset_comment like '��' and navi_user like '%DEF%')
select countr, direc, pset_id, rpdr_id, prefix, name_r from t mm
join aak_dr7 m on lower(countr) like ('%' || lower(name2) || '%')


select * from aak_dr8

select * from pset_directions

begin
  for rec in (select * from aak_dr9) loop
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    select 
    psdr_seq.nextval, 1, rec.pset_id, rec.rpdr_id, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
    from dual;
  end loop;
end;

44462
42240

select * from pset_directions
where pset_pset_id in (44462,42240) 







for update



create table aak_dr9 as
with t as (
select (select lower(name_r) from countries where ps.cou_cou_id = cou_id) as countr, (select name_r from directions where drct_id = drct_drct_id) direc,
ps.* from prefix_sets ps where pset_comment like '��' and navi_user not like '%DEF%')
select countr, direc, pset_id, rpdr_id, prefix, name_r from t mm
join aak_dr7 m on lower(countr) like ('%' || lower(name2) || '%')


select * from aak_dr9 where pset_id in (select pset_id from aak_dr8 )

select * from pset_directions

select * From pset_directions ps where ps.rpdr_rpdr_id = 31306 and ps.pset_pset_id in ( 44939,44462); 
01,,,,,3832111111,8109929607835,20180806113000,60,,05,,,,,00,51,,Y,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
select * from prefix_sets where prefix like '8109929%'
---44939
select * from pset_directions where pset_pset_id in (44462,42240)
---
update pset_directions set end_date = trunc(sysdate) where pset_pset_id is not null
and pset_pset_id not in (44462,42240)

select * from rate_plan_directions 

select * from pset_directions  
where drct_drct_id = 1016

select * from rate_plan_directions where rpdr_id = 31306


select p.pset_pset_id,r.rtpl_rtpl_id,   r.pack_pack_id, r.drtp_drtp_id,     p.start_date, p.end_date, ps.prefix,  p.rpdr_rpdr_id 
from pset_directions p, rate_plan_directions r, prefix_sets ps 
where p.rpdr_rpdr_id = r.rpdr_id and ps.pset_id=p.pset_pset_id and 
greatest( ps.start_date, p.start_date ) < least( ps.end_date, p.end_date ) and 
least( ps.end_date, p.end_date ) >= sysdate  and p.pset_pset_id is not null 

select * from prefix_sets where pset_id in (44462,44939)
select * from rate_plan_directions where 
pack_pack_id = 3795
name_r like '%������%'
select * from pset_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where 
pack_pack_id = 3795)







