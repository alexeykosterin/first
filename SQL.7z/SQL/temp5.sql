----����� ������ ���������� RPDR  884
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select * from t where count_id > 1
and mtxl_mtxl_id not in (1,3)

-------------� ���� rpdr ���� ������  124
with t as (
select rowid, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select * from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rpdr_id in (
select distinct rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
------------
with t as (
select rowid as rw, min(rowid) over(partition by name_r, mtxl_mtxl_id) as min_rw, rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select * from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rpdr_id in (
select distinct rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
))
and rw <> min_rw




select * from rate_plan_directions where navi_user like '%����2063%'
select * from matrix_dir_histories where rpdr_rpdr_id in ()
select * from trafics_by_directions where rpdr_rpdr_id in ()


---760 ��� ������
with table1 as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories where mtxl_mtxl_id not in (1,3) and end_date > sysdate))
select (select distinct pack_pack_id from link_mtrx_histories ll where ll.mtxl_mtxl_id = t.mtxl_mtxl_id and ll.mtxl_mtxl_id not in (1,3) and end_date > sysdate) as pack_pack_id,
t.* from table1 t where count_id > 1
and mtxl_mtxl_id not in (1,3)
and rpdr_id not in (
select rpdr_rpdr_id from trafics_by_directions where rpdr_rpdr_id in (
with t as (
select rpdr_id, name_r, mtxl_mtxl_id, count(1) OVER (PARTITION BY name_r, mtxl_mtxl_id, drtp_drtp_id) count_id from rate_plan_directions
where mtxl_mtxl_id in (select mtxl_mtxl_id from link_mtrx_histories))
select rpdr_id from t where count_id > 1
and mtxl_mtxl_id not in (1,3)
)
)


















select * from rate_plan_directions where mtxl_mtxl_id = 1 and name_r like '��� �� 100 abc'
where name_r = '�� 1201 �� 3000 �� DEF (���������� ����, ���. �����)' and
mtxl_mtxl_id = 34

select * from matrix_dir_histories
where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions
where name_r = '�� 1201 �� 3000 �� DEF (���������� ����, ���. �����)' and
mtxl_mtxl_id = 34
)


SELECT mt.*, 
count(1) OVER (PARTITION BY pset_pset_id, tfrg_tfrg_id, drct_drct_id, end_date) count_id    
FROM matrix_dir_histories mt
where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions
where name_r = '�� 1201 �� 3000 �� DEF (���������� ����, ���. �����)' and
mtxl_mtxl_id = 34
)



select td.* from trafics_by_directions td 
where rpdr_rpdr_id in 
(select rpdr_id from rate_plan_directions
where name_r = '�� 1201 �� 3000 �� DEF (���������� ����, ���. �����)' and
mtxl_mtxl_id = 34
)







select * from rate_plan_directions
where
mtxl_mtxl_id = 34
