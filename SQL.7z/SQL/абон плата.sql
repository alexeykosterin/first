select * from TMP_RESULT t where t.svc_id = 26431464;

select ns.msisdn, sb.clnt_clnt_id, ph.subs_subs_id,ph.nset_nset_id, ch.account
from phone_histories ph,number_sets ns,subscribers sb, client_histories ch
where 1=1
--and ph.end_date > sysdate
and ns.nset_id = ph.nset_nset_id
and sb.subs_id=ph.subs_subs_id
and ch.clnt_clnt_id = sb.clnt_clnt_id
and subs_subs_id = 3369158
and ch.account = 654000026893

select * from subscribers where subs_id = 3369158




and ch.account in (select * from TMP_RESULT t where t.svc_id = 26431464)

declare
v_end_date date;
v_start_date date;
v_limit number;
CURSOR c1
IS
select distinct t.subs_subs_id from subs_histories t join subscribers  t1 on t.subs_subs_id = t1.subs_id where  navi_user like 'PS_MIGR12%'
and t.end_date > sysdate and subs_subs_id in (select ph.subs_subs_id
from phone_histories ph,number_sets ns,subscribers sb, client_histories ch
where ph.end_date > sysdate
and ns.nset_id = ph.nset_nset_id
and sb.subs_id=ph.subs_subs_id
and ch.clnt_clnt_id = sb.clnt_clnt_id
--and ch.account in (select account from TMP_RESULT t where t.svc_id = 26431464)
)
and rownum < 101
;
cnumber  c1%ROWTYPE;
BEGIN
  v_limit := 1;
     OPEN c1;
      FETCH c1 INTO cnumber;
   while c1%FOUND loop
v_start_date := sysdate;
bis_month_charge.bis_subs_charges(startdate => TRUNC(SYSDATE,'MM'), enddate => last_day(TRUNC(SYSDATE,'MM')),subsid => cnumber.subs_subs_id);
v_end_date := sysdate;
dbms_output.put_line(cnumber.subs_subs_id);
insert into TMP_AAK_LOG select v_start_date, v_end_date, cnumber.subs_subs_id from dual;
v_limit := v_limit + 1;
if v_limit = 100 then
commit;
end if;
FETCH c1 INTO cnumber;
end loop;
commit;
   CLOSE c1;
END;


truncate table TMP_AAK_LOG
select * from TMP_AAK_LOG

select (select name_R from packs where pack_id = pack_pack_id) as NAME_R, sp.* from subs_packs sp
where subs_subs_id in (
select ph.subs_subs_id
from phone_histories ph,number_sets ns,subscribers sb, client_histories ch
where ph.end_date > sysdate
and ns.nset_id = ph.nset_nset_id
and sb.subs_id=ph.subs_subs_id
and ch.clnt_clnt_id = sb.clnt_clnt_id
and ch.account in (select account from TMP_RESULT t where t.svc_id = 26431464)
)
--119

select (select def from serv_lists where srls_srls_id = srls_id), 
 (select name_r from packs where pack_id = pack_pack_id),
(select name_r from rate_plans where rtpl_id = calc_rtpl_id),
(select def from standarts where stnd_id = (select stnd_stnd_id from subscribers where subs_id = subs_subs_id)),
c.* from charges c where clnt_clnt_id in (select clnt_clnt_id from client_histories where account in (654000072183))--(select account from tmp_result where svc_id in (105143)))
and month_start between to_date('01.09.2018', 'DD.MM.YYYY') and to_date('30.09.2018 23:59:59', 'DD.MM.YYYY hh24:mi:ss')
and srls_srls_id = 1895

select (select name from t_svc_ref@billnsk r where r.svc_id = c.svc_id), c.* from cpa_charge@billnsk c
where bid = 201809 and
c.user_id in (select user_id from t_users@billnsk where account in (654000072183))--(select account from tmp_result where svc_id in (105143)))
and total > 0
and charge_kind = 'ch'
and (select isconst from t_svc_ref@billnsk r where r.svc_id = c.svc_id) = 'Y'
and svc_id = 105143

select * from migr_mapping@billnsk where start_type = 'SVC' and start_id in (105143)

select * from tmp_result where svc_id in (105143) and total != bis_charge
and account = 654000072183
select * from tmp_result where account = '654000072183' and svc_id = 105143
/*select * from charges 
where subs_subs_id in (
select ph.subs_subs_id
from phone_histories ph,number_sets ns,subscribers sb, client_histories ch
where ph.end_date > sysdate
and ns.nset_id = ph.nset_nset_id
and sb.subs_id=ph.subs_subs_id
and ch.clnt_clnt_id = sb.clnt_clnt_id
and ch.account = 654000026893*/
)

select * from charges where clnt_clnt_id in 
(select clnt_clnt_id from client_histories where account in (select account from TMP_RESULT t where t.svc_id = 26431464
and account = 654000026893))


