select * From link_mtrx_histories hr 
where hr.mtxl_mtxl_id = 1 ;

select * From matrix_lists li
 where li.mtxl_id = 1; --� ��� �������
 
select * From link_mtrx_histories hr 
for update
where pack_pack_id = 0

select * from preference_tariffication_types
where pttp_id in ( 688, 689,691)
for update

where hr.mtxl_mtxl_id = 1
for update;
---1	50	0	1	1	01.04.2018	31.12.2999	AAK	21.06.2018

select * from packs where pack_id = 113

select * from pack_rtpl 
where pack_pack_id in (112,115)
for update
  
select * from rtpl_srls_substitution ----------------




in (301212,301211)

select * from pack_rtpl
where pack_pack_id in (301212,301211)


select * From link_mtrx_histories m 
for update
where m.mtxl_mtxl_id = 3 ;

select * from rate_plans 
where rtpl_id in (227,50,217)
for update

select * from directions

select * from time_classes 
for update
select * From tim

select * from prefix_sets 
where pset_comment like '%����%'
where prefix like '73%'


where drct_drct_id in ( 67,68)
for update
where pset_id =120743



select * from MATRIX_DIR_HISTORIES 
where tfrg_tfrg_id = 60899
for update

select * from rate_plan_directions 

where drtp_drtp_id = 6

select * from matrix_lists




select * from logic_calls 
order by lcal_id


select * from rate_plan_directions



select * from tarif_histories where rtpl_rtpl_id in (227,50)
for update
select * from trafic_histories where rtpl_rtpl_id in (227,50) for update
select * from logic_calls order by lcal_id
select * from serv_lists order by srls_id

select * from trafics_by_directions 
where navi_user like 'AAK%'
for update
--1	86	1	1,300	2	145	6		01.01.2013	31.12.2999	AAK	27.04.2018 12:47:22	1	1	3	0,000	Y			102	0						0				60899	100100		50








select * From matrix_dir_histories
select * from rate_plan_directions
select * from directions

where drct_drct_id in (
145,
35,
100,
21, --1004
1015,
174,
67, --1007
23) --1009

select * from rate_plan_directions
select * from directions



select di.* From rate_plan_directions di where di.mtxl_mtxl_id = 1
select * from direction_types
select * from matrix_dir_histories dr 
where dr.rpdr_rpdr_id in (select di.rpdr_id From rate_plan_directions di where di.mtxl_mtxl_id = 1)
and dr.tfrg_tfrg_id = 60899
and pset_pset_id = 141262
for update

and dr.zone_zone_id = 356 and dr.pset_pset_id = 123055 and dr.drct_drct_id = 23 ;
--131187
select * from zones where def like '%������%'
�� ���� ��� rpdr_id = 6 - "��� 101-600 def": 

select * From rate_plan_directions di where di.mtxl_mtxl_id = 1 and di.rpdr_id = 6 ;

select * from prefix_sets where 1=1 and pset_id = 141262
--and pset_comment like '������%' for update
and prefix like '91414%' 
or pset_comment like '������%'
for update

select * from prefix_sets where pset_id = 141262

select max(pset_id)+1 from prefix_sets
--141279
select * from dba_sequences  d where d.SEQUENCE_NAME like '%PSET%'


914141111
select * from rate_plan_directions ---6
where rpdr_id = 6
select * from round_types
select * from pset_directions
--select * from pset_cit_histories
select * from directions
where drct_id in (23,67,145,35)---23

-----{}{}{}{}{}{}{}{}{{}
select * from trafics_by_directions
where pttp_pttp_id = 691
and rtpl_rtpl_id = 228
and srls_srls_id = 104
and lcal_lcal_id = 5


select * from preference_tariffication_types
where pttp_id = 691
for update
  
select * from packs where pack_id in (112,115)
for update

select * from rate_plan_directions



 where 1=1
--and drct_drct_id in (23,67) 
and rtpl_rtpl_id = 50
for update

select * from prefix_sets 
where pset_id = 122922
where cou_cou_id = 1
---81099873411 --- 1015 43190
----79141411111 122922 21
79141411111
select (select name_r from countries where cou_cou_id = cou_id), c.* from prefix_sets c
select * from countries
where prefix like '91441%'
where pset_id = 122922

select * from logic_calls

select * from serv_lists where srls_id = 104
select * from logic_calls where lcal_id = 5
select * from call_types
select * from countries
---1 - ������

select * from calls_unknown where subs_subs_id in (7673)


select * from trafic_histories where rtpl_rtpl_id in (50) 
for update
--123055
--141262
select * from time_classes where rtpl_rtpl_id = 50
select * From link_mtrx_histories hr where hr.mtxl_mtxl_id = 1 ; 

select rowid, dr.* from matrix_dir_histories dr where dr.rpdr_rpdr_id in (select di.rpdr_id From rate_plan_directions di where di.mtxl_mtxl_id = 1)
--and dr.tfrg_tfrg_id = 60899
and pset_pset_id in ( 141262, 122672,124156,122922,43190,124879,129310)
for update
  
select dr.* from matrix_dir_histories dr where dr.rpdr_rpdr_id in (1,2,3,4,5,6,7,8)
--and dr.tfrg_tfrg_id = 60899
and pset_pset_id in ( 141262, 122672,124156,122922,43190,129310)
for update

select * from rate_plan_directions
select * from trafic_histories
where rtpl_rtpl_id = 50
for update

select * from prefix_sets where pset_id = 122922
select * from serv_lists
select * from tarif_histories where rtpl_rtpl_id in (50)
for update
104
select * From serv_lists where srls_id = 101



begin
    bis_month_charge.bis_subs_charges(startdate => to_date('01.06.2018','dd.mm.yyyy'), enddate => sysdate,subsid => 7673);
end; 

select * from payments where 
clnt_clnt_id = 1133
order by navi_date desc

select * from bis_charges where
clnt_clnt_id = 1133
or subs_subs_id = 7673

select bis.event_2171 from dual

event_210164 

event_210246

select EVENT_1509 from dual
EVENT_210205
EVENT_2189


select * from dba_objects
where lower(object_name) like 'event%'
and owner like 'BIS'

2171 
210164 
210246 

select * from pset_directions
select * from subscribers where subs_id = 7673
select * from prefix_sets where prefix like '8212%'


----������ ������
declare
phometfrg_id number := 60899;
phome_rmop_id number :=100100;
ppttp number :=690;
pprice number := 1.30;
begin
  for rec1 in (select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (1)) loop
  for rec in (select * from aak_for_trafics where srls_id in (102,103)) loop
insert into trafics_by_directions 
(tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select rec.tmcl_id, 1, pprice, 2,0, rec1.rpdr_id, NULL, to_date('01.01.2013','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK ����������� ������', SYSDATE, 1,1, 
rec.lcal_id, 0, 'Y', NULL, ppttp, rec.srls_id, 0, NULL, NULL, NULL, NULL, NULL, 0 ,null,null,null, phometfrg_id, phome_rmop_id, null, rec.rtpl_id from dual;
end loop;
end loop;
for rec2 in (select rpdr_id from rate_plan_directions where mtxl_mtxl_id in (3)) loop
  for rec3 in (select * from aak_for_trafics where srls_id in (104,105)) loop
insert into trafics_by_directions 
(tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select rec3.tmcl_id, 1, pprice, 2,0, rec2.rpdr_id, NULL, to_date('01.01.2013','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK ����������� ������', SYSDATE, 1,1, 
rec3.lcal_id, 0, 'Y', NULL, ppttp, rec3.srls_id, 0, NULL, NULL, NULL, NULL, NULL, 0 ,null,null,null, phometfrg_id, phome_rmop_id, null, rec3.rtpl_id from dual;
end loop;
end loop;
end;
