select * from number_pool_values
where value_1 = value_2
;

select * From number_pools;

--301;2110000;2129999


select * from number_pool_values 
where value_1 like '8%'
for update

create table aak_number_pool (pref number(10), value_1 varchar2(150), value_2 varchar2(150), count_all number(10), name_oper varchar2(150), name_reg varchar2(150))

drop table aak_number_pool
for update

select * from aak_number_pool
where name_oper like '%�����%'



select count(1) from number_pool_values c
join aak_number_pool v on c.value_1 = v.pref||v.value_1
where c.value_2 = v.pref||v.value_2
--25576


update number_pool_values c set c.value_2 = v.pref||v.value_2 where 
create table aak_number_pool_values_back as select * from number_pool_values


MERGE
INTO    number_pool_values trg
USING   (

select c.rowid as rid, c.value_1, v.pref||v.value_1, c.value_2, v.pref||v.value_2 as VAL_2 from number_pool_values c
join aak_number_pool v on c.value_1 = v.pref||v.value_1
where c.value_2 != v.pref||v.value_2
and v.name_oper like '%����%'
        ) src
ON      (trg.rowid = src.rid)
WHEN MATCHED THEN UPDATE
    SET trg.value_2 = src.val_2;





MERGE
INTO    number_pool_values trg
USING   (

select c.rowid as rid, c.value_1, v.pref||v.value_1 as VAL_1, c.value_2, v.pref||v.value_2 as VAL_2 from number_pool_values c
join aak_number_pool v on c.value_2 = v.pref||v.value_2
where c.value_1 != v.pref||v.value_1
and v.name_oper like '%����%'
        ) src
ON      (trg.rowid = src.rid)
WHEN MATCHED THEN UPDATE
    SET trg.value_1 = src.val_1;






select count(1) from number_pool_values c
join aak_number_pool v on c.value_2 = v.pref||v.value_2
where c.value_1 != v.pref||v.value_1
and v.name_oper like '%����%'
;

select c.value_1, v.pref||v.value_1, c.value_2, v.pref||v.value_2 from number_pool_values c
join aak_number_pool v on c.value_1 = v.pref||v.value_1
where c.value_2 != v.pref||v.value_2
and v.name_oper like '%����%'
;


insert into number_pool_values (npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date, navi_user, navi_date, uniq_id)
select * from aak_number_pool_values_back


truncate table number_pool_values


select * from aak_number_pool where name_oper like '%����%';
select * from number_pool_values;


select * from aak_number_pool a where not exists (select 1 from number_pool_values v where a.value_1 = v.value_1 or a.value_2 = v.value_2)
and name_oper like '%����%'


select /*+parallel (a,9)*/ a.pref||a.value_1, a.pref||a.value_2, a.* from aak_number_pool a where not exists 
(select 1 from number_pool_values v where a.pref||a.value_1 = v.value_1 or a.pref||a.value_2 = v.value_2)
and name_oper like '%����%'

	
select * from number_pool_values where value_1 between '9932030000'
and '9932214999'


select count(1) from aak_number_pool

select /*+parallel (a,9)*/ count(1) from aak_number_pool a where not exists 
(select 1 from number_pool_values v where a.pref||a.value_1 = v.value_1 or a.pref||a.value_2 = v.value_2 and v.value_1 != v.value_2)
and name_oper like '%����%'



select count(1) from number_pool_values
where value_1 = value_2
---27766 val_1=val_2
---32705 exist ---8129 not exists
---90949 all


select /*+parallel (a,9)*/ * from number_pool_values v where not exists 
(select 1 from aak_number_pool a where a.pref||a.value_1 = v.value_1 or a.pref||a.value_2 = v.value_2 and name_oper like '%����%')
and v.value_1 != v.value_2

---29604


select * from number_pool_values where value_1 like '993%'









where navi_user like 'AAK'

npol_npol_id = 3
and value_1 like 'D%RT%'

select *from packs p where p.pack_id = 3870;

select * from prefix_sets where prefix like 'D%RT'


declare
v_cnt number(10);
begin
  select max(uniq_id) into v_cnt from number_pool_values;
  for rec in (select * from prefix_sets where prefix like 'D%RT') loop
    v_cnt := v_cnt+1;
    insert into number_pool_values (npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date, navi_user, navi_date, uniq_id)
    select 3,2,0,null,rec.prefix, rec.prefix, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate),
    v_cnt from dual;
  end loop;
end;

select UNIQ_seq.nextval from dual





declare
v_cnt number(10);
v_ad number(10);
begin
  select max(uniq_id) into v_cnt from number_pool_values;
  for rec in (select /*+parallel (a,9)*/ a.pref||a.value_1 as val_1, a.pref||a.value_2 as val_2 from aak_number_pool a where not exists 
(select 1 from number_pool_values v where a.pref||a.value_1 = v.value_1 or a.pref||a.value_2 = v.value_2 and v.value_1 != v.value_2)
and name_oper like '%����%') loop 
v_cnt := v_cnt+1;
if rec.val_1 like '9%' then v_ad :=2 ;
elsif rec.val_1 not like '9%' then v_ad := 1;
end if;
insert into number_pool_values (npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date, navi_user, navi_date, uniq_id)
select v_ad, 2,0,null,rec.val_1, rec.val_2, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'),'BIS', trunc(sysdate), v_cnt from dual;
end loop;
end;



select * from number_pool_values
where navi_date = trunc(sysdate)





select * from number_pool_values
select * from number_pools






select * from number_pool_values t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, end_date) as min_rw
from number_pool_values
) where rw <> min_rw)


delete from number_pool_values t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, end_date) as min_rw
from number_pool_values
) where rw <> min_rw)




delete from number_pool_values v where not exists 
(select 1 from aak_number_pool a where a.pref||a.value_1 = v.value_1 or a.pref||a.value_2 = v.value_2 and name_oper like '%����%')
and v.value_1 != v.value_2
----29604

select /*+parallel (a,9)*/ * from number_pool_values v where not exists 
(select 1 from aak_number_pool a where a.pref||a.value_1 = v.value_1 or a.pref||a.value_2 = v.value_2 and name_oper like '%����%')
and v.value_1 != v.value_2







