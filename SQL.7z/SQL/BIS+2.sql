select sb.subs_id, sb.clnt_clnt_id, cl.account, ns.msisdn
from subscribers sb, client_histories cl, number_sets ns, phone_histories ph
where 1=1
and cl.clnt_clnt_id = sb.clnt_clnt_id
and ns.nset_id = ph.nset_nset_id
and ph.subs_subs_id = sb.subs_id
and sb.subs_id in (select subs_subs_id From subs_histories where rtpl_rtpl_id in (503)
and end_date > sysdate)




select * From number_sets

select * From phone_histories

select * From MTH_THRESHOLD_EXCEED


select * From rate_plans where rtpl_id in (4011, 384)

select * From client_cats


select * From subscribers where subs_id in (11898171 ,4341)

select * from subs_histories where subs_subs_id in (11898171 ,4341)


select * from subs_brd_identifications where subs_subs_id = 11898171 


select * from subs_histories where 
subs_subs_id = 11898171 


select * From trafic_histories where 1=1-- rtpl_rtpl_id in (4011)
and srls_srls_id = 2900
and rtgr_rtgr_id = 30
and home_tfrg_id in (60899)

select * From trafic_histories where rtpl_rtpl_id in (4011);
select * from tarif_histories where rtpl_rtpl_id in (4011) and srls_srls_id in (2900);

select * From time_classes where rtpl_rtpl_id in (217,4011)
for update;
  

--372 373

select * From times where tmcl_tmcl_id in (43,44)
for update;
  
select max(tmcl_id) from time_classes



select * From rate_plans where name_r like '%Web%'


for update
  
select * From tarif_histories 
where rtpl_rtpl_id = 4011 
for update
and srls_srls_id = 2900



select * From time_classes
where rtpl_rtpl_id = 4011









----15732
----



select ch.account from 
client_histories ch, subscribers sb
where ch.clnt_clnt_id = sb.clnt_clnt_id
and ch.end_date > sysdate
and subs_id in 
(
select subs_subs_id from bis.SUBS_BRD_IDENTIFICATIONS
where subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id from subs_histories where navi_user like 'PS_MIGR1218'
and end_date > sysdate)
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where navi_user like '%AAK%' and name_r like '%Webst%'))
and bidt_bidt_id != 1
)








select * from bis.SUBS_BRD_IDENTIFICATIONS
where subs_subs_id in (3993214,
4033345,
3890586,
4147636,
4163993,
3889388,
3920730,
4152689
)
-------------
select distinct * from subs_packs where subs_subs_id in (select subs_subs_id from subs_histories where navi_user like 'PS_MIGR1218'
and end_date > sysdate)
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where navi_user like '%AAK%' and name_r like '%Webst%')
and subs_subs_id in 
(3993214,
4033345,
3890586,
4147636,
4163993,
3889388,
3920730,
4152689
)




(select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id from subs_histories where navi_user like 'PS_MIGR1218'
and end_date > sysdate)
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where navi_user like '%AAK%' and name_r like '%Webst%'))
and bidt_bidt_id != 1)



select (select name_r from packs where pack_id = pack_pack_id) ,sp.* from subs_packs sp where subs_subs_id = 3993214



select (select name_r from packs where pack_id = pack_pack_id) ,sp.* from subs_packs sp where subs_subs_id = 3948734


select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id from subs_histories where navi_user like 'PS_MIGR1218'
and end_date > sysdate)
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where navi_user like '%AAK%' and name_r like '%Webst%')






and msisdn like '3833350938'


with t as (
select (case 
when us_tfp_code like '%70060' then 3723 
when us_tfp_code like '%70061' then 3719 
when us_tfp_code like '%70063' then 3721 
when us_tfp_code like '%70066' then 3726
when us_tfp_code like '%70068' then 3731
when us_tfp_code like '%700500' then 3731 
when us_tfp_code like '%700510' then 3723 
end)
as pack_id, ak.* from aak_calls ak
where us_tfp_code like '8_L%')
select * from t 
where us_tfp_code not in ('80LGRT_72013',
'80LGRU_72097',
'80LFRU_70732'
)
order by TWSC_SESSION_DATE





55373   �������� �� Ethernet �������� ���� Ethernet 1000 ��
55374   �������� �� Ethernet �������� ���� Ethernet 3000 ��
55375   �������� �� Ethernet �������� ���� Ethernet 5000 ��
55376   �������� �� Ethernet �������� ���� Ethernet 7500 ��
55377   �������� �� Ethernet �������� ���� Ethernet 10000 ��
700500  Webstream Drive.�������������� 50 �� ��������-������� (ETTH)
700510  Webstream Drive 100 (ETTH)
700511  Webstream Drive 200 (ETTH)
700512  Webstream Drive 500 (ETTH)
700513  Webstream Drive 1000 (ETTH)
700514  Webstream Drive 3000 (ETTH)
700515  Webstream Drive 5000 (ETTH)
700516  Webstream Drive 7500 (ETTH)
700517  Webstream Drive 10000 (ETTH)
70060   �������� �� XDSL Webstream  100
70061   �������� �� XDSL Webstream  200
70062   �������� �� XDSL Webstream  500
70063   �������� �� XDSL Webstream  1000
70064   �������� �� XDSL Webstream  3000
70065   �������� �� XDSL Webstream  5000
70066   �������� �� XDSL Webstream  10000
700660  �������� �� XDSL Webstream  7500 
70068   Webstream.�������������� 50 �� ��������-������� (XDSL)
71701   �������� �����.�����  Webstream  200
71702   �������� �����.����� Webstream  500
71703   �������� �����.����� Webstream  1000
72106   �������� �� GPON �������������� 50 ����� ��������-�������.
72108   �������� �� GPON Webstream  200
72109   �������� �� GPON Webstream  500
72111   �������� �� GPON  Webstream  100 


select * From aak_calls
for update
truncate table aak_calls





create table aak_t as
with t as (
select AB_ID as subs_subs_id, US_TFP_CODE as pack_pack_id, (TWSC_INPUTOCTETS+TWSC_INPUTOCTETS) as duration, 
ADD_MONTHS(TWSC_SESSION_DATE,+1) as start_date, TWSC_COST as price, 
(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z9%' then 30
when TWSC_CALLED_STATION like '%Z9%N%' then 35
end) as rtgr_rtgr_id, TWSC_CALLED_STATION as trgr_id2
from aak_calls
)
select distinct 
(case 
when subs_subs_id = 987030 then 145815
when subs_subs_id = 1015970 then 145816
when subs_subs_id = 971705 then 145817
when subs_subs_id = 1239143 then 145818
when subs_subs_id = 2113725 then 145819
when subs_subs_id = 1066354 then 145820
when subs_subs_id = 2000032 then 145821
when subs_subs_id = 1069417 then 145822
when subs_subs_id = 1223068 then 145823
when subs_subs_id = 964159 then 145824
when subs_subs_id = 1679362 then 145825
when subs_subs_id = 1139941 then 145826
when subs_subs_id = 995938 then 145827
when subs_subs_id = 1007791 then 145828
when subs_subs_id = 991655 then 145829
when subs_subs_id = 1249570 then 145830
end) as subs,
subs_subs_id,
(case 
when pack_pack_id like '%70060' then 3723 
when pack_pack_id like '%70061' then 3719 
when pack_pack_id like '%70063' then 3721 
when pack_pack_id like '%70066' then 3726
when pack_pack_id like '%70068' then 3731
when pack_pack_id like '%700500' then 3731 
when pack_pack_id like '%700510' then 3723 
end)
as pack_id, pack_pack_id
from t rr
--join SUBS_BRD_IDENTIFICATIONS qq on subs = qq.subs_subs_id
where 1=1
group by subs_subs_id,  pack_pack_id



select 'when ab_id='||t.subs_subs_id||' then '''||qq.ORIGINAL_IDS||'''' from aak_t t
join SUBS_BRD_IDENTIFICATIONS qq on subs = qq.subs_subs_id






select 
'70,,,,,,,'||to_char(ADD_MONTHS(TWSC_SESSION_DATE,+1),'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,07,,,,,,,,,,,'||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end)||',,,,,,,,,0101201808021732260000060000C,10.143.58.122,,,, SID=474:475-1533199962 Framed-IP-Address=176.211.255.45 Framed-IP-Vendor=Juniper ParentSID=474,,,,,,,,,,'
||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end)||',,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||
(case 
when ab_id=1139941 then 'Webstream103'
when ab_id=964159 then 'Webstream101'
when ab_id=1066354 then 'Webstream97'
when ab_id=1069417 then 'Webstream99'
when ab_id=2113725 then 'Webstream96'
when ab_id=1007791 then 'Webstream105'
when ab_id=1679362 then 'Webstream102'
when ab_id=1249570 then 'Webstream107'
when ab_id=987030 then 'Webstream92'
when ab_id=991655 then 'Webstream106'
when ab_id=1223068 then 'Webstream100'
when ab_id=1239143 then 'Webstream95'
when ab_id=2000032 then 'Webstream98'
when ab_id=995938 then 'Webstream104'
when ab_id=971705 then 'Webstream94'
when ab_id=1015970 then 'Webstream93'
end
)
||',,'
from aak_calls
order by TWSC_SESSION_DATE






select * from bis.SUBS_BRD_IDENTIFICATIONS
select * from aak_t
select * from subscribers where subs_id = 145819


declare
p_subs number;
p_pack number;
p_date date;
val varchar2(100);
begin 
select TRUNC(SYSDATE,'MM') into p_date from dual;
SELECT to_char(sysdate, 'mmyyyy') into val FROM dual;
execute immediate 'truncate table bba_calls_00_'||val;
for rec in (select * from aak_t) loop
select rec.subs into p_subs from dual;
select rec.pack_id into p_pack from dual;
update subs_packs set end_date = (start_date-1/86400) where subs_subs_id = p_subs;
delete from subscriber_discount_threads
where subs_subs_id = p_subs;
delete from call_credits where subs_subs_id = p_subs;
bis_engine.order_pack_service(psubs_id => p_subs, ppack_id => p_pack,operation_date => p_date);
UPDATE_SUBS_INFO(PSUBS => p_subs);
end loop;
end;


select count(1) from bba_calls_00_082018
select count(1) from aak_calls

select * from bba_calls_00_082018 where duration = 951585859

select * from aak_t
select * from aak_calls where TWSC_OUTPUTOCTETS = 951585859



select subs_subs_id, count(1), sum(duration), sum(in_balance_$) from bba_calls_00_082018
group by subs_subs_id
order by subs_subs_id;

select ab_id, count(1), sum(TWSC_OUTPUTOCTETS), sum(TWSC_COST) from aak_calls --where  TWSC_CALLED_STATION not like '%Z77%'
group by ab_id
order by ab_id;

select * from aak_calls where ab_id = 971705 and TWSC_CALLED_STATION not like '%Z77%'

select * from rating_groups

select sum(twsc_cost) from aak_calls where ab_id = 2113725;
select sum(TWSC_OUTPUTOCTETS) from aak_calls where ab_id = 2113725;
select count(1) from aak_calls where ab_id = 2113725;
select round(TWSC_COST,2),TWSC_OUTPUTOCTETS,TWSC_SESSION_DATE from aak_calls where ab_id = 2113725;
select in_balance_$,duration,start_time from bba_calls_00_082018 tt where;

1 (ID 1679362) 3726
1 (ID 964159)
1 (ID 1015970)
1 (ID 1223068)
1 (ID 1069417)
1 (ID 1069417)
1 (ID 145829)
1 (ID 145818)



for rec in (select * from aak_t) loop

end loop;


70,,,,,,,20181124192525,7948499,,,,,,,07,07,,,,,,,,,,,,,,,,,,,,0101201808021732260000060000C,10.143.58.122,,,,20.61835983,,,,,,,,,,,,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,ats2210-205-11@nsk,,


select * from aak_calls
where TWSC_OUTPUTOCTETS = 7948499


select 
'70,,,,,,,'||to_char(ADD_MONTHS(TWSC_SESSION_DATE,+1),'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,07,,,,,,,,,,,'||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
  when TWSC_CALLED_STATION like '%Z9%' then 30
when TWSC_CALLED_STATION like '%Internet%' then 30
when TWSC_CALLED_STATION like '%Z9%N%' then 35
end)||',,,,,,,,,0101201808021732260000060000C,10.143.58.122,,,,'||TWSC_COST||',,,,,,,,,,'
||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z9%' then 30
  when TWSC_CALLED_STATION like '%Internet%' then 30
when TWSC_CALLED_STATION like '%Z9%N%' then 35
end)||',,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||
TWSC_LOGNAME
||',,'
from (
with t as (
select (case 
when us_tfp_code like '%70060' then 3723 
when us_tfp_code like '%70061' then 3719 
when us_tfp_code like '%70063' then 3721 
when us_tfp_code like '%70066' then 3726
when us_tfp_code like '%70068' then 3731
when us_tfp_code like '%700500' then 3731 
when us_tfp_code like '%700510' then 3723 
end)
as pack_id, ak.* from aak_calls ak
where us_tfp_code like '8_L%')
select * from t 
where us_tfp_code not in ('80LGRT_72013',
'80LGRU_72097',
'80LFRU_70732'
)
order by TWSC_SESSION_DATE)


select * from aak_calls
