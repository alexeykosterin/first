select * from discount_plans where def like '%Webst%'
select * from packs where pack_id in (select pack_pack_id from discount_plans where def like '%Webst%') or pack_id = 3731 for update
select * From discount_plans where pack_pack_id in (select pack_pack_id from discount_plans where def like '%Webst%') 
for update
select * from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where def like '%Webst%') for update
select * from discount_plan_histories where dcpl_dcpl_id in (select dcpl_id from discount_plans where def like '%Webst%') for update
select * from discount_thread_volumes 
where dctr_dctr_id in (select dctr_id from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where def like '%Webst%')) 
for update
select * from pack_rtpl where pack_pack_id in (3722,3731) for update

select * from discount_thread_volumes 
where dctr_dctr_id in (371)
for update;
---����������� ������
select * from discount_volume_transitions 
for update;
select * from discount_volume_chains 
for update;

select * from DISCOUNT_THREADS where dctr_id in (371)
for update
DVCN_DVCN_ID != NULL
select * from discount_thread_volumes where dctr_dctr_id  IN (371)
for update
select * from discount_threads where dctr_id  in(371, 257) 
for update


select dt.dvcn_dvcn_id,dvt.dctv_from,dvt.dctv_to, '(dvcn_dvcn_id)(dctv_do)---->(dvcn_dvcn_id)(next_dctv_id)' as todo,dtv.* from BIS.DISCOUNT_THREADS dt
inner join bis.discount_thread_volumes dtv on dt.dctr_id = dtv.dctr_dctr_id
inner join bis.discount_volume_transitions dvt on dt.dvcn_dvcn_id = dvt.dvcn_dvcn_id 
and dtv.dctv_id = dvt.dctv_from 
where dt.DVCN_DVCN_ID is not NULL
order by dtv.dctr_dctr_id,dtv.dctv_id;

select dt.dvcn_dvcn_id, '(dvcn_dvcn_id)(dctv_do)---->(dvcn_dvcn_id)(next_dctv_id)' as todo,dtv.* from BIS.DISCOUNT_THREADS dt
inner join bis.discount_thread_volumes dtv on dt.dctr_id = dtv.dctr_dctr_id
inner join bis.discount_volume_transitions dvt on dt.dvcn_dvcn_id = dvt.dvcn_dvcn_id 
where dt.DVCN_DVCN_ID is not NULL

select * from BIS.DISCOUNT_VOLUME_CHAINS;
select * from BIS.DISCOUNT_VOLUME_TRANSITIONS;


select * from scaled_price 
for update
select * from scaled_price_parts 
for update
-- z99_night_in	J_Z99_N_VL
-- z99_day_in	J_Z99_D_VL


select * from trafic_histories
where pack_pack_id in (select pack_pack_id from discount_plans where def like '%Webst%')
and zone_zone_id = 356
and tmcl_tmcl_id  in (43,44)
and pack_pack_id = 3731
for update




update trafic_histories set tmcl_tmcl_id = 43
where pack_pack_id in (select pack_pack_id from discount_plans where def like '%Webst%')
and zone_zone_id = 356
and tmcl_tmcl_id = 1

for update

select * from TARIF_HISTORIES
where rtpl_rtpl_id = 217
and pacK_pack_id in (select pack_pack_id from discount_plans where def like '%Webst%')
for update

select * from MTH_SUBS_PRICES
select * from MTH_SUBS_CLUSTERS where subs_subs_id = 7673

begin
select * from MTH_RECURRING_PRICES ; 
end;
select * from times where tmcl_tmcl_id = 1
select * from MTH_USER_FUNC.RT

select * from trafic_histories
where pack_pack_id in (select pack_id from packs where pack_id in (select pack_pack_id from discount_plans where def like '%Webst%'))
for update

select * from TARIF_HISTORIES
where rtpl_rtpl_id = 217
and pack_pack_id in (select pack_id from packs where pack_id in (select pack_pack_id from discount_plans where def like '%Webst%'))
for update
  

SRLS_SRLS_ID = 211 (���������� ETTH) � ��� PACK_ID in (3731, 3723, 3719, 3720, 3721, 3722, 3724, 3725, 3726, 3727, 3728, 3729, 3730),   
SRLS_SRLS_ID = 212 (���������� GPON) � ��� PACK_ID in (3731, 3719, 3720, 3723).


begin
  for rec in (select pack_id from packs where pack_id in (3731)) loop
    insert into trafic_histories (srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, pack_pack_id, pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, navi_date, faft_faft_id, scpr_scpr_id, rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id)
select 
212, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, rec.pack_id, pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, TRUNC(SYSDATE), faft_faft_id, scpr_scpr_id, rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id
from trafic_histories th where pack_pack_id = rec.pack_id and zone_Zone_id = 356;
  end loop;
end;


select 
srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, pack_pack_id, pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, TRUNC(SYSDATE), faft_faft_id, scpr_scpr_id, rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id
from trafic_histories th where pack_pack_id = 3731 and zone_Zone_id = 356
for update

select * from trafic_histories 
where pack_pack_id in (3731, 3719, 3720, 3723)
for update
and srls_srls_id = 212


where navi_date = trunc(sysdate)


3)	� ������� tarif_histories �����������: SRLS_SRLS_ID = 212 (���������� GPON), SRLS_SRLS_ID = 211 (���������� ETTH)
select * from TARIF_HISTORIES
where rtpl_rtpl_id = 217
and pack_pack_id in (select pack_id from packs where pack_id in (select pack_pack_id from discount_plans where def like '%Webst%'))
for update
  

---������ �� �� Webstream
begin
  for rec in (select distinct clst_id from MTH_CLUSTERS where lower(def) like '%���%') loop
    for rec2 in (select * from aak_price_web where tfrg_id = 60899) loop
      for rec3 in (select srls_id from serv_lists where srls_id in (210,211,212)) loop
insert into MTH_TARIF_HISTORIES 
(RTPL_RTPL_ID, PACK_PACK_ID, SRLS_SRLS_ID, BNDL_BNDL_ID, MACR_MACR_ID, BRNC_BRNC_ID, CLST_CLST_ID, MTCG_MTCG_ID, AMOUNT, RATE_FOR_ONE_DAY, FEE_TAX_INCLUDED, COMMENTS, START_DATE, END_DATE, NAVI_USER, NAVI_DATE)
select 217, rec2.pack_id, rec3.srls_id, 0,600,null,rec.clst_id,4,rec2.price_$,'N','Y',null,to_date('15.05.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'),
'AAK Webstream 60899', SYSDATE from dual; 
      end loop;
    end loop;
  end loop;
end;


---��������
select count(1), srls_srls_id, pack_pack_id, amount from MTH_TARIF_HISTORIES where navi_user like '%AAK %'
group by srls_srls_id, pack_pack_id, amount

select * from charges where subs_subs_id = 7673
select * from subs_packs where subs_subs_id = 7673 and end_date > sysdate


begin
bis_month_charge.bis_subs_charges(startdate => to_date('01.07.2018','dd.mm.yyyy'), enddate => sysdate,subsid => 7673);
end;


select * from DISCOUNT_THREAD_DEPEND
  for update
--366
select * from discount_plans where pack_pack_id = 3731 
for update
select * from packs where pack_id in (3733, 3731) for update
select * from discount_threads where dcpl_dcpl_id in (365,366) 
for update
select * from discount_thread_volumes where dctr_dctr_id in (372)
for update
select * from discount_plan_histories where dcpl_dcpl_id in (365,366)

select * from time_classes
select * from discount_trees 
where def like '%Webstre%'
select * from rate_plans where rtpl_id = 217
select * from time_classes
select * from times
select * From discount_volume_chains for update
select * from discount_volume_transitions for update
