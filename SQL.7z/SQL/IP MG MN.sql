select * from directions 

select * from matrix_dir_histories

select * from rate_plan_directions where mtxl_mtxl_id in (4)
for update
select max(rpdr_id) from rate_plan_directions

--62146

select rpdr_seq.nextval from dual

create table aak_tmp3 (drct_name varchar2(100), price_$ varchar2(100))

select * From aak_tmp3 for update



declare 
v_cnt number(10);
begin
  
  for rec in (SELECT distinct
(case when DRCT_NAME like '%���. �����%' then REPLACE(DRCT_NAME, ', ���. �����', '')
when DRCT_NAME like '%, ����.�����%' then REPLACE(DRCT_NAME, ', ����.�����', '')
when DRCT_NAME like '% ABC%' then REPLACE(DRCT_NAME, ' ABC', '')
when DRCT_NAME like '% DEF%' then REPLACE(DRCT_NAME, ' DEF', '')
else DRCT_NAME
                    end) as DRCT
FROM aak_tmp3) loop
select rpdr_seq.nextval into v_cnt from dual;
insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select v_cnt, 0, 1, translit(rec.drct), rec.drct, '��', 'IP', 'AAK', trunc(sysdate), 6,0,4 from dual;
end loop;
end;




declare
v_lcal number(10);
v_srls number(10);
begin
for rec in (
with t as (
SELECT distinct
(case when DRCT_NAME like '%���. �����%' then REPLACE(DRCT_NAME, ', ���. �����', '')
when DRCT_NAME like '%, ����.�����%' then REPLACE(DRCT_NAME, ', ����.�����', '')
when DRCT_NAME like '% ABC%' then REPLACE(DRCT_NAME, ' ABC', '')
when DRCT_NAME like '% DEF%' then REPLACE(DRCT_NAME, ' DEF', '')
else DRCT_NAME
                    end) as DRCT, DRCT_NAME, price_$
FROM aak_tmp3)
select * From t
join rate_plan_directions on name_r = drct
where mtxl_mtxl_id in (4)
and name_1 like '��'
)
loop
  if rec.drct like '%�������%' then v_lcal := 13;
    elsif rec.drct like '%���.%' then v_lcal := 13;
      elsif rec.drct like '%����.%' then v_lcal := 14;
        else v_lcal := 14;
  end if; 
  if rec.drct like '%�������%' then v_srls := 104;
    elsif rec.drct like '%���.%' then v_srls := 104;
      elsif rec.drct like '%����.%' then v_srls := 105;
        else v_srls := 104;
  end if; 
for rec2 in (select tmcl_id from time_classes where tmcl_id in (82,83)) loop
  insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, add_drct_id, add_rpdr_id, pack_pack_id, rtcm_rtcm_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
  
  select 
  rec2.tmcl_id, 1, to_char(REPLACE(rec.price_$, ',', '.')), 2,null,rec.rpdr_id, null, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'),'AAK', trunc(sysdate),1,1,v_lcal,0,'Y',null,0, v_srls,0,
  null,null,null,null,0,null,null,null,null,60899,100100,null,228
  from dual;
end loop;
end loop;
end;



select * from trafics_by_directions where navi_date = trunc(sysdate-1)

select * from rate_plan_directions where mtxl_mtxl_id = 4 and name_1 like '��'

select * from matrix_dir_histories where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where mtxl_mtxl_id = 4)


select * from logic_calls w





delete from trafics_by_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by tmcl_tmcl_id, price_$, pphm_pphm_id, end_date, drct_drct_id, rpdr_rpdr_id, function_name, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, 
add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id) as min_rw
from trafics_by_directions where navi_date = trunc(sysdate)
) where rw <> min_rw)




select * from serv_lists
select * from logic_calls
13	VoIP �� ABC
14	VoIP �� DEF
104	�� �������
105	�� ��������


select * from matrix_dir_histories where pset_pset_id in (151583) 


select * from trafics_by_directions 







begin
  for rec in (
with t as (
select REPLACE(DRCT_NAME, 'IP ', '') as DRCT_NAME from aak_tmp3
)
select * from t 
left join directions on drct_name = name_r
where name_r is null) loop
insert into directions (drct_id, name_e, name_r, name_1, name_2, rndt_rndt_id, navi_user, navi_date)
select drct_seq.nextval, translit(rec.drct_name), rec.drct_name, null,null,0, 'AAK', trunc(sysdate) from dual;
end loop;
end;



with t as (
select REPLACE(DRCT_NAME, 'IP ', '') as DRCT_NAME, drct_name as DD from aak_tmp3
)
select * from t a
join directions s on a.drct_name = s.name_r
join rate_plan_directions r on r.name_r = a.DD


select * from matrix_dir_histories where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where mtxl_mtxl_id = 4)




begin
  for rec in (with t as (
select REPLACE(DRCT_NAME, 'IP ', '') as DRCT_NAME, drct_name as DD from aak_tmp3
)
select * from t a
join directions s on a.drct_name = s.name_r
join rate_plan_directions r on r.name_r = a.DD) loop
    insert into matrix_dir_histories (tfrg_tfrg_id, drct_drct_id, pset_pset_id, number_history, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, zone_zone_id)
    select 60899, rec.drct_id,0,1,rec.rpdr_id,to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 0 from dual;
  end loop;
end;

select * from trafics_by_directions where navi_date = trunc(sysdate-1)

select * from matrix_dir_histories where navi_date = trunc(sysdate)



select drct_seq.nextval from dual
select * from directions where navi_user like 'AAK'






select * from directions where name_r like '%IP%'
select * from pset_directions








select * from rate_plan_directions
select * from aak_tmp3


SELECT distinct
(case when DRCT_NAME like '%���. �����%' then REPLACE(DRCT_NAME, ', ���. �����', '')
when DRCT_NAME like '%, ����.�����%' then REPLACE(DRCT_NAME, ', ����.�����', '')
when DRCT_NAME like '% ABC%' then REPLACE(DRCT_NAME, ' ABC', '')
when DRCT_NAME like '% DEF%' then REPLACE(DRCT_NAME, ' DEF', '')
else DRCT_NAME
                    end),
                    price_$
FROM aak_tmp3;


select * from aak_tmp3





select REPLACE(', ���. �����', '') from dual



create table aak_tmp_MN (name_r varchar2(100), price_$ varchar2(100))


select * from aak_tmp_MN for update


with t as (
select distinct case when name_r like '%DEF%' then REPLACE(name_r, ' DEF', '')
when name_r like '%ABC%' then REPLACE(name_r, ' ABC', '')
end as NAME_DRCT, to_char(REPLACE(price_$, ',', '.')) from aak_tmp_MN
)
select * from t a
left join directions s on a.NAME_DRCT = s.name_r
--where s.name_r is null


select * from directions where name_r like '%�����%'
name_1 like '��'

select * from aak_tmp_MN where name_r like
--'����������� �-��%' for update
--'����������� �-��%' for update
--'���%' for update
--'��������� �������%' for update
--'����%' for update
--'��������� �-��%' for update
--'�����-����� ������%' for update
'���%' for update






declare
v_rpdr number(10);
begin
  for rec in (with t as (
select distinct case when name_r like '%DEF%' then REPLACE(name_r, ' DEF', '')
when name_r like '%ABC%' then REPLACE(name_r, ' ABC', '')
end as NAME_DRCT, to_char(REPLACE(price_$, ',', '.')) from aak_tmp_MN
)
select * from t a
left join directions s on a.NAME_DRCT = s.name_r) loop
select rpdr_seq.nextval into v_rpdr from dual;
    insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
    select v_rpdr, 0,0, translit(rec.name_drct), rec.name_r, '�� IP', rec.drct_id, 'AAK', trunc(sysdate), 1,4036,null from dual;
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    select psdr_seq.nextval, 1,null,v_rpdr, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), rec.drct_id, null from dual;
    dbms_output.put_line(rec.name_r);
  end loop;
end;

select * from pset_directions where navi_user like 'AAK' and
navi_date = to_date('22.08.2019','dd.mm.yyyy')


order by navi_date desc

navi_date = trunc(sysdate)


select * from rate_plan_directions where rpdr_id in (51740,63750,63749)



select * from trafics_by_directions where rpdr_rpdr_id in (
select rpdr_id From rate_plan_directions where name_1 like '%�� IP%')

select * From rate_plan_directions where pack_pack_id = 4036
select * from prefix_sets where pset_id = 44427

select * from pset_directions where drct_drct_id = 1007
or pset_pset_id = 44427
create table aak_pset_dir as 



select * from pset_directions where navi_user like 'AAK' and navi_date = to_date('22.08.2019','dd.mm.yyyy')

select * from aak_pset_dir



begin
  for rec in (select distinct * from aak_pset_dir) loop
    dbms_output.put_line(rec.drct_drct_id);
    for rec2 in (select distinct pset_id from prefix_sets where drct_drct_id = rec.drct_drct_id) loop
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    select psdr_seq.nextval,rec.number_history,rec2.pset_id,rec.rpdr_rpdr_id,rec.start_date,rec.end_date,rec.navi_user,rec.navi_date,null,null from dual;
  dbms_output.put_line(1);
  end loop;
  end loop;
end;


select DECODE(PSET_PSET_ID,NULL,0,1),PSET_PSET_ID from pset_directions






select max(psdr_id) from pset_directions

177764
ORA-02290: check constraint (BIS.RGRR_PSET_DRCT_RPDR_CK) violated
ORA-06512: at line 4
ORA-06512: at line 4

select psdr_seq.nextval from dual
PSET_DIRECTIONS

select * From dba_constraints where constraint_name like '%RGRR_PSET_DRCT_RPDR_CK%'





select * from prefix_sets where drct_drct_id = rec.drct_drct_id;





delete from pset_directions where navi_user like 'AAK' and navi_date = to_date('22.08.2019','dd.mm.yyyy')




select * from rate_plan_directions where 
rpdr_id in (select rpdr_rpdr_id from pset_directions where pset_pset_id = 44955)




select * from trafics_by_directions for update


select * from trafics_by_directions as of scn timestamp_to_scn(sysdate-INTERVAL '1' HOUR)
where rpdr_rpdr_id in (
select rpdr_id From rate_plan_directions where name_1 like '%�� IP%')

select * From rate_plan_directions where name_1 like '%IP%'


delete from trafics_by_directions where rpdr_rpdr_id in (
select rpdr_id From rate_plan_directions where name_1 like '%�� IP%')
and lcal_lcal_id = 13


delete from trafics_by_directions where rpdr_rpdr_id in (
select rpdr_id From rate_plan_directions where name_1 like '%�� IP%')
and navi_date = to_date('19.07.2019','dd.mm.yyyy')



update trafics_by_directions set lcal_lcal_id = 20 where rpdr_rpdr_id in (
select rpdr_id From rate_plan_directions where name_1 like '%�� IP%')
select * From logic_calls

select * from trafics_by_directions where pack_pack_id = 4036 
and navi_user like '�� IP'

and navi_date = to_date('20.08.2019','dd.mm.yyyy') order by navi_date desc





select * from pset_directions where navi_date = trunc(sysdate)
select * from rate_plan_directions where navi_date = trunc(sysdate)


delete from pset_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by number_history, pset_pset_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id) as min_rw
from rate_plan_directions where navi_date = trunc(sysdate)
) where rw <> min_rw)



select * from rate_plan_directions where navi_date = trunc(sysdate)
and rpdr_id not in (select rpdr_rpdr_id from pset_directions where navi_date = trunc(sysdate))




select * from rate_plan_directions where name_r like '���� 1'

select * from pset_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where name_r like '���� 1')



select * from trafics_by_directions 
where srls_srls_id in (104,110)
where drct_drct_id in (select drct_id from directions 
where name_1 like '��')

select * from directions 
where name_1 like '��'
where name_r like '���� 1'




select * from packs where name_r like '%�����%'




declare
v_srls number(10);
v_lcal number(10);
begin
  v_srls := 110;
  for rec in (
with t as (
select distinct case when name_r like '%DEF%' then REPLACE(name_r, ' DEF', '')
when name_r like '%ABC%' then REPLACE(name_r, ' ABC', '')
end as NAME_DRCT, name_r as NAME_1, to_char(REPLACE(price_$, ',', '.')) as price_$ from aak_tmp_MN
)
select distinct name_drct, a.name_1, price_$,d.rpdr_id, s.drct_id from t a
left join directions s on a.NAME_DRCT = s.name_r
left join rate_plan_directions d on d.NAME_R = a.NAME_DRCT
where d.pack_pack_id = 4036
) loop
if rec.name_1 like '%ABC%' then v_lcal := 13;
  elsif rec.name_1 like '%DEF%' then v_lcal := 14;
  else v_lcal := 14;
end if;
for rec1 in (select tmcl_id from time_classes where tmcl_id in (82,83)) loop
  insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, add_drct_id, add_rpdr_id, pack_pack_id, rtcm_rtcm_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
  select rec1.tmcl_id, 1, rec.price_$,2,null,rec.rpdr_id,null,to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK IP', trunc(sysdate),1,1,
  v_lcal,0,'Y',null,null,v_srls,0,null,null,null,null,0,null,null,null,null,60899,100100,null,0 from dual;
  end loop;
end loop;
end;



select * from trafics_by_directions where navi_date = trunc(sysdate)

select * from logic_calls 
select * from serv_lists




select * from rate_plan_directions where pack_pack_id = 4036
for update


select *
from trafics_by_directions
where rpdr_rpdr_id in (select rpdr_id From rate_plan_directions di where pack_pack_id = 3886) 








