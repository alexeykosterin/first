select * from subs_discount_plan_volumes
select * From subscriber_discount_threads

----- �� IMSI

select s.clnt_clnt_id, s.subs_id, ns.msisdn from subscribers s
left join phone_histories p on subs_id = subs_subs_id
left join number_sets ns on nset_id = nset_nset_id
--left join clients c on clnt_id = s.clnt_clnt_id
where subs_id = 7673


select ns.msisdn, ph.subs_subs_id, clh.account, cl.clnt_id, ju.name JUR, clh.name CLH--, sc.imsi, sc.icc
from number_sets ns, phone_histories ph, subs_histories sh, subscribers s,
client_histories clh,jur_addresses ju, clients cl--, sim_cards sc
where 1=1
and ns.nset_id = ph.nset_nset_id
and sh.end_date > sysdate
and sh.subs_subs_id = ph.subs_subs_id
and s.clnt_clnt_id = cl.clnt_id
and cl.clnt_id = ju.clnt_clnt_id
and ju.end_date > sysdate
and clh.clnt_clnt_id = cl.clnt_id
and clh.end_date > sysdate
and s.subs_id = 7673
--and sh.scrd_scrd_id = sc.scrd_id
--and sc.expiration_date > sysdate


select * from phone_histories where subs_subs_id = 7673
select * from number_sets where nset_id = 30000001
select * from number_set_histories


select * from dba_objects
where lower(object_name) like '%event%'
and owner = 'BIS'


select * from user_sequences where lower(sequence_name) like '%pack%'

select * from rate_plans where lower(name_r) like '%webstream%'
select * from pack_rtpl where rtpl_rtpl_id in (select rtpl_id from rate_plans where lower(name_r) like '%webstream%' and rtpl_id = 217)
select * from packs where pack_id in (select pack_pack_id from pack_rtpl where rtpl_rtpl_id in (select rtpl_id from rate_plans where lower(name_r) like '%webstream%' and rtpl_id = 217))

select * from number_sets
select * from serv_lists where srls_id = 210
select * from rating_groups

select * from zones
select * from rtpl_faft
--- ������ �����
declare
V_RTPL_ID number;
begin 
  BIS.SIB_EASR.RATE_PLAN_CLONE(P_OLD_RTPL_ID => 217, P_NAME => '����_webstream_aak', P_NAVI_USER => 'AAK', P_RTPL_ID => V_RTPL_ID);
end;

select hextoraw(to_char(23593,'fm000X')) from dual;

---������ RTGR

select (select name_r from rate_plans where rtpl_id = rtpl_rtpl_id), rtpl_rtpl_id, rtgr_rtgr_id, PRICE_$,--*1.18,
(select def from rating_groups where rtgr_id = rtgr_rtgr_id), (select def from zones where zone_zone_id = zone_id), zone_zone_id ZZ,
(select def from time_classes where tmcl_tmcl_id = tmcl_id), tmcl_tmcl_id,
rh.* from trafic_histories rh
where 1=1
--and rtgr_rtgr_id in (select rtgr_id from rating_groups) 
and rtpl_rtpl_id in (217)
order by ZZ

select tmcl_tmcl_id from trafic_histories where rtpl_rtpl_id = 217 and tmcl_tmcl_id not in (0,1)

select * from time_classes

select count(1) from trafic_histories where rtpl_rtpl_id = 217 and tmcl_tmcl_id not in (0,1); ---���� ����� �� ������� � ������� ����

select * from rating_group_ranges
where rtgr_rtgr_id in (
select rtgr_rtgr_id from trafic_histories rh
where 1=1
--and rtgr_rtgr_id in (select rtgr_id from rating_groups) 
and rtpl_rtpl_id in (217))


select * from bis.time_classes

--order by rtpl_rtpl_id
select * from time_classes

select * from tarif_histories where
1=1
and rtpl_rtpl_id = 217

select dp.dcmr_dcmr_id,(select def from discount_measures where dp.dcmr_dcmr_id = dcmr_id), 
dp.* from discount_plans dp where pack_pack_id in (
select pack_id from packs where pack_id in (select pack_pack_id from pack_rtpl where rtpl_rtpl_id in (select rtpl_id from rate_plans where lower(name_r) like '%webstream%' and rtpl_id = 217))
);
select * from discount_sub_types;
select * from discount_measures;

select * from DISCOUNT_THREADS t
where t.dcpl_dcpl_id in (
select dcpl_id from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select pack_pack_id from pack_rtpl where rtpl_rtpl_id in (select rtpl_id from rate_plans where lower(name_r) like '%webstream%' and rtpl_id = 217))
));

select * from times;
select * from day_categories;
select * from rating_group_ranges;

---������
select * from discount_trees where dtre_id = 143

select * from DISCOUNT_PREDICATE_LINKS t
where t.dtre_dtre_id = :m_dtre_id



select * from discount_thread_volumes where dctr_dctr_id in 
(
select dctr_id from DISCOUNT_THREADS t
where t.dcpl_dcpl_id in (
select dcpl_id from discount_plans where pack_pack_id in (
select pack_id from packs where pack_id in (select pack_pack_id from pack_rtpl where rtpl_rtpl_id in (select rtpl_id from rate_plans where lower(name_r) like '%webstream%' and rtpl_id = 217))
))
)
---�����������
select * from rate_plan_directions where 1=1
and rtpl_rtpl_id = 217
or
pack_pack_id = 3723


select * from time_classes where rtpl_rtpl_id = 217

---����� ��� ������� ������� � ����������� ����
select * from rtpl_zone_substitution
---� ����� ��� ��������
select * from rtpl_roam_substitution
---
--select * from number_types
--select * from number_categories
select (select def from number_types where ntyp_ntyp_id = ntyp_id), 
(select def from number_categories where ncat_id = ncat_ncat_id),
rn.* from rtpl_ntyp rn where rtpl_rtpl_id = 217
