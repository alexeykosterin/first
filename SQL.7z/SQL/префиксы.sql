with table1 as (
select rpd.name_r, aak.* from aak_dir aak 
join rate_plan_directions rpd on lower(name_coun) like ('%' || lower(regexp_replace(name_r,'.$|ABC|DEF','')) || '%')
where navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')
and name_r like '%ABC%'
and lower(name_coun) like '%�����%')
,
table2 as(
select rpd.name_r, aak.* from aak_dir aak 
join rate_plan_directions rpd on lower(name_coun) like ('%' || lower(regexp_replace(name_r,'.$|ABC|DEF','')) || '%')
where navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')
and name_r like '%DEF%'
and lower(name_coun) not like '%�����%')
select t.*,tt.* from table1 t,table2 tt

create table aak_table1 as
select rpd.rpdr_id, rpd.name_r, aak.* from aak_dir aak 
join rate_plan_directions rpd on lower(name_coun) like ('%' || lower(regexp_replace(name_r,'.$|ABC|DEF','')) || '%')
where navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')
and name_r like '%DEF%'
and lower(name_coun) like '%�����%'

create table aak_table2 as
select rpd.rpdr_id, rpd.name_r, aak.* from aak_dir aak 
right join rate_plan_directions rpd on lower(name_coun) like ('%' || lower(regexp_replace(name_r,'.$|ABC|DEF','')) || '%')
where navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')
and name_r like '%DEF%'
and lower(name_coun) not like '%�����%'

select * from aak_dir
where name_coun like '%���%'

select distinct * from aak_table1
--387 DEF
drop table aak_table1

select distinct * from aak_table2
--33 ABC

select distinct * from aak_dir where name_coun not like '%�����%'
and lower(name_coun) like ('%' || || '%')

select aak.* from aak_dir aak where lower(name_coun) like '%���������%'

create table aak_table3 as 
select rpdr_id, lower(regexp_replace(name_r,'.$|DEF','')) as NAME_R from rate_plan_directions where name_r like '%DEF%' 
and navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')

select * from aak_dir
select * from aak_table3



select distinct * from aak_dir where lower(name_coun) like (select name_r from aak_table3)




join aak_table3 rpd on lower(name_coun) like ('%' || name_r || '%')
and name_coun not like '%�����%'

 
select distinct a.* from   aak_dir a where  exists (select null
from   aak_table3 n 
where  lower(a.name_coun) like '%'|| lower(regexp_replace(name_r,'.$|ABC|DEF','')) ||'%')
and name_coun not like '%�����%'
and name_coun not like '%�����%'
and name_coun not like '%IFS%'
and name_coun not like '%ISF%'

select distinct a.name_coun||' ABC' as NAME_R from   aak_dir a where  exists (select null
from   aak_table3 n 
where  lower(a.name_coun) like '%'|| lower(regexp_replace(name_r,'.$|ABC|DEF','')) ||'%')
and name_coun not like '%�����%'
and name_coun not like '%�����%'
and name_coun not like '%IFS%'
and name_coun not like '%ISF%'
order by name_r


select * from rate_plan_directions
where navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')
and name_r like '%ABC%'

select * from directions where drct_id = 1020

select * from prefix_sets where drct_drct_id = 1020
select * from pset_directions where drct_drct_id = 1020



begin 
  for rec in (select distinct a.name_coun||' ISF' as NAME_R from   aak_dir a where  exists (select null
from   aak_table3 n 
where  lower(a.name_coun) like '%'|| lower(regexp_replace(name_r,'.$|ABC|DEF','')) ||'%')
and name_coun not like '%�����%'
and name_coun not like '%�����%'
and name_coun like '%IFS%'
or name_coun like '%ISF%'
order by name_r) loop
insert into directions (drct_id, name_e, name_r, name_1, name_2, rndt_rndt_id, navi_user, navi_date)
select drct_seq.nextval, translit(rec.name_r), rec.name_r, '��', null, 2, 'AAK ����� � ������ ������ ISF', TRUNC(SYSDATE) from dual;
end loop;
end;

select * from directions where name_r like '%DEF%' and navi_user like '%AAK%'


select * from directions where navi_user like 'AAK ����� � ������ ������'

select * from prefix_sets where drct_drct_id = 1020

begin 
  for rec in (select * 
from aak_dir10 join aak_dir9 on lower(name_r) like (lower(name_coun) || '_')) loop
insert into prefix_sets (pset_id, number_history, oper_oper_id, prefix, start_date, end_date, navi_user, navi_date, drct_drct_id, cit_cit_id, cou_cou_id, pset_comment, odrc_odrc_id, zone_zone_id, aob_aob_id, rtcm_rtcm_id)
select pset_seq.nextval, 1, 0, 810||rec.number_id, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK ����� � ������ ������ ISF', TRUNC(SYSDATE), 

rec.drct_id ----------

, 0, 6, '��', null, 0, null, null
from dual;
end loop;
end;

select distinct * from aak_table1;

select * from aak_dir6 join aak_dir5 on lower(name_r) like (lower(name_coun) || '_');




select * from prefix_sets where navi_user like 'AAK ����� � ������ ������ ISF'

select * from directions where drct_id in (
select drct_drct_id from prefix_sets where navi_user like 'AAK ����� � ������ ������')




create table aak_dir9
as 
select distinct /*dr.drct_id,dr.name_r,*/ a.* from   aak_dir a 
/*left join aak_dir5 dr
on lower(name_coun) like ('%' || lower(name_r) || '%')*/
where  exists (select null
from   aak_table3 n 
where  lower(a.name_coun) like '%'|| lower(regexp_replace(name_r,'.$|ABC|DEF','')) ||'%')
and name_coun not like '%�����%'
and name_coun not like '%�����%'
and name_coun like '%IFS%'
or name_coun like '%ISF%'



select * from aak_dir7
select * from aak_dir5

select * 
from aak_dir10 
join aak_dir9 on lower(name_r) like (lower(name_coun) || '_')

select distinct a.* from   aak_dir a where  exists (select null
from   aak_table3 n 
where  lower(a.name_coun) like '%'|| lower(regexp_replace(name_r,'.$|ABC|DEF','')) ||'%')
and name_coun not like '%�����%'
and name_coun not like '%�����%'
and name_coun not like '%IFS%'
and name_coun not like '%ISF%'



select * from directions

create table aak_dir10 as
select drct_id, regexp_replace(name_r,'.$|ABC|DEF|ISF','') as name_r  from directions where navi_user like 'AAK ����� � ������ ������ ISF'


select * from prefix_sets where navi_user like '%AAK%' and pset_comment like '��'
select * from directions where navi_user like '%AAK%'
select * from rate_plan_directions where pack_pack_id = 3795 for update
--31320
select * from pset_directions where drct_drct_id = 1020 
for update

update rate_plan_directions set pack_pack_id = 3795 where navi_user like '%AAK%' and 
mtxl_mtxl_id is null

select * from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null
select * from direction_types

select distinct name_coun from aak_dir where name_coun like '%ISF%'
or name_coun like '%IFS%'

begin
  for rec in (select distinct name_coun from aak_dir where name_coun like '%ISF%'
or name_coun like '%IFS%') loop
insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select 
rpdr_seq.nextval, 0, 1, translit(rec.name_coun), rec.name_coun, null, null, 'AAK', trunc(sysdate), 1, 3795, null
from dual;
end loop;
end;


select * from pset_directions where drct_drct_id = 1020 

select * from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null
select * from directions where navi_user like '%AAK%'

select * 
from directions t
join aak_abc  tt on lower(t.name_r) like ('%' || lower(tt.name_r) || '%')
where t.name_r like '%ABC%'


create table aak_abc as
select rpdr_id, regexp_replace(name_r,'.$|ABC|DEF|ISF','') as name_r  from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null
and name_r like '%ABC%'


select * 
from directions t
join aak_def  tt on lower(t.name_r) like ('%' || lower(tt.name_r) || '%')
where t.name_r like '%DEF%'


create table aak_def as
select rpdr_id, regexp_replace(name_r,'.$|ABC|DEF|ISF','') as name_r  from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null
and name_r like '%DEF%'


select * 
from directions t
join aak_abc  tt on lower(t.name_r) like ('%' || lower(tt.name_r) || '%')
where t.name_r like '%I%'

create table aak_isf as
select rpdr_id, regexp_replace(name_r,'.$|ABC|DEF|ISF|IFS','') as name_r  from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null
and name_r like '%I%'

select * from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null
and name_r like '%I%'
select * from pset_directions where navi_user like '%AAK%'


begin
  for rec in (select * 
from directions t
join aak_abc  tt on lower(t.name_r) like ('%' || lower(tt.name_r) || '%')
where t.name_r like '%I%') loop
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    select
    psdr_seq.nextval, 1, null, rec.rpdr_id, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK ISF', trunc(sysdate), rec.drct_id, null
    from dual;
  end loop;
end;


---228
select * from pset_directions where navi_user like '%AAK%';
select * from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null;
select * from prefix_sets where navi_user like '%AAK%' and pset_comment like '��';
select * from directions where navi_user like '%AAK%';


select * from trafics_by_directions 
where pack_pack_id = 3795
and lcal_lcal_id = 5
and srls_srls_id = 104
and tmcl_tmcL_id = 82
for update


select * from 

delete from trafics_by_directions
where navi_user like '%AAK ����� � ������ ������%'


TMCL_TMCL_ID	NUMBER_HISTORY	PRICE_$	PPHM_PPHM_ID	DRCT_DRCT_ID	RPDR_RPDR_ID	FUNCTION_NAME	START_DATE	END_DATE	NAVI_USER	NAVI_DATE	CUR_CUR_ID	XTYP_XTYP_ID	LCAL_LCAL_ID	CONNECTION_$	ENABLE_FAF	SCPR_SCPR_ID	PTTP_PTTP_ID	SRLS_SRLS_ID	COU_COU_ID	RMOP_RMOP_ID	AOB_AOB_ID	RTCM_RTCM_ID	ADD_DRCT_ID	ADD_RPDR_ID	PACK_PACK_ID	FLAG_CS	ZONE_ZONE_ID	TFRG_TFRG_ID	HOME_TFRG_ID	HOME_RMOP_ID	RMTP_RMTP_ID	RTPL_RTPL_ID
82	            1	12,000	2		31256		31.12.1990	31.12.2999	AAK ����� � ������ ������ DEF	31.07.2018	1	1	5	0,000	Y			104	0						0					100100		0




begin
  for rec in (select * from time_classes where tmcl_id in (82,83)) loop
    for rec2 in (select * from serv_lists where srls_id in (104,105)) loop
      for rec3 in (select * from logic_calls where lcal_id in (5,6,9,10)) loop
      for rec4 in (select * from rate_plan_directions join aak_zvoni on lower(name_r) like ('%' || lower(countries) || '%')
where navi_user like '%AAK%' and mtxl_mtxl_id is null and name_r not like '%DEF%'
and name_r not like '%ABC%') loop
    insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, 
    navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, 
    aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
  select 
  rec.tmcl_id, 1, rec4.ABC, 2, null, rec4.rpdr_id, null, to_date('31.12.1990','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK ����� � ������ ������ IFS', trunc(sysdate), 
  1, 1, rec3.lcal_id, 0, 'Y', null, null, rec2.srls_id, 0, null, null, 
  null, null, null, 0, null, null, null, null, 100100, null, 0
  from dual;
  end loop;
  end loop;
  end loop;
  end loop;
end;



select * from trafics_by_directions where navi_user like 'AAK ����� � ������ ������%'

select * from rate_plan_directions join aak_zvoni on lower(name_r) like ('%' || lower(countries) || '%')
where navi_user like '%AAK%' and mtxl_mtxl_id is null and name_r not like '%DEF%'
and name_r not like '%ABC%'



select * from rate_plan_directions where navi_user like '%AAK%' and mtxl_mtxl_id is null and name_r like '%ABC%'
select * from aak_zvoni


select * from rate_plan_directions join aak_zvoni on lower(name_r) like ('%' || lower(countries) || '%')
where navi_user like '%AAK%' and mtxl_mtxl_id is null and name_r like '%ABC%'


---create table aak_zvoni (name_r varchar2(300),ABC number(10,5),DEF number(10,5))
5	���� abc
6	���� def
9	���� ������������� ABC
10	���� ������������� DEF


select * from serv_lists
select * from logic_calls
select * from time_classes where tmcl_id in (82,83)

select * from pset_directions where rpdr_rpdr_id = 31372

select * from directions where drct_id = 1016
---����������� (�����.) DEF

select * from prefix_sets where drct_drct_id in (2056,2132,1016) --166899
for update

select * from trafics_by_directions where navi_user like '%����� � ���%'
and rpdr_rpdr_id = 31372
for update
  
update trafics_by_directions set lcal_lcal_id = 9 where navi_user like '%����� � ���%'
and lcal_lcal_id = 10

 
