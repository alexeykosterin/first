
with t as (

select /*+paralle (c,9)*/ 
dialed as dialed2,
file_name as file_name2,
round(REGEXP_SUBSTR (cdr_udf, '[^;]+', 1, 1),5) as PRICE_START,
charges_$ as charges_$2,
REGEXP_SUBSTR (cdr_udf, '[^;]+', 1, 2) as DRCT_START,
DRCT_DRCT_ID as DRCT_DRCT_ID2,
REGEXP_SUBSTR (cdr_udf, '[^;]+', 1, 3) as DETG_START,
detg_detg_id as DETG_DETG_ID2,
REGEXP_SUBSTR (cdr_udf, '[^;]+', 1, 4) as ID_START,
REGEXP_SUBSTR (cdr_udf, '[^;]+', 1, 5) as VNSET_START,
--to_number(c.trafic_price_$,'9.99'),
trafic_price_$ as trafic_price_$2,
in_balance_$ as in_balance_$2,
c.* From pstn_calls_00_022020 c
--where regexp_like(c.file_name,'^mnIP_202001.txt%*|^mnIP_202002.txt%*|^vznIP_202001.txt%*|^vznIP_202002.txt%*') 
where file_name like '%IP%'

)
select * From t
where price_start != charges_$2
or DRCT_START != DRCT_DRCT_ID2
or DETG_START != DETG_DETG_ID2


73822753351
73822451944
73822222309
73822675265
73822753351
73822675265
73822244647


select * F



