select (select name from bvd_discount_tables t where BVDT_ID = bvdt_bvdt_id) name_r, t.*, 
count(CLNT_CLNT_ID) OVER (PARTITION BY BVDT_BVDT_ID) COUNT_BVDT_BVDT_ID from bvd_clnt_bvdt t;

select * from BVD_BVVD_DETG
where detg_detg_id in (75521)

-----------
select (select name from bvd_discount_tables t where BVDT_ID = bvdt_bvdt_id) name_r, t.bvdt_bvdt_id, DETG_DETG_ID, tt.clnt_clnt_id, 
count(tt.CLNT_CLNT_ID) OVER (PARTITION BY DETG_DETG_ID) COUNT_DETG,
count(t.CLNT_CLNT_ID) OVER (PARTITION BY BVDT_BVDT_ID) COUNT_BVDT_BVDT_ID,
tt.* from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where 1=1--clnt_clnt_id in (select t.clnt_clnt_id from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173')
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
and t.navi_user like 'PS_MIGR173'
order by COUNT_BVDT_BVDT_ID desc
-----------

select (select name from bvd_discount_tables t where BVDT_ID = bvdt_bvdt_id) name_r, t.* from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173'
and BVDT_BVDT_ID = 28




begin
bis.PACK_BILLING_DISC_PARAMS.CALCULATE_DISC_PARS(ip_date =>  to_date('01.08.2019','dd.mm.yyyy'),ip_RUN_AGGREGATE_BILLING => true,ip_RUN_AGGREGATE_BILLING_ROAM => true);
end;





begin
  bis.PACK_BILLING_TASK.BT_INIT(0);
end;


select * from bis.BT_TASKS;
select * from bis.BT_SETS;
select * from bis.BT_BTSE_CLNT;



DECLARE
v_bill_month NUMBER:=201909;
  MAX_CLNT clients.clnt_id%type;
  MIN_CLNT clients.clnt_id%type;
BEGIN
  PACK_BILLING_TASK_BGI.BT_INIT(P_CHEK_STATE => 0);
  for cur in (select blcl_id, blgr_blgr_id
                from bill_cycles
               where 1=1--cycle_date = to_date('31.12.2018 23:59:59', 'DD.MM.YYYY HH24:MI:SS')
                 and bct_bct_id = 1
                 and clst_clst_id = 3 and blcl_id=190630000001912) loop
    select min(clnt_clnt_id), max(clnt_clnt_id)
      into MIN_CLNT, MAX_CLNT
      from client_histories
     where clnt_clnt_id in (select tt.clnt_clnt_id from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where 1=1--clnt_clnt_id in (select t.clnt_clnt_id from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173')
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
and t.navi_user like 'PS_MIGR173');
    pack_billing_task_bgi.g_PARALLEL := 1;
    PACK_BILLING_TASK_BGI.BT_ADD_TASK(P_BILL_DATE     => ((last_day(to_date(to_char(v_bill_month)||'01','YYYYMMDD'))+1)-1/86400),
                                      P_BLCL_ID       => cur.blcl_id,
                                      P_PRIORITY      => 1,
                                      P_BRNC_ID       => 1609,
                                      P_BLGR_ID       => cur.blgr_blgr_id,
                                      P_AFKT_ID       => NULL,
                                      P_START_CLNT_ID => MIN_CLNT,
                                      P_END_CLNT_ID   => MAX_CLNT,
                                      P_START_ASSC_ID => NULL,
                                      P_END_ASSC_ID   => NULL,
                                      P_SETS_MAX      => 1000);
  end loop;
  PACK_BILLING_TASK_BGI.BT_ADD_IND;
END;






select * from bis.BT_TASKS;
select * from bis.BT_SETS;
select * from bis.BT_BTSE_CLNT;
--1092


begin
  pack_billing_task_bgi.start_bgi_proccess(p_btts_id => 1091);
end;



select st.name, s.* from bis.bt_sets s, bis.bt_states st where s.btst_btst_id = st.btst_id;


select * from bill_details b where bill_bill_id = 190601779543800
order by BLDT_ID desc

select * From bills where blcl_blcl_id  = 190630000001910
order by bill_id desc

select * from charges 
where subs_subs_id in (select subs_id from subscribers where clnt_clnt_id in (select clnt_clnt_id from bis.BT_BTSE_CLNT))
order by date_for_bill desc



select st.name, s.* from bis.bt_sets s, bis.bt_states st where s.btst_btst_id = st.btst_id;

