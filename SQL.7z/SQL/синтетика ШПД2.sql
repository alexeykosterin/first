----------------------1)
----������
declare
v_cnt number(30);
v_cnt1 number(10);
v_cnt2 number(10);
v_cnt3 number(30);
table_not_exists exception;
pragma exception_init(table_not_exists,-942);
begin
execute immediate 'drop table aak_sintetic2 purge';
execute immediate 'truncate table aak_sintetic';
  for rec1 in (select distinct subs_subs_id, pack_pack_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
) loop 
--50
if rec1.pack_pack_id in (3870,3731) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(0, 10)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--100_200_500
elsif rec1.pack_pack_id in (3723,3719,3720) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(100, 150)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--1000_3000
elsif rec1.pack_pack_id in (3721,3722,3724) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(100, 300)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--7500_12000_30000
elsif rec1.pack_pack_id in (3725,3726,3727) then
for rec2 in 1..300 loop
SELECT trunc(dbms_random.VALUE(100, 300)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--50000_100000
elsif rec1.pack_pack_id in (3728,3730) then
for rec2 in 1..300 loop
SELECT trunc(dbms_random.VALUE(100, 1000)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
elsif rec1.pack_pack_id in (3729) then
for rec2 in 1..300 loop
SELECT trunc(dbms_random.VALUE(300, 5000)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
end if;
select count(1) into v_cnt1 from aak_sintetic
where subs_id = rec1.subs_subs_id;
v_cnt1 := round(v_cnt1/10,0);
v_cnt2 := v_cnt1;
update aak_sintetic set DURATION = DURATION/2 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/3 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/4 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/5 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/7 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/10 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/30 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/50 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/100 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
end loop;
commit;
begin
select count(1) into v_cnt3 from aak_sintetic;
dbms_output.put_line(v_cnt3);
dbms_output.put_line(v_cnt3);
execute immediate 'create table aak_sintetic2 as with t as (SELECT ''201808''||LPAD(trunc(dbms_random.VALUE(1, 32)), 2, ''0'')||
LPAD(trunc(dbms_random.VALUE(0, 24)), 2, ''0'')||
LPAD(trunc(dbms_random.VALUE(0, 60)), 2, ''0'')||
LPAD(trunc(dbms_random.VALUE(0, 60)), 2, ''0'') random_date 
FROM dual 
CONNECT BY LEVEL <= 500000)
select distinct random_date
from t
FETCH FIRST '|| v_cnt3 ||' ROWS ONLY';
dbms_output.put_line(v_cnt3);
end;
exception 
when table_not_exists then 
execute immediate 'create table aak_sintetic2 (id_id number(10))'
;
end;


select count(1) from aak_sintetic
select count(1) from aak_sintetic2
select * from aak_sintetic
select * from aak_sintetic2
----------------------2)
declare
v_cnt1 number(10);
table_not_exists exception;
pragma exception_init(table_not_exists,-942);
begin
  
for rec2 in (select distinct pack_id from aak_sintetic) loop
dbms_output.put_line(v_cnt1 || rec2.pack_id);

select /*+parallel (ut,9)*/ count(1) into v_cnt1 from user_tables ut where lower(table_name) like 'aak_cdr%';
dbms_output.put_line(v_cnt1 || rec2.pack_id);
if v_cnt1 != 0 then
execute immediate 'drop table aak_cdr'||rec2.pack_id;
dbms_output.put_line(v_cnt1 || rec2.pack_id);
end if;
end loop;

for rec3 in (select distinct pack_id from aak_sintetic) loop
execute immediate 'create table aak_cdr'||rec3.pack_id||' (cdr varchar2(300), group_id (number(10))';
end loop;

for rec in (SELECT a.subs_id, original_ids, duration, pack_id, b.RANDOM_DATE
  FROM (SELECT rownum rn
          FROM dual
        CONNECT BY LEVEL <= greatest((SELECT COUNT(*) FROM aak_sintetic),
                                     (SELECT COUNT(*) FROM aak_sintetic2))) pivot,
       (SELECT rownum rn, subs_id, duration, pack_id,original_ids FROM aak_sintetic, SUBS_BRD_IDENTIFICATIONS where subs_id = subs_subs_id and end_date > sysdate
       and BIDT_BIDT_ID = 4) a,
       (SELECT rownum rn, RANDOM_DATE FROM aak_sintetic2) b
 WHERE pivot.rn = a.rn(+) AND
       pivot.rn = b.rn(+)) loop
execute immediate
'insert into aak_cdr'||rec.pack_id||' (cdr) select ''70,,,,,,,'||rec.RANDOM_DATE||','||rec.duration||',,,,,,,07,07,,,,,,,,,,,30,,,,,,,,,0101201808021732260000060000C,10.143.58.122,,,, SID=474:475-1533199962 Framed-IP-Address=176.211.255.45 Framed-IP-Vendor=Juniper ParentSID=474,,,,,,,,,,30,,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||rec.original_ids||',,'' from dual';
end loop;
commit;
exception 
when table_not_exists then null;
commit;
end;



select count(1) from aak_cdr3720
select * from aak_cdr3719 
for update

----------------------3)
select /*+parallel (ut,9)*/  * from user_tables ut where lower(table_name) like 'aak_cdr%';
select * from AAK_CDR3728;
select * from AAK_CDR3723;
select * from AAK_CDR3870;
select * from AAK_CDR3727;

select * from AAK_CDR3722;
select * from AAK_CDR3730;
select * from AAK_CDR3726;
select * from AAK_CDR3725;
select * from AAK_CDR3719;
select * from AAK_CDR3720;
select * from AAK_CDR3729;
select * from AAK_CDR3724;

select * from AAK_CDR3731;
select * from AAK_CDR3721;




begin
for rec in (select distinct pack_id from aak_sintetic) loop
if rec.pack_id = 3870 then
execute immediate 'update aak_cdr'||rec.pack_id||' set cdr = REPLACE(cdr, '',30,'', '',14,'') where rownum in (
select rownum from aak_cdr'||rec.pack_id||' where  rowid in
(select rid
from   (select mod(row_number() over(order by null), 50) as rn, rowid as rid from aak_cdr'||rec.pack_id||') x
where  x.rn = 0))';
end if;
end loop;
end;


select * from aak_cdr3870


-------4) ������� ����� 
select LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')) from aak_cdr3870

---���-�� �� 
select sum(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')))/1048576 from aak_cdr3731
---5 ������ �� 50 ��
select round(sum(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')))/1048576/50,0) from aak_cdr3731


SELECT LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*'))
FROM   aak_cdr3731
ORDER BY cdr
OFFSET 50 ROWS 
FETCH NEXT 50 PERCENT ROWS ONLY


with t as (
select LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')) as aa_id from aak_cdr3870)
SELECT aa_id, 
SUM(aa_id) OVER (PARTITION BY aa_id ) sum_aa_id    
FROM t;

select * from aak_cdr3870
select sum(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*'))) from aak_cdr3870

269962888


with t as (
select LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')) as aa_id from aak_cdr3870)
select t.*,
1+sum(aa_id) over(order by aa_id) + nvl(max(aa_id) over(order by aa_id rows between unbounded preceding and 1 preceding),0) g2
from t



with t as (
select rowid, regexp_SUBSTR(CDR,'[^,]+',1,13,'i') as subs_id, to_char(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')))/1048576 as duration from aak_cdr3731)
SELECT subs_id, duration, 
SUM(duration) OVER (ORDER BY subs_id, duration rows between unbounded preceding and 1 preceding) sum_duration
FROM t
where subs_id = 'e3460-01-07012-01@nsk';



select regexp_SUBSTR(CDR,'[^,]+',1,13,'i') from aak_cdr3731;


with t1 as (
select rowid, regexp_SUBSTR(CDR,'[^,]+',1,13,'i') as subs_id, to_char(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')))/1048576 as duration from aak_cdr3731),
t2 as (select * from aak_cdr3731)
SELECT t2.rowid, t2.*, subs_id, duration, 
SUM(duration) OVER (ORDER BY subs_id, duration rows between unbounded preceding and 1 preceding) sum_duration
FROM t1,t2
where 1=1
and subs_id = 'e3460-01-07012-01@nsk'
and t1.rowid=t2.rowid
;


declare 
v_cnt number(10);
v_cnt3 number(10);
begin
  for rec in (select distinct regexp_SUBSTR(CDR,'[^,]+',1,13,'i') as subs_id from aak_cdr3731) loop
    dbms_output.put_line(rec.subs_id);

for rec2 in (with t1 as (
select rowid, regexp_SUBSTR(CDR,'[^,]+',1,13,'i') as subs_id, to_char(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')))/1048576 as duration from aak_cdr3731),
t2 as (select * from aak_cdr3731)
SELECT t2.rowid, t2.*, subs_id, duration, 
SUM(duration) OVER (ORDER BY subs_id, duration rows between unbounded preceding and 1 preceding) sum_duration
FROM t1,t2
where 1=1
and subs_id = rec.subs_id
and t1.rowid=t2.rowid) loop
select rec2.sum_duration into v_cnt from dual;
if v_cnt between 0 and 51 then
update aak_cdr3731 set group_id = 1 where rowid = rec2.rowid;
elsif v_cnt between 51 and 101 then
update aak_cdr3731 set group_id = 2 where rowid = rec2.rowid;
elsif v_cnt between 101 and 151 then
update aak_cdr3731 set group_id = 3 where rowid = rec2.rowid;
elsif v_cnt > 151 then
update aak_cdr3731 set group_id = 4 where rowid = rec2.rowid;
end if;
end loop;
end loop;
end;



with t1 as (
select rowid, regexp_SUBSTR(CDR,'[^,]+',1,13,'i') as subs_id, to_char(LTRIM(REGEXP_SUBSTR(SUBSTR(cdr, 25),'^[^,]*')))/1048576 as duration from aak_cdr3731),
t2 as (select * from aak_cdr3731)
SELECT subs_id, group_id, sum(duration)
FROM t1,t2
where 1=1
and t1.rowid=t2.rowid
group by subs_id,group_id
order by subs_id, group_id


select * from aak_cdr3731 where group_id = 1


