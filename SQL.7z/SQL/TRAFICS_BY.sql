select * from detail_groups d where d.name_r like '%��� ���� �������%����%';
select * from detail_charges d where d.detg_detg_id=68130;
select * from detail_local_calls d where d.detg_detg_id=68130; 



select * from detail_groups;
select * from detail_charges;
select * from detail_local_calls; 

select * From prefix_sets where pset_id = 45787
select * from directions where drct_id = 67

select * From prefix_sets where pset_id between 167278 and 167282
for update
select * from directions where drct_id in (select drct_drct_id From prefix_sets where pset_id between 167278 and 167282)

delete from pstn_calls_00_082018 where file_name like '%MN%'


select * from subs_packs where subs_subs_id = 145513
select * from trafics_by_directions where rpdr_rpdr_id = 40786
select * from rate_plan_directions where rpdr_id = 40786
select rpdr_seq.nextval from dual


select * from rate_plan_directions where pack_pack_id = 480
and name_r like '%������%'
for update

40784	���������
40785	��������� DEF

1014	���������
2359	��������� DEF

167278	1014
167279	2359
167280	2359
167281	2359
167282	2359

select * from pset_directions

insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
select 
psdr_seq.nextval, 1, 167282, 40785, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
from dual


select * from trafics_by_directions 
where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 480 and rpdr_id = 33644)
for update

delete from trafics_by_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by tmcl_tmcl_id, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, 
cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, 
add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id) as min_rw
from trafics_by_directions
) where rw <> min_rw)


select * from trafics_by_directions where rowid = 'AAAn9VAACAALxo9AAO'


select * from trafics_by_directions where 
tmcl_tmcl_id = 82
and rpdr_rpdr_id = 33754
and lcal_lcal_id = 5
and srls_srls_id = 104
and pack_pack_id = 0

delete from pstn_calls_00_082018 where file_name like '%MN%'


504=498

select * from rate_plan_directions where pack_pack_id = 498
and name_r like '%������%'
for update
  

begin
  for rec in (select * from rate_plan_directions where pack_pack_id = 480
and name_r like '%������%') loop
insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select rpdr_seq.nextval, 0, 0, rec.name_e, rec.name_r, rec.name_1, rec.name_2, rec.navi_user, rec.navi_date, 1, 498, null from dual;
end loop;
end;


40786
40787 DEF
40788
40789 DEF

167278	1014
167279	2359
167280	2359
167281	2359
167282	2359



begin
  for rec in (select * From prefix_sets where pset_id between 167278 and 167282 and drct_drct_id != 1014) loop
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
select 
psdr_seq.nextval, 1, rec.pset_id, 40789, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
from dual;
  end loop;
end;

select * from trafics_by_directions 
where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 480 and rpdr_id = 33644)


begin
  for rec in () loop
    
  end loop;
end;



305=277
select * from prefix_sets where pset_id = 42686
select * from countries where cou_id = 13
select * from directions where drct_id = 1017
select * from pset_directions where pset_pset_id = 42686 and rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 277)
select * from trafics_by_directions where rpdr_rpdr_id in (36314) for update


select * from rate_plan_directions where pack_pack_id = 305

insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select rpdr_seq.nextval, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, trunc(sysdate), drtp_drtp_id, 305, mtxl_mtxl_id
from rate_plan_directions where pack_pack_id = 277

select * from pset_directions 
where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 305)

select * from rate_plan_directions where pack_pack_id = 305;
select * from rate_plan_directions where pack_pack_id = 277;

select t.rpdr_id as new_rpdr, tt.rpdr_id as old_rpdr from rate_plan_directions t, rate_plan_directions tt
where t.pack_pack_id = 305
and tt.pack_pack_id = 277
and t.name_1 = tt.name_1
and t.name_r = tt.name_r

begin
  for rec in (select t.rpdr_id as new_rpdr, tt.rpdr_id as old_rpdr from rate_plan_directions t, rate_plan_directions tt
where t.pack_pack_id = 305
and tt.pack_pack_id = 277
and t.name_1 = tt.name_1
and t.name_r = tt.name_r) loop
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    
select psdr_seq.nextval, number_history, pset_pset_id, rec.new_rpdr, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id
 from pset_directions 
where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 277) and rec.old_rpdr = rpdr_rpdr_id;
  end loop;
end;


select * from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 277)

select * from rate_plan_directions where name_r like '����������' and pack_pack_id = 305





