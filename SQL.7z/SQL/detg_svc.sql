select count(1), (select name from bvd_discount_tables where bvdt_id = bvdt_bvdt_id), c.bvdt_bvdt_id from bvd_clnt_bvdt c
where navi_date > to_date('07.08.2020','dd.mm.yyyy')
group by bvdt_bvdt_id


select (select name from bvd_discount_tables where bvdt_id = bvdt_bvdt_id), c.* from bvd_clnt_bvdt c
where navi_date > to_date('01.08.2020','dd.mm.yyyy')
and end_date > to_date('01.08.2020','dd.mm.yyyy')





select * from subs_histories where rtpl_rtpl_id = 503 and end_DATE > SYSDATE






WITH T AS (
SELECT id_cen
      ,MIN(decode(rn,1,v_4)) v_41
      ,MIN(decode(rn,1,v_2)) v_21
      ,MIN(decode(rn,2,v_4)) v_42
      ,MIN(decode(rn,2,v_2)) v_22
      ,MIN(decode(rn,3,v_4)) v_43
      ,MIN(decode(rn,3,v_2)) v_23
      ,MIN(decode(rn,4,v_4)) v_44
      ,MIN(decode(rn,4,v_2)) v_24
      ,MIN(decode(rn,5,v_4)) v_45
      ,MIN(decode(rn,5,v_2)) v_25
      ,MIN(decode(rn,6,v_4)) v_46
      ,MIN(decode(rn,6,v_2)) v_26
      ,MIN(decode(rn,7,v_4)) v_47
      ,MIN(decode(rn,7,v_2)) v_27
      ,MIN(decode(rn,8,v_4)) v_48
      ,MIN(decode(rn,8,v_2)) v_28
      ,MIN(decode(rn,9,v_4)) v_49
      ,MIN(decode(rn,9,v_2)) v_29
      ,MIN(decode(rn,10,v_4)) v_41_1
      ,MIN(decode(rn,10,v_2)) v_21_1
      ,MIN(decode(rn,11,v_4)) v_42_2
      ,MIN(decode(rn,11,v_2)) v_22_2
FROM (SELECT ID_CEN, V_1, V_2, V_3, V_4, row_number() over (PARTITION BY id_cen ORDER BY id_cen) rn FROM aak_tmp_v where v_2 not like 'ITEM_BDR' order by ID_CEN, v_1, v_2)
where id_cen like '%_90'
GROUP BY id_cen  
)

SELECT 
distinct detg, (select distinct detg from aak_tmp_ds where svc=v_42), tt.* FROM T tt
left join aak_tmp_ds ds on svc = v_41


where (v_43 in ('1778','1779')
and v_23 like 'prclId')or (v_42 in ('1778','1779')
and v_22 like 'prclId')
or (v_44 in ('1778','1779')
and v_24 like 'prclId')
or (v_45 in ('1778','1779')
and v_25 like 'prclId')or (v_46 in ('1778','1779')
and v_26 like 'prclId')or (v_47 in ('1778','1779')
and v_27 like 'prclId')



and v_43 is not null

select * from aak_tmp_v
where id_cen like '%_90' and v_2 like '������� ������ ONE-TIME_SERVICE'
for update

select * From aak_tmp_ds

200257
select * from detail_groups where detg_id in (84220,84221)


)
for update

select * from aak_tmp_ds
for update


select detg_seq.nextval from dual

 
create table aak_tmp_r (DETG varchar2(300),	SVC	varchar2(300), PRCL varchar2(300) )



select distinct detg, prcl from aak_tmp_r 
order by prcl

for update
