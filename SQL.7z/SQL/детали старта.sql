with t as (
select z.a_svc_id, count(1), (select name from t_svc_ref where svc_id = a_svc_id) as name_r from t_mts_res r, t_mts_zone z where billing_id = 202001
and r.mts_zone_id = z.mts_zone_id
and user_id in (select user_id from rtk_migr_batch_lists where batch_batch_id = 3000) 
group by z.a_svc_id
order by 3 
)
select ta.*, d.detg_id from t ta
join detail_groups d on d.svc_id = ta.a_svc_id 
--where lower(ta.name_r) like '%��%'
where detg_id in (
75155,
64479
)

select * from detail_groups where detg_id in (
75155,
64479
)





select * from t_mts_cod_ref cd 
where cd.mts_cod_id in (
select c.mts_cod_id from t_mts_zone z,t_mts_c_ref c where (z.a_svc_id=40416 or z.z_svc_id=40416) and z.mts_zone_id=c.mts_zone_id and c.date_end is null) ;

with t as (
select /*+ parallel (c,9) */ distinct lower(tt.name) as name from t_mts_c_ref c
join t_mts_cod_ref f on f.codetown = c.codetown
join t_mts_zone p on p.mts_zone_id = c.mts_zone_id
join t_mts_type_cross_vnd t on t.MTS_TYPE_VND_ID = c.MTS_TYPE_VND_ID
join detail_groups ta on ta.svc_id = p.a_svc_id
join t_svc_ref ts on ts.svc_id = ta.svc_id
join T_MTS_COD_REGION tt on tt.code_region = c.code_region 
where c.DATE_END is null
and p.a_svc_id != p.z_svc_id
and f.mts_cod_id in (
select c.mts_cod_id from t_mts_zone z,t_mts_c_ref c where (z.a_svc_id=40416 or z.z_svc_id=40416) and z.mts_zone_id=c.mts_zone_id and c.date_end is null) 
)
select LISTAGG('^'||name||'%*|', '') WITHIN GROUP (order by name) as list
from t
;



select a.*, (select bis_id from migr_mapping m where start_type = 'APUS' and bis_type = 'RTPL' and a.id_plan = m.start_id) RTPL,
(select detg_id from detail_groups dg where a.svc_id = dg.svc_id) DETG
from t_apus_plan a
where id_plan in (select start_id from migr_mapping where start_type = 'APUS' and bis_type = 'RTPL') -- ����������� �� BIS
and id_plan != 1123 -- ���� �����
order by a.name


SELECT * FROM T_MTS_COD_REGION 



select * from F008.T_MTS_PHONERUN_CODES t
where t.mts_cod_id = :m_mts_cod_id


select * from F008.T_MTS_COD_REF t
where code_region = 10420

select * from F008.T_WB_MTS_CUSTOM_LIST t
where t.mts_cod_id = :m_mts_cod_id


select distinct sys.USER_CONSTRAINTS.CONSTRAINT_NAME, sys.USER_CONSTRAINTS.TABLE_NAME, sys.USER_CONSTRAINTS.CONSTRAINT_TYPE,sys.USER_CONS_COLUMNS.column_name  from 
sys.USER_CONSTRAINTS inner join sys.USER_CONS_COLUMNS 
on sys.USER_CONS_COLUMNS.table_name = sys.USER_CONSTRAINTS.table_name
and
sys.USER_CONS_COLUMNS.owner = sys.USER_CONSTRAINTS.owner
where 1=1
--and sys.USER_CONSTRAINTS.table_name = 'DETAIL_GROUPS'
--and sys.USER_CONSTRAINTS.constraint_type = 'P'
and column_name like '%CODE_REGION%'




















