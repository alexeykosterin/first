select a.ab_lr_legal_status,a.ab_account,a.ab_id,ct.us_uc_code,ct.us_tfp_code,tp.tfp_name,ct.us_user_name,sc.twsc_session_date,sc.twsc_session_time,sc.twsc_session_id,sc.twsc_calling_station,sc.twsc_called_station,sc.twsc_inputoctets,sc.twsc_outputoctets,sc.twsc_logname,sc.twsc_cost
from sip_w.abonent a,sip_w.providers p,sip_w.ct_users ct,sip_w.ct_user_services us,sip_w.tb_wtmps_session_charges sc,sip_w.tb_tariff_plans tp
where a.ab_prv_id=p.prv_id and ct.us_tfp_code=tp.tfp_code
and (select prv_id from sip_w.providers ppp where CONNECT_BY_ISLEAF=1 connect by prv_id=prior prv_prv_id and prv_id<>1 start with ppp.prv_id=p.prv_id)=28
and a.ab_id=ct.us_ab_id and ct.us_user_name=us.uss_us_user_name and us.uss_sl_type='RADIUS'
--and ct.us_tfp_code in ('80LART_70060','80LART_70061','80LFRT_700517','80LFRT_700514','80LFRT_700515','80LFRT_700516','80LFRT_700513',
--'80LFRT_700512','80LFRT_700510','80PFRT_700500','80LFRT_700511','80PART_70068','80LART_70064','80LART_70063','80LART_70065','80LART_700660','80LART_70066','80LART_70062','80LGRT_72111')
--) where usa_val is not null group by us_uc_code,us_tfp_code,usa_value
--order by 1,2,6,7
--and exists(select 1 from sip_w.tb_tariff_services ts where ts.trs_to_date is null and ts.trs_base_cost<>0 and ts.trs_int_code not in ('GENERAL','RADIUSTM','RADIUSVL')and ts.trs_tfp_code=ct.us_tfp_code)
--group by ct.us_tfp_code
and sc.twsc_session_date between to_date('01.07.2019','dd.mm.yyyy') and to_date('31.07.2019 23:59:59','dd.mm.yyyy hh24:mi:ss')
and sc.twsc_abid=a.ab_id and sc.twsc_us_user_name=ct.us_user_name
and a.ab_account in (
'654000077615',
'654000082819',
'654000102836',
'654000081041',
'654000075433',
'654000134929',
'654000127851',
'654000058646',
'654000117524',
'654000060197',
'654000058960',
'654000024319',
'654000060751',
'654000060752',
'654000024861',
'654000025391',
'654000063280',
'654000033681',
'654000033109',
'654000060325',
'654000026028',
'654000026893',
'654000026698',
'654000071902',
'654000051748',
'654000027245',
'654000027974',
'654000065505',
'654000055926',
'654000037998',
'654000022863',
'654000038150',
'654000057202',
'654000023414',
'654000029482',
'654000043069',
'654000029708',
'654000041105',
'654000043309',
'654000039298',
'654000041075',
'654000067385',
'654000068134',
'654000055507',
'654000073958',
'654000070115',
'654000040287',
'654000040738',
'654000029731',
'654000029847',
'654000024148',
'654000024160',
'654000024394',
'654000004167',
'654000004557',
'654000003331',
'654000002698',
'654000003709',
'654000005636',
'654000005521',
'654000006201',
'654000000038',
'654000000054',
'654000000924',
'654000003514',
'654000006759',
'654000007049',
'654000006847',
'654000006981',
'654000006592',
'654000007907',
'654000007208',
'654000002300',
'654000008133',
'654000002455',
'654000002687',
'654000004568',
'654000009476',
'654000009533',
'654000017975',
'654000018502',
'654000013522',
'654000013706',
'654000009496',
'654000013242',
'654000013603',
'654000013689',
'654000012803',
'654000019111',
'654000014302',
'654000019464',
'654000011206',
'654000010818',
'654000010434',
'654000010521',
'654000011580',
'654000014451',
'654000014466',
'654000014334',
'654000019764',
'654000012280',
'654000022066',
'654000081871'
)


����� �������� �� �������

select a.ab_lr_legal_status,a.ab_account,a.ab_id,ct.us_uc_code,ct.us_tfp_code,ct.us_user_name
--ct.us_tfp_code,count(*)
from sip_w.abonent a,sip_w.providers p,sip_w.ct_users ct,sip_w.ct_user_services us
where a.ab_prv_id=p.prv_id
and (select prv_id from sip_w.providers ppp where CONNECT_BY_ISLEAF=1 connect by prv_id=prior prv_prv_id and prv_id<>1 start with ppp.prv_id=p.prv_id)=28
and a.ab_id=ct.us_ab_id and ct.us_user_name=us.uss_us_user_name and us.uss_sl_type='RADIUS'
--and ct.us_tfp_code in ('80LART_70060','80LART_70061','80LFRT_700517','80LFRT_700514','80LFRT_700515','80LFRT_700516','80LFRT_700513',
--'80LFRT_700512','80LFRT_700510','80PFRT_700500','80LFRT_700511','80PART_70068','80LART_70064','80LART_70063','80LART_70065','80LART_700660','80LART_70066','80LART_70062','80LGRT_72111')
--) where usa_val is not null group by us_uc_code,us_tfp_code,usa_value
--order by 1,2,6,7
and exists(
select 1 from sip_w.tb_tariff_services ts where ts.trs_to_date is null and ts.trs_base_cost<>0 and ts.trs_int_code not in ('GENERAL','RADIUSTM','RADIUSVL')
and ts.trs_tfp_code=ct.us_tfp_code)

���������� �� ������������ ����� 2602,2702
