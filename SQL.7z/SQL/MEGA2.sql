declare 
v_cnt4 varchar2(300);
v_rpdr number(30);
v_drct number(30);
v_count_pset number(30);
v_cou number(30);
v_count_cou number(30); 
v_count_drct number(30); 
TYPE PSETSET IS TABLE OF prefix_sets%ROWTYPE;
unaccounted PSETSET;

CURSOR c1 IS SELECT pset_id,cou_cou_id, drct_drct_id FROM prefix_sets;
TYPE NamePSET IS TABLE OF c1%ROWTYPE;
some_pset NamePSET;
begin
for rec4 in (select distinct name_loc, pack_id from aak_all_1 where pack_id = 363 and zone_id = 1
and rowid not in (select distinct ak.rowid from aak_all_1 ak
join rate_plan_directions on name_r like name_loc and pack_pack_id = 363 and zone_id = 1 and pack_id = 363)) loop

insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select 
rpdr_seq.nextval, 0, 0, translit(rec4.name_loc), rec4.name_loc, null, null, 
'AAK', trunc(sysdate), 1, rec4.pack_id, null
from dual;

select rpdr_id into v_rpdr from rate_plan_directions where name_r = rec4.name_loc and pack_pack_id = rec4.pack_id;
dbms_output.put_line('����� rpdr_id '||v_rpdr);
select count(drct_id) into v_count_drct from directions where name_r = rec4.name_loc;
if v_count_drct = 0 then
  dbms_output.put_line(rec4.name_loc||' �� ������� �����������');
else
select drct_id into v_drct from directions where name_r = rec4.name_loc;
end if;
dbms_output.put_line('drct_id '||v_drct);
select count(pset_id) into v_count_pset from prefix_sets where drct_drct_id = v_drct;
dbms_output.put_line('cou_id '||rec4.name_loc);
if v_count_pset = 0 then
select count(cou_id) into v_count_cou from countries where lower(name_r) = lower(rec4.name_loc);
if v_count_cou = 0 then
dbms_output.put_line(rec4.name_loc||' �� ������� ������');
else
select cou_id into v_cou from countries where lower(name_r) = lower(rec4.name_loc);
select * BULK COLLECT INTO unaccounted from prefix_sets where cou_cou_id = v_cou;
FOR i IN unaccounted.FIRST..unaccounted.LAST
LOOP
DBMS_OUTPUT.PUT_LINE('����� pset_id '||unaccounted(i).pset_id ||' � pset_directions');
insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
select psdr_seq.nextval, 1, unaccounted(i).pset_id, v_rpdr, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
from dual;
END LOOP;
end if;
else
select * BULK COLLECT INTO unaccounted from prefix_sets where drct_drct_id = v_drct;
FOR i IN unaccounted.FIRST..unaccounted.LAST
LOOP
DBMS_OUTPUT.PUT_LINE('����� pset_id '||unaccounted(i).pset_id||' � pset_directions');
insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
select psdr_seq.nextval, 1, unaccounted(i).pset_id, v_rpdr, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null
from dual;
END LOOP;
end if;
end loop;
end;


