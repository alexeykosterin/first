select * from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782)



delete from discount_plans where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782))


delete from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782)))
delete from discount_thread_volumes where dctr_dctr_id in (select dctr_id from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782))))


delete from discount_plan_histories where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782)))


delete from pack_rtpl where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782))

delete from discount_thread_depend where dctr_dctr_id in (select dctr_id from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782))))


ORA-02292: integrity constraint (BIS.TARH_PACK_FK) violated - child record found


select * from dba_objects where object_name like '%TARH_PACK_FK%'


delete from trafic_histories where pack_pack_id in (select pack_id from packs where navi_user like 'AAK%' and name_r like '%��%' and pack_id in (3733,3773,3774,3775,3776,3777,3778,3779,3780,3781,3782))

select * from aak_number_pool
where beginn like '7343%'

select * from back_number_pool_values
where value_1 like '843%'


select * from directions where name_r like '%����%' 

select * from prefix_sets where prefix like '84366'

create table aak_pref (prefix number(30), name_r varchar2(200))


select * from aak_pref for update

create table aak_tmp_1 (VNSET_ID number(30),	PACK_NAME	varchar2(300), ���_Zone_A	varchar2(300), ��_Zone_A_Key	varchar2(300), �������_$ number(10,5),	��������_$  number(10,5), 
��� number(10),	COD	number(10), CODE_REGION	number(30), HOUR_TYPE	varchar2(300), HOUR_TYPE_ID	number(30), RPDR varchar2(300),	DRCT varchar2(300)
)

alter table aak_tmp_1 drop column VNSET_ID BIS_DRCT varchar2(100)	PACK_ID	DRCT_ID	BIS DRCT

select * from aak_tmp_1
insert into aak_tmp_1 (
select * from aak_tmp_1 for update


select * from aak_number_pool 
where beginn like '7958%'
for update


select
(case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en
from aak_number_pool 
where beginn not like '79%'

select * from back_number_pool_values
where value_1 like '9%'

select level from dual connect by level < 2e4

truncate table number_pool_values

insert into number_pool_values (

select * from number_pool_values where zone_zone_id != 0
select * from number_pools
insert into number_pool_values (

declare 
v_num number;
begin
  v_num :=67681;
  for rec in (select
(case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en
from aak_number_pool where beginn like '79%') loop
v_num := v_num +1;
insert into number_pool_values (npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date, navi_user, navi_date, uniq_id)
select 2, 2, 0 , null, rec.beg, rec.en, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'BIS', trunc(sysdate), v_num
from dual;
  end loop;
end;


with table1 as (
select (select name_r from directions q where q.drct_id = t.drct_id) as name_r, REPLACE(AV_$, ',', '.') AS AV1_$, REPLACE(ZAK_$, ',', '.') AS ZAK1_$, t.* From aak_tmp_1 t
)
select name_r, count(1), av1_$, zak1_$, drct_id, pack_id  from table1
group by av1_$, zak1_$, drct_id, pack_id, name_r


select * from directions where drct_id = 3458
select * from subs_brd_identifications where original_ids = '600'


select * from prefix_sets where prefix like '87772%'
select * from matrix_dir_histories where pset_pset_id = 159328 and tfrg_tfrg_id = 60899
select * from pset_directions where drct_drct_id = 84


create table aak_mg_tmp (PREFIX_B	number(30), �������_$ varchar2(50),	��������_$ varchar2(50),	PACK_NAME varchar2(150))
select * from aak_mg_tmp for update



with table1 as (
select (select drct_drct_id from prefix_sets where to_char(prefix) = to_char(PREFIX_B) ) as DRCT_ID, PREFIX_B, REPLACE(�������_$, ',', '.') AS AV1_$, REPLACE(��������_$, ',', '.') AS ZAK1_$, PACK_NAME From aak_mg_tmp t
)
select DRCT_ID, count(1), av1_$, zak1_$  from table1 
group by PREFIX_B, av1_$, zak1_$

select /*+ parallel (c 10)*/ distinct (select name_r from directions where drct_id = drct_drct_id) as NAME_DRCT, drct_drct_id, REPLACE(�������_$, ',', '.') AS AV_$, REPLACE(��������_$, ',', '.') AS ZAK_$ From aak_mg_tmp
join prefix_sets c on prefix like prefix_b






select * from directions where name_r like '%���%'

with table1 as (
select (select name_r from directions q where q.drct_id = t.drct_id) as name_r, REPLACE(AV_$, ',', '.') AS AV1_$, REPLACE(ZAK_$, ',', '.') AS ZAK1_$, t.* From aak_tmp_1 t
)
select name_r, count(1), av1_$, zak1_$, drct_id, pack_id  from table1 where pack_id = 4037
and name_r not like '%����%' and name_r not like '%���%'
group by av1_$, zak1_$, drct_id, pack_id, name_r

delete from trafics_by_directions where pack_pack_id in (4037)
and rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id in (4037))

select * from rate_plan_directions
where navi_user like 'AAK 4037'

select rpdr_seq.nextval from dual

select max(rpdr_id) from rate_plan_directions

declare
v_cnt number;
v_cnt2 number;
v_mtxl number;
v_lcal number;
begin
  select max(mtxl_id) into v_mtxl from matrix_lists;
  for rec in (with table1 as (
select (select name_r from directions q where q.drct_id = t.drct_id) as name_r, REPLACE(AV_$, ',', '.') AS AV1_$, REPLACE(ZAK_$, ',', '.') AS ZAK1_$, t.* From aak_tmp_1 t
)
select name_r, count(1), av1_$, zak1_$, drct_id, pack_id  from table1 where pack_id = 4037
--where drct_id = 1087
group by av1_$, zak1_$, drct_id, pack_id, name_r
) loop
select rpdr_seq.nextval into v_cnt from dual;
insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select v_cnt, 0, 1, translit(rec.name_r), rec.name_r, 'IP '||rec.name_r, rec.name_r, 'AAK 4037', trunc(sysdate), 6,0,v_mtxl from dual;

for rec1 in (select tmcl_id from time_classes where tmcl_id in (82,83)) loop
  for rec2 in (select srls_id from serv_lists where srls_id in (104,105)) loop
    if rec2.srls_id = 104 then
      v_cnt2 := 104;
    elsif rec2.srls_id = 105 then
      v_cnt2 := 105;
    end if;
  if rec.name_r like '%����%' then
      v_lcal := 14;
    elsif rec.name_r like '%���%' then
      v_lcal := 13;
    else
      v_lcal := 13;
    end if;
insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, add_drct_id, add_rpdr_id, pack_pack_id, rtcm_rtcm_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select rec1.tmcl_id, 1, rec.av1_$,2, 0, v_cnt, null, to_date('01.01.2000','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK 4037', trunc(sysdate), 1,1,v_lcal,0,'Y',null,null,v_cnt2,0,
null,null,null,null,rec.pack_id,null,null,null,null,60899,100100,null,228 from dual;
end loop;
end loop;
end loop;
end;



select * from matrix_lists for update;
select rpdr_seq.nextval from dual;
select max(rpdr_id) from rate_plan_directions 
select * from rate_plan_directions where navi_user like 'AAK 4037'
select * from trafics_by_directions where navi_user like 'AAK 4037'

select * from rate_plan_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id) as min_rw
from rate_plan_directions where navi_user like 'AAK 4037'
) where rw <> min_rw)

select * from trafics_by_directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, add_drct_id, add_rpdr_id, pack_pack_id, rtcm_rtcm_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id) as min_rw
from trafics_by_directions where navi_user like 'AAK 4037'
) where rw <> min_rw)


select * from trafics_by_directions where rpdr_rpdr_id in (62067,
61971,
61901,
62110,
61651,
61762
)


select * from serv_lists where srls_id in (104,105)
select * from logic_calls where lcal_id in (13,14)



select mtxl_seq.nextval from dual;
select max(mtxl_id) from matrix_lists
select * from rate_plan_directions where mtxl_mtxl_id = 4

select * from trafics_by_directions 
WHERE SRLS_SRLS_ID = 104 AND TMCL_TMCL_ID = 82 AND RPDR_RPDR_ID = 102

select * from rate_plan_directions where pack_pack_id = 4037;
select * from trafics_by_directions where pack_pack_id = 4037;


104	�� �������
105	�� ��������

select * From logic_calls

13	VoIP �� ABC
14	VoIP �� DEF


select * from trafics_by_directions


select * from rate_plan_directions
where pack_pack_id in (645,727);

select * from trafics_by_directions
where rpdr_rpdr_id in (
                   select rpdr_id from rate_plan_directions
                   where pack_pack_id in (645,727)
)
and navi_user like 'AAK'


select * from rate_plan_directions where rpdr_id in (select rpdr_rpdr_id from trafics_by_directions
where rpdr_rpdr_id in (
                   select rpdr_id from rate_plan_directions
                   where pack_pack_id in (645,727)
)
)


select * from trafics_by_directions
where rpdr_rpdr_id in (
                   select rpdr_id from rate_plan_directions
                   where pack_pack_id in (645,727)
)



delete from trafics_by_directions
where rpdr_rpdr_id in (
                   select rpdr_id from rate_plan_directions
                   where pack_pack_id in (645,727)
)

delete from trafic_histories
where srls_srls_id in (96, 100)


select * from packs where name_r like '%�����%'

select * from packs where pack_id in (645,727)
select * from discount_plans where pacK_pack_id in (645,727,3795)



select count(1) from number_pool_values for update
--90280
select * From back_number_pool_values
where value_1 like 'D%'

select * from matrix_dir_histories where pset_pset_id = 45962
select * from prefix_sets where pset_id = 45962
delete from MATRIX_DIR_HISTORIES m where m.pset_pset_id is not null 
and not exists (select 1 from prefix_sets se where se.pset_id = m.pset_pset_id)
