﻿SELECT ''''||bl.account||''''
         ,bl.user_id
         ,bl.clnt_clnt_id ext_clnt_id
         ,cm.clnt_clnt_id clnt_id,
         bl.*, cm.*
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL)) 





with table1 as (
SELECT distinct bl.account 
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL))
)
select d.* From table1 b
join client_histories cl on cl.account = b.account
join bvd_clnt_bvdt d on cl.clnt_clnt_id = d.clnt_clnt_id
where d.end_date > sysdate




---только платный трафик
select * from rtk_migr_batch_lists bl,sip_w.abonent@stip_migr a where bl.batch_batch_id=3330 and bl.account=a.ab_account  
and exists(select 1 from t_other_svc os where os.billing_id=202003 and os.pack_num='IP' and os.summ<>0 and os.user_id=bl.user_id) 




select * from ps_migr.migr_batches where ext_batch_id = 3000 order by 1 desc 

select * from client_histories where clnt_clnt_id in (SELECT (select gf_clnt_id from ps_migr.key_clients where lg_clnt_id = bl.clnt_clnt_id and batch_batch_id = 186)--bl.clnt_clnt_id
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = 2702 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL)))


select * From client_histories where navi_user like '%PS_MIGR186%'




declare
v_end_date date;
v_start_date date;
v_limit number;
CURSOR c1
IS
select subs_id from subscribers where clnt_clnt_id in (select clnt_clnt_id From client_histories where navi_user like '%PS_MIGR186%')
;
cnumber  c1%ROWTYPE;
BEGIN
  v_limit := 1;
     OPEN c1;
      FETCH c1 INTO cnumber;
   while c1%FOUND loop
v_start_date := sysdate;
bis_month_charge.bis_subs_charges(startdate => to_date('01.09.2019','dd.mm.yyyy'), enddate => to_date('30.09.2019','dd.mm.yyyy'),subsid => cnumber.subs_id);
v_end_date := sysdate;
dbms_output.put_line(cnumber.subs_id);
--insert into TMP_AAK_LOG select v_start_date, v_end_date, cnumber.subs_id from dual;
v_limit := v_limit + 1;
if v_limit = 100 then
commit;
end if;
FETCH c1 INTO cnumber;
end loop;
commit;
   CLOSE c1;
END;





select last_day(TRUNC(SYSDATE,'MM')) from dual



----делаем любую таблицу с нужными нам клиентами
        
CREATE GLOBAL TEMPORARY 

create 
TABLE tmp_aak   
--ON COMMIT PRESERVE ROWS    
AS 
select clnt_clnt_id From client_histories where navi_user like '%PS_MIGR186%'

select * From tmp_aak
drop table tmp_aak
----нарезаем пачки с учетом этой таблицы с помощью нового параметра «P_ADD_CONDITION»
select clnt_clnt_id from tmp_aak
truncate table tmp_aak

select clnt_clnt_id from tmp_aak

DECLARE
  v_bill_month NUMBER := 201909;
  v_blcl_id    NUMBER := 190930000001969; --= SELECT * FROM bill_cycles bc WHERE bc.cycle_date=((last_day(to_date(to_char(201906)||'01','YYYYMMDD'))+1)-1/86400) AND bc.bct_bct_id=1;
  MAX_CLNT     clients.clnt_id%type;
  MIN_CLNT     clients.clnt_id%type;
BEGIN
  FOR cur IN (select blcl_id, blgr_blgr_id
                from bill_cycles
               where 1 = 1
                 and bct_bct_id = 1
                 and clst_clst_id = 3
                 and blcl_id = v_blcl_id) LOOP
  
    SELECT min(clnt_clnt_id), max(clnt_clnt_id)
      INTO MIN_CLNT, MAX_CLNT
      FROM tmp_aak;
  
    pack_billing_task_bgi.g_PARALLEL := 1;
  
    PACK_BILLING_TASK_BGI.BT_ADD_TASK(P_ADD_CONDITION => 'select clnt_clnt_id from tmp_aak where clnt_clnt_id = 432124',
                                      P_BILL_DATE     => ((last_day(to_date(to_char(v_bill_month) || '01',
                                                                            'YYYYMMDD')) + 1) -
                                                         1 / 86400), --дата окончания отчетного периода (последняя секунда месяца), за который планируется проводить биллинг (обязательно)
                                      P_BLCL_ID       => cur.blcl_id,
                                      P_PRIORITY      => 1,
                                      P_BLGR_ID       => cur.blgr_blgr_id, --биллинговая группа (опционально)
                                      P_AFKT_ID       => NULL,
                                      P_START_CLNT_ID => 432124, --интервал идентификаторов ЛС (идентификаторы клиентов ЕАСР) (опционально)
                                      P_END_CLNT_ID   => 432124, --интервал идентификаторов ЛС (идентификаторы клиентов ЕАСР) (опционально)
                                      P_START_ASSC_ID => NULL,
                                      P_END_ASSC_ID   => NULL,
                                      P_SETS_MAX      => 1000); --размерность биллинговой пачки (опционально)
  END LOOP;
END;


select * from bis.BT_TASKS where btts_id = 1259;
select * from bis.BT_SETS where btts_btts_id =1259 or bgirq_bgirq_id = 9874;
select * from bis.BT_BTSE_CLNT where btts_btts_id = 1259
or btse_btse_id in (select btse_id from bis.BT_SETS where bgirq_bgirq_id = 9874);

---запуск биллинга
begin
  pack_billing_task_bgi.start_bgi_proccess(p_btts_id => 1259);
end;





----попытки отправки в GUS ATTEMPT_NUM
select * from bgi_req_in_work t where t.bgirq_bgirq_id=8801;



select st.name, s.* from bis.bt_sets s, bis.bt_states st where s.btst_btst_id = st.btst_id
and btts_btts_id = 1259;

select * from sys_logs where message like '%432124%'
order by log_date desc

Îøèáêà : (client=432124): ORA-20003: ORA-20002: Äëÿ êëèåíòà (clnt_id = 432124) îòñóòñòâóåò çàïèñü â òàáëèöå BILLS_LAST. BT: ORA-06512: at "BIS.PACK_BILLING", line 31810
ORA-06512: at "BIS.PACK_BILLING", line 26109
ORA-06512: at "BIS.PACK_BILLING", line 29577 BT: ORA-06512: at "BIS.PACK_BILLING", line 30906
ORA-06512: at "BIS.PACK_BILLING", line 16531
 14:28:02
 
 
select * from bills t
left join BILLS_LAST on bill_id = last_bill_id
where t.clnt_clnt_id = 432124
and last_bill_id is null


select * from BILLS_LAST t where t.clnt_clnt_id = 432124

190930000001969

