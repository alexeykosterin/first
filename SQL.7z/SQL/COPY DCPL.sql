declare
P_NAVI_USER discount_plan_histories.navi_user%TYPE;
P_PACK_ID number := 3731;
CURSOR c1
IS
select dp.*, dph.* from discount_plans dp, discount_plan_histories dph
where dcpl_id = dcpl_dcpl_id and pack_pack_id = P_PACK_ID;
cnumber  c1%ROWTYPE;
BEGIN
  
select osuser into P_NAVI_USER from v$session where sid=(select sid from v$mystat where rownum=1);
     OPEN c1;
      FETCH c1 INTO cnumber;
   while c1%FOUND loop
insert into DISCOUNT_PLANS2 (DCPL_ID, DEF, RTPL_RTPL_ID, PACK_PACK_ID, DCTP_DCTP_ID, DCMR_DCMR_ID
      , DCMR_DCMR_ID1, DCMR_DCMR_ID2, DATP_DATP_ID, DCCL_DCCL_ID, DCST_DCST_ID, DCPA_DCPA_ID, DCCA_DCCA_ID, DCPL_COMMENT, DCGR_DCGR_ID, AUTOMATIC_YN, 
      BRT_INFORM, BRT_ACTION, PRIORITY, BRT_MIN_QUOTA, DPCT_DPCT_ID, DBSL_DBSL_ID, HISTORY_PERIOD, DELETE_UNUSED, DENY_PACK_ID, ALIGN_TUNT_ID, RNDT_RNDT_ID, 
      COMMON_CLCR_DCTR_VOLUME_YN, BIS_INFORM, MSRR_MSRR_ID, DMCT_DMCT_ID, IGNORE_SUBS_PACK_CHARGES, ALIGN_QUOTA_BY_DCTV, IS_FINAL, ROLL_OVER_ALLOWED, 
      ROLL_OVER_PACK_ID)
      values
        (
(select max(dcpl_id)+1 from DISCOUNT_PLANS2)
,'l' ----pack_name
,cnumber.RTPL_RTPL_ID
,1 ----pack_id
,cnumber.DCTP_DCTP_ID
,cnumber.DCMR_DCMR_ID
,cnumber.DCMR_DCMR_ID1
,cnumber.DCMR_DCMR_ID2
,cnumber.DATP_DATP_ID
,cnumber.DCCL_DCCL_ID
,cnumber.DCST_DCST_ID
,cnumber.DCPA_DCPA_ID
,cnumber.DCCA_DCCA_ID
,cnumber.DCPL_COMMENT
,cnumber.DCGR_DCGR_ID
,cnumber.AUTOMATIC_YN
,cnumber.BRT_INFORM
,cnumber.BRT_ACTION
,cnumber.PRIORITY
,cnumber.BRT_MIN_QUOTA
,cnumber.DPCT_DPCT_ID
,cnumber.DBSL_DBSL_ID
,cnumber.HISTORY_PERIOD
,cnumber.DELETE_UNUSED
,cnumber.DENY_PACK_ID
,cnumber.ALIGN_TUNT_ID
,cnumber.RNDT_RNDT_ID
,cnumber.COMMON_CLCR_DCTR_VOLUME_YN
,cnumber.BIS_INFORM
,cnumber.MSRR_MSRR_ID
,cnumber.DMCT_DMCT_ID
,cnumber.IGNORE_SUBS_PACK_CHARGES
,cnumber.ALIGN_QUOTA_BY_DCTV
,cnumber.IS_FINAL
,cnumber.ROLL_OVER_ALLOWED
,cnumber.ROLL_OVER_PACK_ID
         );
insert into Discount_Plan_Histories2 (DCPL_DCPL_ID, NUMBER_HISTORY, DURATION, DURATION_WAIT, START_USE, END_USE, START_DATE, END_DATE, NAVI_USER, NAVI_DATE, CLCR_VOLUME)
values
((select max(dcpl_id) from Discount_Plans2)
,1
,cnumber.DURATION
,cnumber.DURATION_WAIT
,cnumber.START_USE
,cnumber.END_USE
,cnumber.START_DATE
,cnumber.END_DATE
,P_NAVI_USER
,SYSDATE
,cnumber.CLCR_VOLUME
);
insert into dcpl_aak_test 
values ((select max(dcpl_id) from Discount_Plans2));
FETCH c1 INTO cnumber;
end loop;
   CLOSE c1;
for rec in (select dcpl_id from dcpl_aak_test) loop
  insert into discount_threads2 (dctr_id, phone_number, circuit_in, circuit_out, srls_srls_id, zntp_zntp_id, lcal_lcal_id, zone_zone_id, tmcl_tmcl_id, dctc_dctc_id, dcpl_dcpl_id, function_name, discount_zero_price, mth_srls_id, brt_warning, navi_user, navi_date, del_user, del_date, brt_priority, def, dtre_dtre_id, dvcn_dvcn_id, dvcn_volume, no_reserve, ignore_debet, ignore_balance_lock)
  select 
DCTR_SEQ.NEXTVAL, phone_number, circuit_in, circuit_out, srls_srls_id, zntp_zntp_id, lcal_lcal_id, zone_zone_id, tmcl_tmcl_id, dctc_dctc_id, rec.dcpl_id, function_name, discount_zero_price, mth_srls_id, brt_warning, P_NAVI_USER, sysdate, del_user, del_date, brt_priority, def, dtre_dtre_id, dvcn_dvcn_id, dvcn_volume, no_reserve, ignore_debet, ignore_balance_lock
from  discount_threads where dcpl_dcpl_id in (select distinct dcpl_id from discount_plans where pack_pack_id = P_PACK_ID);
end loop;
execute immediate 'truncate table dcpl_aak_test';
END;
