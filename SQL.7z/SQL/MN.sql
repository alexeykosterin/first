create table aak_dir_mn (name_r varchar2(100), prefix number(30))


select TO_NUMBER(PREFIX) from prefix_sets where prefix is not null


select * from aak_dir_mn_def
select * from aak_dir_mn 

with t as (
select TO_NUMBER(PREFIX)as PP, p.* from prefix_sets p )
select * from t where exists (select 1 from aak_dir_mn d where pp = d.PREFIX)



left join aak_dir_mn d on p.prefix = d.prefix





where exists (select 1 from aak_dir_mn d where to_number(p.prefix) = to_number(d.PREFIX))



select TO_NUMBER(PREFIX, '999') from dual



where COUNTR like '%����%'


update aak_dir_mn_def set countr = countr||' DEF'

for update


update aak_dir_mn set prefix = 810||prefix

update aak_dir_mn set name_r = name_r||' ABC'


create table aak_dir_mn_def (countr varchar2(100), oper varchar2(100), code_pref varchar2(100), code_op varchar2(1000), other varchar2(300))

drop table aak_dir_mn_def

select * from aak_dir_mn_def for update

create table aak_clob (all_zp clob)



ALTER TABLE aak_dir_mn_def MODIFY code_pref number(30) 

ALTER TABLE aak_dir_mn_def 
drop column other



select all_zp from aak_clob for update



select tt.rowid, t.*, tt.* from aak_dir_mn_def t
join aak_dir_mn_def tt on tt.code_pref = t.code_pref and tt.countr is null
where t.countr is not null
for update

select * from aak_dir_mn_def










DECLARE
      html clob /*:= '<body><table border="1" cellspacing="0" cellpadding="0">
<tr>
<td>
<div style="text-align: center;"><strong><span id="selection_index4" class="selection_index"></span>������</strong></div>
</td>
<td>
<div style="text-align: center;"><strong><span id="selection_index5" class="selection_index"></span>��������� ��������</strong></div>
</td>
<td>
<div style="text-align: center;"><strong><span id="selection_index6" class="selection_index"></span>��� ������</strong></div>
</td>
<td>
<div style="text-align: center;"><strong><span id="selection_index7" class="selection_index"></span>��� ���������� ���������</strong></div>
</td>
<td>
<div style="text-align: center;"><strong><span id="selection_index8" class="selection_index"></span>������� �������</strong></div>
</td>
</tr>
<tr>
<td rowspan="2"><span id="selection_index9" class="selection_index"></span> ���������� </td>
<td><span id="selection_index10" class="selection_index"></span> Afghan Wireless Communication Corporation </td>
<td style="text-align: center;"><span id="selection_index11" class="selection_index"></span> 93 </td>
<td><span id="selection_index12" class="selection_index"></span> 701, 702, 703, 704, 705, 706, 707, 708 </td>
<td rowspan="2"><a href="articles/pravila_nabora_telefonnyix_nomerov/pravila_nabora_nomerov_afganistana.html" target="_blank"><span id="selection_index13" class="selection_index"></span>��� ��������� �  ����������</a></td>
</tr></table></body>'*/;
BEGIN
  select all_zp into html from aak_clob;
  FOR r IN
  (SELECT rownum rn,
    td
  FROM xmltable('*/table/tr' passing xmltype(html) columns td xmltype path '.')
  )
  LOOP
    FOR c IN
    (SELECT cell
    FROM xmltable('*/td/.' passing r.td columns cell VARCHAR(200) path '.')
    )
    LOOP
      dbms_output.put_line('Row ' || r.rn || ': ' || c.cell);
    END LOOP;
  END LOOP;
END;





select * from aak_dir_mn_def where countr like '%�����%'
for update


select (case when CODE_OP like '% to %' then REPLACE(CODE_OP, ' to ', '-')
when CODE_OP like '%to %' then REPLACE(CODE_OP, 'to ', '-') end) from aak_dir_mn_def
where code_op like '%-%'

select * from aak_dir_mn_def

SELECT countr, REGEXP_SUBSTR(CODE_OP, '[^, ]+', REGEXP_INSTR(CODE_OP, '[^, ]+', 1, LEVEL, 0), 1)
FROM aak_dir_mn_def
where countr like '%��������%'
CONNECT BY REGEXP_INSTR(CODE_OP, '[^, ]+', 1, LEVEL) > 0 



with t as (

select * from aak_dir_mn_def where oper like 'Airtel Bharti'
for update

select d.*, y.* from aak_dir_mn_def d, xmltable(nvl(rtrim(regexp_replace(CODE_OP||' ', '(\S+)\s+', '"\1",'), ', '), '1 to 0')) y



with t as (
select t1.*, dbms_xmlgen.convert(xmlcast(column_value as varchar2(100)),1) column_value
from aak_dir_mn_def t1, xmltable(nvl(rtrim(regexp_replace(dbms_xmlgen.convert(CODE_OP)||' ', '(\S+)\s+', '"\1",'), ', '), '1 to 0')) x
) select regexp_replace(COLUMN_VALUE,',|;',''), tt.* From t tt




select * from aak_dir_start_mn_def
for update



with t as (
select t1.*, dbms_xmlgen.convert(xmlcast(column_value as varchar2(2000)),1) column_value
from aak_dir_start_mn_def t1, xmltable(nvl(rtrim(regexp_replace(dbms_xmlgen.convert(PREFIX_DEF)||' ', '(\S+)\s+', '"\1",'), ', '), '1 to 0')) x
) select regexp_replace(COLUMN_VALUE,',|;',''), tt.* From t tt







) select * from t


ORA-19280: XQuery dynamic type mismatch: expected atomic value - got node



SELECT
                extractValue(x.t_val,'section/@name') Name_var,
                extractValue(value(y),'/param') Pattern_var
           FROM
           (SELECT value(t) t_val
            FROM TABLE(xmlsequence(extract(XMLType(
                                                    '<config>
                                                    <section name = ''Strings_1''>
                                                            <section name = ''Patterns''>
                                                               <param name = ''1''>111111111111111</param>
                                                               <param name = ''22''>100010000010001</param>
                                                           </section>
                                                   </section>
                                                   <section name = ''Payout_1''>
                                                           <section name = ''Payout''>
                                                               <param name = ''1''>10000</param>
                                                               <param name = ''22''>5</param>
                                                           </section>
                                                   </section>
                                                   </config>
                                                   '                                               )
                                          ,'/config/section'))) t) x
        ,table(xmlsequence(Extract(x.t_val,'/section/section/param'))) y
   ;







select * from aak_dir_mn_def where code_op like '%x%'
for update



with t as (
select regexp_substr(code_op, '(\d+)(, |$)', 1, rownum, 'c', 1) ok, a.*
from aak_dir_mn_def a
where countr like '%������%'
connect by level <= regexp_count(code_op, '\d+(, |$)')
)
select count(1) from t where ok is not null



select regexp_count(code_op, '\d+(,|$)'), t.* from aak_dir_mn_def t
where countr like '%������%'


for update


begin
execute immediate 'truncate table aak_temp';
execute immediate 'drop table aak_temp';
end;

CREATE GLOBAL TEMPORARY 
TABLE aak_temp   
ON COMMIT PRESERVE ROWS    
AS
with t as (
select t1.*, dbms_xmlgen.convert(xmlcast(column_value as varchar2(2000)),1) column_value
from aak_dir_start_mn_def t1, xmltable(nvl(rtrim(regexp_replace(dbms_xmlgen.convert(PREFIX_DEF)||' ', '(\S+)\s+', '"\1",'), ', '), '1 to 0')) x
) select tt.COUNTR_NAME, regexp_replace(COLUMN_VALUE,',|;','') as PREF_1, tt.countr_id From t tt;


select * From aak_temp

select SUBSTR(t.COUNTR_NAME, 1, INSTR(t.COUNTR_NAME, ' ')-1)||' DEF' AS name_1, t.* from aak_dir_start_mn_def t
where countr_name like '%�����%'

update aak_dir_start_mn_def t set COUNTR_NAME = SUBSTR(t.COUNTR_NAME, 1, INSTR(t.COUNTR_NAME, ' ')-1)||' DEF'
where countr_name like '%�����%'



select * from aak_dir_start_mn_def

drop table aak_dir_start_mn_def
select * from aak_dir_start_mn_def for update

create table aak_dir_start_mn_def (
countr_name varchar2(100),
COUNTR_ID	vARCHAR2(100),
PREFIX_DEF	VARCHAR2(2000))		


truncate table aak_temp;
drop table aak_temp;




begin
for rec in () loop
  
end loop;
end;


select * From aak_temp
where PREF_1 like '%-%'


select t1.*, dbms_xmlgen.convert(xmlcast(column_value as varchar2(2000)),1) column_value
from aak_temp t1, xmltable(nvl(rtrim(regexp_replace(dbms_xmlgen.convert(PREF_1)||' ','(\S+)\s+', '"\1"-'), '-'), '1 to 0')) x
where PREF_1 like '%-%'



SELECT SUBSTR(t.PREF_1, 1, INSTR(t.PREF_1, '-')-1) AS name_1,
       SUBSTR(t.PREF_1, INSTR(t.PREF_1, '-')+1) AS name_2, t.*
FROM aak_temp t 
where PREF_1 like '%-%'


begin
  for rec in (SELECT SUBSTR(t.PREF_1, 1, INSTR(t.PREF_1, '-')-1) AS name_1,
       SUBSTR(t.PREF_1, INSTR(t.PREF_1, '-')+1) AS name_2, t.*
FROM aak_temp t 
where PREF_1 like '%-%'
) loop
begin
   for t in 
      (
      select regexp_substr(ll,'[^-]+',1,1) l1 , regexp_substr(ll,'[^-]+',1,2) l2 , ll.* -- ���������� ��������� ��� �������� ������ ���������
      from 
      (
      select  regexp_substr(rec.pref_1,'[^,]+',1,level) ll -- ���������� ��������� ��� ������ � ����������
       from dual
      connect by level <=  REGEXP_COUNT(rec.pref_1,',')+1
      ) ll
      ) loop 
        for i in t.l1..t.l2 loop
      --    dbms_output.put_line(i); -- ����� ��������
      insert into aak_temp (COUNTR_NAME, pref_1, countr_id)
      select rec.countr_name, i, rec.countr_id from dual;
        end loop;
      --  dbms_output.put_line(''); -- ������ ������ ��� ��������� ���������
      end loop;
      exception
  when others then dbms_output.put_line (rec.pref_1||'!!!!!!!');
      end;
      end loop;
end;

delete 
FROM aak_temp t 
where PREF_1 like '%-%'




with t as (
select pref_1, '810'||countr_id as countr_id from aak_temp t )
select * from t
join aak_dir_mn on countr_id = prefix








