with t as (
select to_char(round(in_balance_$,1)) as BIS, REPLACE(round(REPLACE(to_char(ps.cdr_udf), ',', '.'),1), ',', '.') as CTAPT ,ps.* from CALLS_00_092018 ps where 1=1 
and file_name like '%31%aak_%')
select a.BIS, a.CTAPT, a.duration/60, a.* from t a
where BIS != CTAPT


declare
v_cnt1 number(10);
v_cnt2 number(10);
v_cnt3 number(10);
v_var varchar2(100);
begin
  for rec in (with t as (
select to_char(round(in_balance_$,1)) as BIS, REPLACE(round(REPLACE(to_char(ps.cdr_udf), ',', '.'),1), ',', '.') as CTAPT ,ps.* from CALLS_00_092018 ps where 1=1 
and file_name like '%31%aak_%')
select a.* from t a
where BIS != CTAPT
)
loop
  select ph.subs_subs_id into v_cnt1 
from phone_histories ph,number_sets ns,subscribers sb 
where ph.end_date > sysdate
and ns.nset_id = ph.nset_nset_id
and sb.subs_id=ph.subs_subs_id
and msisdn like rec.msisdn;
select pack_pack_id into v_cnt2 from subs_packs where subs_subs_id = v_cnt1 and pack_pack_id in (select distinct pack_id from aak_all_1);


select price_$ into v_cnt3 from trafics_by_directions where rpdr_rpdr_id in (select rpdr_rpdr_id from pset_directions where pset_pset_id = rec.pset_pset_id
and rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = v_cnt2) and lcal_lcal_id = rec.lcal_lcal_id and tmcl_tmcl_id = rec.tmcl_tmcl_id
and srls_srls_id = rec.srls_srls_id);
select (select name_r from countries where cou_id = cou_cou_id) into v_var from prefix_sets where pset_id = rec.pset_pset_id;
dbms_output.put_line(v_cnt1 ||' '
|| v_cnt2||' ��� pset_id = '||rec.pset_pset_id||' ������ '||v_var||' ��������� � ������� CALLS '||round(rec.bis/round(rec.duration/60,2),2)||', � trafics_by_dir ����������� '|| v_cnt3);
end loop;
end;


select * from subs_packs where subs_subs_id = 2014435
select * From pset_directions where pset_pset_id = 44197 and rpdr_rpdr_id in (select rpdr_id from rate_plan_directions where pack_pack_id = 504)
select * from prefix_sets where pset_id = 42414
select * from countries where cou_id = 7
select * From rate_plan_directions where pack_pack_id = 504 and name_r like '%������%'
delete From rate_plan_directions where pack_pack_id = 504 and name_r like '%������%'

select * from trafics_by_directions where rpdr_rpdr_id in (40629,42711)
delete from trafics_by_directions where rpdr_rpdr_id in (40629,42711)
select * from pset_directions where rpdr_rpdr_id in (45272,45273)
delete from pset_directions where rpdr_rpdr_id in (40629,42711)



