create table tmp_mth_tar_aak as 


with t as (select distinct (case when upper(id_name) like '%PRCL%' then (select def from price_list where id_number = prcl_id) 
when upper(id_name) like '%PACK%' then (select name_r from packs where id_number = pack_id) when upper(id_name) like '%PACKAGE%' then (select name_r from packs where id_number = pack_id)
when upper(id_name) like '%SRLS%' then (select def from serv_lists where id_number = srls_id) when upper(id_name) like '%RTPL%' then (select name_r from rate_plans where id_number = rtpl_id)
when upper(id_name) like '%SRLS%MTH%' then (select def from serv_lists where id_number = srls_id) end) as PP,
a.* from aak_ma a) select * from t join (with table_c as (
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,1,'i'),';',','), '[[:space:]]+', '') as A, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,2,'i'),';',','), '[[:space:]]+', '') as B, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,3,'i'),';',','), '[[:space:]]+', '') as B, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,'[^;]+',1,4,'i'),';',','), '[[:space:]]+', '') as B, ID_PRICE, PRICE from aak_ma2
where price is not null)
select rownum Numbe, cc.* from table_c cc where A is not null) tt on tt.ID_PRICE =  CLST_NAME join mth_clusters mm on mm.def = A where PP is not null 
and ID_PRICE like '�-00004'
and clst_id = 74
--order by id_price, clst_id


------------------------------------
declare
v_rtpl number(10) default 0;
v_rtpl_et number(10);
v_pack number(10) default 0;
v_srls number(10);
v_prcl number(10) default 0;
v_navi varchar2(100) default 'not null';
v_count_rtpl number(10) default 0;
v_count_pack number(10) default 0;
v_price mth_tarif_histories.AMOUNT%TYPE;
table_not_exists exception;
pragma exception_init(table_not_exists,-942);
begin
  select osuser into v_navi from v$session where sid=(select sid from v$mystat where rownum=1);
  execute immediate 'create or replace procedure ins_mth_tarif_his_aak ( p_rtpl IN mth_tarif_histories.rtpl_rtpl_id%TYPE default 0,p_pack IN mth_tarif_histories.pack_pack_id%TYPE default 0,
p_srls IN mth_tarif_histories.srls_srls_id%TYPE default 0,p_clst IN mth_tarif_histories.clst_clst_id%TYPE default 0,p_price IN mth_tarif_histories.AMOUNT%TYPE,
p_comments IN mth_tarif_histories.comments%TYPE default NULL,p_navi IN mth_tarif_histories.navi_user%TYPE default ''BIS'') IS
BEGIN INSERT INTO mth_tarif_histories_akk (rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id,clst_clst_id, mtcg_mtcg_id, amount, RATE_FOR_ONE_DAY, fee_tax_included, tarif_modify, comments,start_date, 
end_date, navi_user, navi_date,eval_disc_rate, eval_disc_days) VALUES (p_rtpl, p_pack, p_srls, 0 , 600, p_clst, 3, p_price, ''N'', ''N'', ''N'' ,p_comments, to_date(''01.01.2018'',''dd.mm.yyyy''),
to_date(''31.12.2999'',''dd.mm.yyyy''),p_navi, trunc(sysdate), 0,0);END;';
  execute immediate 'drop table tmp_mth_tar_aak';
  execute immediate 'create table tmp_mth_tar_aak as with t as (select distinct (case when upper(id_name) like ''%PRCL%'' then (select def from price_list where id_number = prcl_id) 
when upper(id_name) like ''%PACK%'' then (select name_r from packs where id_number = pack_id) when upper(id_name) like ''%PACKAGE%'' then (select name_r from packs where id_number = pack_id)
when upper(id_name) like ''%SRLS%'' then (select def from serv_lists where id_number = srls_id) when upper(id_name) like ''%RTPL%'' then (select name_r from rate_plans where id_number = rtpl_id)
when upper(id_name) like ''%SRLS%MTH%'' then (select def from serv_lists where id_number = srls_id) end) as PP,
a.* from aak_ma a) select * from t join (with table_c as (
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,''[^;]+'',1,1,''i''),'';'','',''), ''[[:space:]]+'', '''') as A, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,''[^;]+'',1,2,''i''),'';'','',''), ''[[:space:]]+'', '''') as B, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,''[^;]+'',1,3,''i''),'';'','',''), ''[[:space:]]+'', '''') as B, ID_PRICE, PRICE from aak_ma2
where price is not null
union all 
select regexp_replace(REPLACE(regexp_SUBSTR(clst_name,''[^;]+'',1,4,''i''),'';'','',''), ''[[:space:]]+'', '''') as B, ID_PRICE, PRICE from aak_ma2
where price is not null)
select rownum Numbe, cc.* from table_c cc where A is not null) tt on tt.ID_PRICE =  CLST_NAME join mth_clusters mm on mm.def = A where PP is not null';
  for rec1 in (select distinct clst_name from aak_ma) loop
    for rec2 in (select distinct clst_id, def from mth_clusters where clst_id in (select distinct clst_id from tmp_mth_tar_aak)) loop
      ---����������� RTPL
      select distinct id_number into v_rtpl_et from tmp_mth_tar_aak where upper(ID_NAME) like '%RTPL%';
      select count(1) into v_count_rtpl from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%RTPL%';
      if v_count_rtpl > 1 then
        dbms_output.put_line('��� '||rec1.clst_name||' � '||rec2.clst_id||' � ������� ����������� ������ 1 RTPL_ID');
      elsif v_count_rtpl = 0 then
        dbms_output.put_line('��� '||rec1.clst_name||' � '||rec2.clst_id||' � ������� ��� RTPL_ID');
        v_rtpl :=0;
      else
      select id_number into v_rtpl from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%RTPL%';
      end if;
      dbms_output.put_line(v_rtpl);
      
      ---����������� PACK
      select count(1) into v_count_pack from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%PACK%';
      if v_count_pack > 1 then
        dbms_output.put_line('��� '||rec1.clst_name||' � '||rec2.clst_id||' � ������� ����������� ������ 1 PACK_ID');
        for rec_pack in (select id_number from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%PACK%') loop
          select price into v_price from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%PACK%' and id_number = rec_pack.id_number;
          if v_price is null then
            dbms_output.put_line('��� ��������� ��� ������ PACK RTPL SRSL (1)');
          else
            
          begin
          select id_number into v_srls from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%';
          exception
            when NO_DATA_FOUND then null;
              dbms_output.put_line('NO DATA FOUND for v_srls!');
          end;
          
          if v_srls > 0 then          
          for rec_srls in (select id_number from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%') loop
          ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => rec_pack.id_number, p_srls => rec_srls.id_number, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi);
          end loop;
          else
            ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => rec_pack.id_number, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi);
          end if;
          end if;
                  
        end loop;
      elsif v_count_pack = 0 then
        dbms_output.put_line('��� '||rec1.clst_name||' � '||rec2.clst_id||' � ������� ��� PACK_ID');
        v_pack :=0;
         -- select price into v_price from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%' and id_number = v_pack;
          select count(1) into v_srls from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%';
          if v_srls > 0 then          
          for rec_srls in (select id_number from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%') loop
          select price into v_price from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%' and id_number = rec_srls.id_number;
          ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => v_pack, p_srls => rec_srls.id_number, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi);
          end loop;
         -- else
            --ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => v_pack, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi);
          end if;
      else
      select id_number into v_pack from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%PACK%';
      dbms_output.put_line(v_pack);
      
      
          select price into v_price from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%PACK%' and id_number = v_pack;
          if v_price is null then
            dbms_output.put_line('��� ��������� ��� ������ PACK RTPL SRSL (2)');
          else
          select count(1) into v_srls from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%';
          
          if v_srls > 0 then          
          for rec_srls in (select id_number from tmp_mth_tar_aak where ID_PRICE like rec1.clst_name and clst_id = rec2.clst_id and upper(ID_NAME) like '%SRLS%') loop
          ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => v_pack, p_srls => rec_srls.id_number, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi);
          end loop;
          else
            ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => v_pack, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi);
          end if;
          
          end if;
      
      
      end if;

    end loop;
  end loop;
  
begin
  for rec_prcl in (select distinct id_number, price from tmp_mth_tar_aak where upper(ID_NAME) like '%PRCL%') loop
    insert into price_items (prci_id, prcl_prcl_id, rtpl_rtpl_id, price_$, msru_msru_id, navi_user, navi_date, number_history, start_date, end_date, cur_cur_id, xtyp_xtyp_id, price_$_with_tax, tax_rate, flag_cs)
    select prci_seq.nextval, rec_prcl.id_number, v_rtpl_et, rec_prcl.price*0.833333, 1, v_navi, trunc(sysdate), 1, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'),
    1, 1, rec_prcl.price, 1.2, null from dual;
  end loop;
end;

  
exception 
when table_not_exists then null;
when NO_DATA_FOUND then null;
dbms_output.put_line('NO DATA FOUND!');
end;





select distinct id_number, price from tmp_mth_tar_aak where upper(ID_NAME) like '%PRCL%'

select * from price_items 
where rtpl_rtpl_id = 299
select * from exchange_types

select prci_seq.nextval from dual


select distinct id_number, price from tmp_mth_tar_aak where upper(ID_NAME) like '%PRCL%'

select * from tmp_mth_tar_aak where ID_PRICE like '�-00004' and clst_id = 1000 
and upper(ID_NAME) like '%PACK%'


select * from price_items where navi_user like 'A.Kos%'


select * from mth_tarif_histories_akk;
select * from mth_tarif_histories where navi_user like '%TRAN_ID%';

rtpl_rtpl_id in (211);



select * from mth_tarif_histories_akk t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, tarif_modify, eval_disc_rate, eval_disc_days) as min_rw
from mth_tarif_histories_akk
) where rw <> min_rw)




select * from mth_tarif_histories where rtpl_rtpl_id in (211);
select * from mth_tarif_histories_akk where rtpl_rtpl_id in (211);









select * from mth_tarif_histories where rtpl_rtpl_id not in (384,299) 

and srls_srls_id in (210,211,212);

delete from mth_tarif_histories_akk where rtpl_rtpl_id = 299


select * from trafic_histories
where rtpl_rtpl_id = 341 for update






mth_tarif_histories_akk(rtpl_rtpl_id, pack_pack_id, srls_srls_id, bndl_bndl_id, macr_macr_id, brnc_brnc_id, clst_clst_id, mtcg_mtcg_id, amount, rate_for_one_day, fee_tax_included, tarif_modify, comments, start_date, end_date, navi_user, navi_date, eval_disc_rate, eval_disc_days)
select * From mth_tarif_histories_akk;
select * From mth_tarif_histories where rtpl_rtpl_id = 384 and pack_pack_id in (210,215) and srls_srls_id in (211,212) and clst_clst_id in (1000,1001, 2001,2000);












select * from mth_tarif_histories





select price from tmp_mth_tar_aak where ID_PRICE like '�-00005' and clst_id = 1000 and upper(ID_NAME) like '%PACK%' and id_number = 210
select id_number from tmp_mth_tar_aak where ID_PRICE like '�-00005' and clst_id = 1000 and upper(ID_NAME) like '%SRLS%';





select * From mth_tarif_histories_akk


select * from mth_tarif_histories where navi_date = trunc(sysdate)

ins_mth_tarif_his_aak(p_rtpl => v_rtpl, p_pack => v_pack, p_srls => v_srls, p_clst => rec2.clst_id, p_price => v_price, p_comments => rec1.clst_name, p_navi => v_navi)










select * From mth_tarif_histories
select * From price_list
select * From price_items
select * from EXTERNAL_CHARGES t














