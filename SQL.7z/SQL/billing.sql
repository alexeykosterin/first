PACKAGE BODY PACK_BILLING_TASK_BGI_1 IS











































CURRENT_VERSION_PB  CONSTANT VARCHAR2(20) := '118.03';

G_BT_APPL_ID NUMBER := 1;

PRM_BTPR_MAX APP_PARAMETERS.PRMT_ID%TYPE := 10237; 
PRM_TYPES_NOT_BILL APP_PARAMETERS.PRMT_ID%TYPE := 1083; 
PRM_SETS_MIN APP_PARAMETERS.PRMT_ID%TYPE := 10241; 

PRM_CHDB_USE_MODE APP_PARAMETERS.PRMT_ID%TYPE := 10261; 

PRM_SETS_FLAG APP_PARAMETERS.PRMT_ID%TYPE := 10271; 

PRM_AGGREGATE_BY_MACRO_TZ CONSTANT APP_PARAMETERS.PRMT_ID%TYPE := 10288;

GC_BTST_WAITING_FOR_RUN       CONSTANT BT_STATES.BTST_ID%TYPE := 1;  
GC_BTST_PROCESSING            CONSTANT BT_STATES.BTST_ID%TYPE := 2;  
GC_BTST_COMPLETED             CONSTANT BT_STATES.BTST_ID%TYPE := 3;  
GC_BTST_ERROR                 CONSTANT BT_STATES.BTST_ID%TYPE := 4;  
GC_BTST_ASSC_ERROR            CONSTANT BT_STATES.BTST_ID%TYPE := 5;  
GC_BTST_REQUESTING_GUS_AGGR   CONSTANT BT_STATES.BTST_ID%TYPE := 6;  
GC_BTST_READY_FOR_BILLING     CONSTANT BT_STATES.BTST_ID%TYPE := 7;  
GC_BTST_CALC_DISC_PRMTS       CONSTANT BT_STATES.BTST_ID%TYPE := 8;  
GC_BTST_ROLLBACK              CONSTANT BT_STATES.BTST_ID%TYPE := 9;  
GC_BTST_ROLLBACK_AND_AGGR_DEL CONSTANT BT_STATES.BTST_ID%TYPE := 10; 


GC_BTST_WAITING_FOR_ROLLBACK CONSTANT BT_STATES.BTST_ID%TYPE := 11; 
GC_BTST_ROLLBACK_ERROR       CONSTANT BT_STATES.BTST_ID%TYPE := 12; 


G_BTPR_MAX_FUNC  APP_PARAMETERS.VALUE_STRING%TYPE;
G_TYPES_NOT_BILL APP_PARAMETERS.VALUE_STRING%TYPE;
G_APPL_LANG NUMBER    := 2;  
G_SETS_MIN NUMBER     := 100;

G_CHDB_USE_MODE NUMBER := 0; 



G_FLG_1 NUMBER; 
G_FLG_2 NUMBER; 
G_FLG_3 NUMBER; 
G_FLG_4 NUMBER; 
G_FLG_5 NUMBER; 
G_FLG_6 NUMBER; 
G_FLG_7 NUMBER; 
G_FLG_8 NUMBER;
G_FLG_9 NUMBER;

G_LOCK_ASSC_BTSE_ON NUMBER := 0; 

PRM_AFTER_TIME APP_PARAMETERS.PRMT_ID%TYPE := 10284; 
                                                     
G_MAX_COUNT NUMBER := 5; 
G_TIME_OUT NUMBER := 60; 

PRM_BFAM_BILL_JOB_CLASS APP_PARAMETERS.PRMT_ID%TYPE := 10294; 
G_BFAM_BILL_JOB_CLASS APP_PARAMETERS.VALUE_STRING%TYPE;



FUNCTION GET_VERSION RETURN VARCHAR2
IS
BEGIN
  RETURN CURRENT_VERSION;
END;



FUNCTION TO_SYS_LOG(P_MESSAGE  IN SYS_LOGS.MESSAGE%TYPE,
                    P_SLOG_ID  IN SYS_LOGS.SLOG_SLOG_ID%TYPE DEFAULT NULL,
                    P_MSG_TYPE IN APPLICATION_MESSAGES.APMT_APMT_ID%TYPE DEFAULT LOG_COMMON.INFOMSG
                   ) RETURN NUMBER
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  V_SLOG_ID SYS_LOGS.SLOG_ID%TYPE;
BEGIN
  V_SLOG_ID := LOG_COMMON.INSERT_LOG_RECORDS(MESS => P_MESSAGE,
                                             APPL => G_BT_APPL_ID,
                                             APMT => P_MSG_TYPE,
                                             SLOG => P_SLOG_ID);
  COMMIT;
  RETURN V_SLOG_ID;
END;

FUNCTION GET_MSG(P_MSG_ID     IN NUMBER,
                 P_ARGUMENT_1 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_2 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_3 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_4 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_5 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_6 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_7 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_8 IN VARCHAR2 DEFAULT NULL,
                 P_ARGUMENT_9 IN VARCHAR2 DEFAULT NULL
                ) RETURN VARCHAR2
IS
BEGIN
  RETURN GET_APPLICATION_MESSAGE( P_MSG_ID, G_APPL_LANG,
                                  P_ARGUMENT_1, P_ARGUMENT_2, P_ARGUMENT_3, P_ARGUMENT_4,
                                  P_ARGUMENT_5, P_ARGUMENT_6, P_ARGUMENT_7, P_ARGUMENT_8,
                                  P_ARGUMENT_9);
END;

PROCEDURE RAISE_ERROR(P_MSG_ID     IN NUMBER,
                      P_ARGUMENT_1 IN VARCHAR2 DEFAULT NULL,
                      P_ARGUMENT_2 IN VARCHAR2 DEFAULT NULL,
                      P_ARGUMENT_3 IN VARCHAR2 DEFAULT NULL,
                      P_BACKTRACE  IN VARCHAR2 DEFAULT NULL
                     )
IS
BEGIN
  RAISE_APPLICATION_ERROR(-20001, GET_MSG(P_MSG_ID, P_ARGUMENT_1, P_ARGUMENT_2, P_ARGUMENT_3) || P_BACKTRACE);
END;



FUNCTION GET_PRMT(P_PRMT_ID IN APP_PARAMETERS.PRMT_ID%TYPE
  ) RETURN APP_PARAMETERS%ROWTYPE
IS
  RES APP_PARAMETERS%ROWTYPE;
BEGIN
  FOR REC IN (SELECT *
                FROM APP_PARAMETERS
               WHERE PRMT_ID = P_PRMT_ID
             ) LOOP
    RETURN REC;
  END LOOP;
  RETURN RES;
END;


PROCEDURE INIT_PARAMS
IS
  RES APP_PARAMETERS%ROWTYPE;
BEGIN
  
  RES := GET_PRMT(PRM_BTPR_MAX);
  G_BTPR_MAX_FUNC := RES.VALUE_STRING; 
  G_BTPR_MAX := NVL(RES.VALUE_NUMBER, G_BTPR_MAX); 
  
  RES := GET_PRMT(PRM_TYPES_NOT_BILL);
  G_TYPES_NOT_BILL:= NVL(REPLACE(RES.VALUE_STRING,' ',''), '-');
  
  RES := GET_PRMT(PRM_SETS_MIN);
  G_SETS_MIN := NVL(RES.VALUE_NUMBER, G_SETS_MIN); 
  
  RES := GET_PRMT(24);
  G_APPL_LANG := NVL(RES.VALUE_NUMBER, G_APPL_LANG);

  
  
  RES := GET_PRMT(PRM_CHDB_USE_MODE);
  G_CHDB_USE_MODE := NVL(RES.VALUE_NUMBER, 0);

  
  
  
  RES := GET_PRMT(PRM_SETS_FLAG);
  G_FLG_1 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 1, 1)), 0);
  G_FLG_2 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 2, 1)), 0);
  G_FLG_3 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 3, 1)), 0);
  G_FLG_4 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 4, 1)), 0);
  G_FLG_5 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 5, 1)), 0);
  G_FLG_6 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 6, 1)), 0);
  G_FLG_7 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 7, 1)), 0);
  G_FLG_8 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 8, 1)), 0);
  G_FLG_9 := NVL(TRIM(SUBSTR(RES.VALUE_STRING, 9, 1)), 0);

  
  RES := GET_PRMT(PRM_AFTER_TIME);
  G_MAX_COUNT := NVL(RES.VALUE_NUMBER, G_MAX_COUNT); 
  G_TIME_OUT  := NVL(TO_NUMBER(RES.VALUE_STRING), G_TIME_OUT)/24/60/60; 
  
  RES := GET_PRMT(PRM_BFAM_BILL_JOB_CLASS);
  G_BFAM_BILL_JOB_CLASS := NVL(RES.VALUE_STRING, 'DEFAULT_JOB_CLASS');
  
END;





PROCEDURE ALLOCATE_NAME(
  P_LOCK_NAME  IN  VARCHAR2,
  P_LOCKHANDLE OUT VARCHAR2
) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  DBMS_LOCK.ALLOCATE_UNIQUE(P_LOCK_NAME, P_LOCKHANDLE);
  COMMIT;
END;


FUNCTION U_LOCK(P_LOCK_NAME IN VARCHAR2, 
                P_AUTO_DROP IN NUMBER DEFAULT 1, 
                P_LOCKHANDLE OUT VARCHAR2
  ) RETURN BOOLEAN 
IS
BEGIN
  ALLOCATE_NAME(P_LOCK_NAME, P_LOCKHANDLE);
  
  RETURN  0 = DBMS_LOCK.REQUEST(LOCKHANDLE => P_LOCKHANDLE,
                                TIMEOUT => G_LOCK_TIMEOUT,  
                                RELEASE_ON_COMMIT => (P_AUTO_DROP = 1)); 
END;

PROCEDURE RELEASE_LOCK(P_LOCKHANDLE IN VARCHAR2)
IS
  RES INTEGER;
BEGIN
  RES:= DBMS_LOCK.RELEASE(P_LOCKHANDLE);
END;



FUNCTION GET_QT_JOB_MAX
  RETURN NUMBER
IS
  V_RES NUMBER;
BEGIN
  IF G_BTPR_MAX_FUNC IS NOT NULL THEN 
    EXECUTE IMMEDIATE 'begin :V_RESULT := '||G_BTPR_MAX_FUNC|| '; end;'
      USING OUT V_RES;
  END IF;
  RETURN NVL(V_RES, G_BTPR_MAX);
EXCEPTION
  WHEN OTHERS THEN
    RETURN G_BTPR_MAX;
END;


FUNCTION GET_QT_JOB_MASK(P_MASK IN VARCHAR2, 
                         P_RUN_JOB IN NUMBER DEFAULT 1 
  ) RETURN NUMBER
IS
  RES NUMBER;
BEGIN
  IF P_RUN_JOB = 1 THEN
    SELECT COUNT(1)
      INTO RES
      FROM DBA_SCHEDULER_JOBS
     WHERE UPPER(JOB_NAME) LIKE UPPER(P_MASK)
       AND STATE IN ('SCHEDULED', 'RUNNING');
  ELSE
    SELECT COUNT(1)
      INTO RES
      FROM DBA_SCHEDULER_JOBS
     WHERE UPPER(JOB_NAME) LIKE UPPER(P_MASK);
  END IF;
  RETURN RES;
END;



PROCEDURE STOP_PACK_BILLING
IS
BEGIN
  
  IF GET_QT_JOB_MASK('bt_bgi_stop_billing') > 0 THEN 
    RAISE_ERROR(10291); 
  END IF;

  
  IF BFAM_SERVICES_PG.CHECK_STOP(BGI_RQ_PG.GV_AGGR_SRV_NAME) = 0
  THEN
    BGI_RQ_PG.STOP_BGI_SRV;
  END IF;
  

  
  
  
  DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_stop_billing',
                            JOB_TYPE   => 'PLSQL_BLOCK',
                            JOB_ACTION => 'loop if PACK_BILLING_TASK_BGI.get_qt_job_mask(''bt_bgi_job_%'') + PACK_BILLING_TASK_BGI.get_qt_job_mask(''bt_bgi_run_job_init%'') = 0 then exit; end if; dbms_lock.sleep(15); end loop;',
                            ENABLED    => TRUE,
                            AUTO_DROP  => TRUE,
                            JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                           );
END;


PROCEDURE CHANGE_TASK_STATUS
IS
  V_RES NUMBER;
BEGIN
  FOR REC IN (SELECT BTTS_ID, BORD_ID, BILL_BTST_ID,
                     CASE WHEN R.IS_BTST = '0010' THEN 3            
                          WHEN SUBSTR(R.IS_BTST, 4, 1) = '1' THEN 4 
                          WHEN SUBSTR(R.IS_BTST, 2, 1) = '1' THEN 2 
                     ELSE 1 
                     END BOST_ID 
                FROM (SELECT T.BTTS_ID,                    
                             MAX(T.BILL_BTST_ID) BILL_BTST_ID, 
                             MAX(T.BORD_BORD_ID) BORD_ID,  
                             
                             NVL(MAX(CASE WHEN B.BTST_BTST_ID IN (1,5) THEN 1 END), 0) || 
                             NVL(MAX(CASE WHEN B.BTST_BTST_ID = 2 THEN 1 END), 0) ||
                             NVL(MAX(CASE WHEN B.BTST_BTST_ID = 3 THEN 1 END), 0) ||
                             NVL(MAX(CASE WHEN B.BTST_BTST_ID = 4 THEN 1 END), 0) IS_BTST
                        FROM BT_TASKS T
                             INNER JOIN BT_SETS B
                                     ON B.BTTS_BTTS_ID = T.BTTS_ID
                       WHERE T.BILL_BTST_ID IN (1,2) 
                         AND T.BORD_BORD_ID IS NOT NULL 
                       GROUP BY T.BTTS_ID
                     ) R
             ) LOOP
    IF (REC.BOST_ID > 1) AND (REC.BOST_ID <> REC.BILL_BTST_ID) THEN
      
      UPDATE BT_TASKS
         SET BILL_BTST_ID = REC.BOST_ID
       WHERE BTTS_ID = REC.BTTS_ID;
      COMMIT;

      IF G_CHDB_USE_MODE = 1 THEN 
        
        IF REC.BOST_ID = 3 THEN 
          V_RES := PACK_BILLING.POST_BILL_PROCESS(P_BCT_ID => 1, 
                                                  P_BORD_ID => REC.BORD_ID, 
                                                  P_BOST_ID => REC.BOST_ID, 
                                                  P_BORD_COMMENT => ''      
                                                  );
        ELSE 
          V_RES := PACK_BILLING_SHARE.SET_BILL_ORDER_STATUS(P_BORD_ID => REC.BORD_ID, 
                                                            P_BOST_ID => REC.BOST_ID, 
                                                            P_BORD_COMMENT => '',     
                                                            P_CHG_BOST_DATE => SYSDATE
                                                           );
        END IF;
      END IF;
    END IF;
  END LOOP;
END;

PROCEDURE RUN_CHANGE_TASK_STATUS
IS
BEGIN
  
  IF GET_QT_JOB_MASK('bt_bgi_change_task_status') = 0 THEN 
    
    
    
    DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_change_task_status',
                              JOB_TYPE   => 'PLSQL_BLOCK',
                              JOB_ACTION => '
loop
  PACK_BILLING_TASK_BGI.change_task_status;
  if PACK_BILLING_TASK_BGI.get_qt_job_mask(''bt_bgi_job_%'') + PACK_BILLING_TASK_BGI.get_qt_job_mask(''bt_bgi_run_job_init%'') = 0 then
    PACK_BILLING_TASK_BGI.change_task_status; -- ��� ����� �� ������ ������
    exit;
  end if;
  dbms_lock.sleep(600);
end loop;
',
                              ENABLED    => TRUE,
                              AUTO_DROP  => TRUE,
                              JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                             );
  END IF;
END;



PROCEDURE START_JOB_WAITING(P_AFTER_TIME IN DATE, 
                            P_BTTS_ID    IN VARCHAR2 DEFAULT NULL 
                           )
IS
  V_LOCKHANDLE  VARCHAR2(128);
BEGIN
  
  IF GET_QT_JOB_MASK('bt_bgi_stop_billing') > 0 THEN 
    RAISE_APPLICATION_ERROR(-20000, 'stop_billing');
  END IF;

  
  IF U_LOCK(P_LOCK_NAME => 'bt_bgi_job_waiting_lock',
            P_AUTO_DROP => 0,
            P_LOCKHANDLE => V_LOCKHANDLE
           ) THEN
    IF GET_QT_JOB_MASK('bt_bgi_job_waiting') = 0 THEN 
      
      DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_job_waiting',
                                JOB_TYPE   => 'PLSQL_BLOCK',
                                JOB_ACTION => '
begin
dbms_lock.sleep(15); -- ���� 15 ������
PACK_BILLING_TASK_BGI.gv_need_trace := '||NVL(GV_NEED_TRACE, 0)||';
loop
  -- �������� ��� ��� ����� ���������� ��������
  if PACK_BILLING_TASK_BGI.get_qt_job_mask(''bt_bgi_stop_billing'') > 0 then
    exit;
  end if;
  -- ��������� ����\��� ��������� ���������
  if to_date('''||TO_CHAR(P_AFTER_TIME, 'dd.mm.yyyy hh24:mi:ss')||''',''dd.mm.yyyy hh24:mi:ss'') < sysdate then -- ����
    -- ������ job ������������� ��������� ��������� ��������� ��������
    PACK_BILLING_TASK_BGI.start_job_init('||CASE WHEN P_BTTS_ID IS NULL THEN 'null' ELSE TO_CHAR(P_BTTS_ID) END||');
    exit;
  end if;
  dbms_lock.sleep(15); -- ���� 15 ������ � ��������� ��������
end loop;
end;',
                              ENABLED    => TRUE,
                              AUTO_DROP  => TRUE,
                              JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                             );
    END IF;
  END IF;

  RELEASE_LOCK(V_LOCKHANDLE); 
EXCEPTION
  WHEN OTHERS THEN
    RELEASE_LOCK(V_LOCKHANDLE); 
END;



PROCEDURE START_JOB_INIT(P_BTTS_ID VARCHAR2 DEFAULT NULL 
  )
IS
  V_LOCKHANDLE  VARCHAR2(128);
BEGIN
  
  LOOP
    
    IF GET_QT_JOB_MASK('bt_bgi_stop_billing') > 0 THEN 
      RAISE_APPLICATION_ERROR(-20000, 'stop_billing');
    END IF;

    IF U_LOCK(P_LOCK_NAME => 'bt_bgi_job_init_lock',
              P_AUTO_DROP => 0,
              P_LOCKHANDLE => V_LOCKHANDLE
             ) THEN
      EXIT;
    END IF;
    DBMS_LOCK.SLEEP(G_LOCK_TIMEOUT);
  END LOOP;

  
  LOOP
    IF GET_QT_JOB_MASK('bt_bgi_stop_billing') > 0 THEN 
      RAISE_APPLICATION_ERROR(-20000, 'stop_billing');
    END IF;

    IF GET_QT_JOB_MASK('bt_bgi_job_init', 0) = 0 THEN
      EXIT;
    END IF;
    DBMS_LOCK.SLEEP(G_LOCK_TIMEOUT);
  END LOOP;

  IF GET_QT_JOB_MASK('bt_bgi_stop_billing') = 0 THEN 
    DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_job_init',
                              JOB_TYPE   => 'PLSQL_BLOCK',
                              JOB_ACTION => 'begin PACK_BILLING_TASK_BGI.gv_need_trace := '||NVL(GV_NEED_TRACE, 0)||';'|| 
                                              CASE WHEN P_BTTS_ID IS NULL THEN 'PACK_BILLING_TASK_BGI.start_processes;'
                                              ELSE 'PACK_BILLING_TASK_BGI.start_processes('''||P_BTTS_ID||''');'
                                              END ||
                                            'end;',
                              ENABLED    => TRUE,
                              AUTO_DROP  => TRUE,
                              JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                              );
  END IF;

  RELEASE_LOCK(V_LOCKHANDLE); 
EXCEPTION
  WHEN OTHERS THEN
    RELEASE_LOCK(V_LOCKHANDLE); 
END;


PROCEDURE CHANGE_BTSE_STATUS(P_BTSE_ID NUMBER,
                             P_STATUS  NUMBER,
                             P_SLOG_ID NUMBER DEFAULT NULL
                            )
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  V_NUM NUMBER;
BEGIN
  FOR REC IN (SELECT H.BTSE_ID FROM BT_SETS H WHERE H.BTSE_ID = P_BTSE_ID FOR UPDATE NOWAIT) LOOP
    UPDATE BT_SETS
       SET BTST_BTST_ID = P_STATUS
     WHERE BTSE_ID = P_BTSE_ID;
    EXIT;
  END LOOP;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI ERROR: change_btse_status(p_btse_id => '|| P_BTSE_ID || ', p_status => ' || P_STATUS || ')',
                        P_SLOG_ID => P_SLOG_ID,
                        P_MSG_TYPE => LOG_COMMON.ERRORMSG);
    RAISE;
END;

PROCEDURE CHANGE_ASSC_STATUS(P_ID NUMBER,
                             P_BTSG_ID NUMBER,
                             P_BTST_ID NUMBER,
                             P_NEW_STATUS NUMBER, 
                             P_SLOG_ID NUMBER DEFAULT NULL
                            )
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  V_NUM NUMBER;
BEGIN
  IF P_BTSG_ID = 0 THEN 
    FOR REC IN (SELECT H.BTSE_ID FROM BT_SETS H WHERE H.BTSE_ID = P_ID FOR UPDATE NOWAIT) LOOP
      UPDATE BT_SETS
         SET BTST_BTST_ID = P_NEW_STATUS
       WHERE BTSE_ID = P_ID;
      EXIT;
    END LOOP;
  ELSIF (P_BTSG_ID IN (2, 4) AND P_BTST_ID IN (1,5)) OR 
        (P_BTSG_ID = 4 AND P_BTST_ID = 3) THEN  
    FOR REC IN (SELECT 1 FROM BT_SETS H WHERE H.BTSE_ID = P_ID FOR UPDATE NOWAIT) LOOP
      UPDATE BT_SETS
         SET BTST_BTST_ID = P_NEW_STATUS
       WHERE BTSE_ID = P_ID;
      EXIT;
    END LOOP;
  ELSIF (P_BTSG_ID = 3 AND P_BTST_ID = 1) OR
        (P_BTSG_ID = 2 AND P_BTST_ID = 3) THEN  
    FOR REC IN (SELECT 1 FROM BT_SETS H WHERE H.ASSC_ASSC_ID = P_ID FOR UPDATE NOWAIT) LOOP
      
      
      
      UPDATE BT_SETS
         SET BTSG_BTSG_ID = CASE WHEN P_NEW_STATUS = 3 THEN 4 ELSE 3 END,
             BTST_BTST_ID = CASE WHEN P_NEW_STATUS = 3 THEN 1 ELSE P_NEW_STATUS END
       WHERE ASSC_ASSC_ID = P_ID
         AND BTSG_BTSG_ID <> 5; 
      EXIT;
    END LOOP;
  END IF;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI ERROR: change_assc_status(p_id => '        ||P_ID
                                                                  ||', p_btsg_id => '   ||P_BTSG_ID
                                                                  ||', p_btst_id => '   ||P_BTST_ID
                                                                  ||', p_new_status => '||P_NEW_STATUS
                                                                  || ')',
                        P_SLOG_ID => P_SLOG_ID,
                        P_MSG_TYPE => LOG_COMMON.ERRORMSG);
    RAISE;
END;

PROCEDURE RUN_JOB_INIT(P_BTTS_ID IN VARCHAR2,
                       P_JOB_NUM IN NUMBER DEFAULT NULL)
IS
  V_JOB_NUM NUMBER := P_JOB_NUM;
BEGIN
  
  IF GET_QT_JOB_MASK('bt_bgi_run_job_init%') < 2 AND    
     GET_QT_JOB_MASK('bt_bgi_stop_billing') = 0 THEN 
    IF V_JOB_NUM IS NULL THEN
      V_JOB_NUM := BTJB_SEQ.NEXTVAL;
    END IF;

    DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_run_job_init_'||V_JOB_NUM,
                              JOB_TYPE   => 'PLSQL_BLOCK',
                              JOB_ACTION => 'begin
                                               PACK_BILLING_TASK_BGI.gv_need_trace := '||NVL(GV_NEED_TRACE, 0)||'; -- 106.01
                                               -- 107.01, �������� ���������� ������ v_job_num
                                               loop
                                                 if PACK_BILLING_TASK_BGI.get_qt_job_mask(''bt_bgi_job_work%_'||V_JOB_NUM||''') = 0 then
                                                   exit;
                                                 end if;
                                                 dbms_lock.sleep(/* 118.02 (BFAM-2111) 5*/ PACK_BILLING_TASK_BGI.g_LOCK_TIMEOUT);
                                               end loop;
                                               --/107.01
                                               PACK_BILLING_TASK_BGI.start_job_init'||CASE WHEN P_BTTS_ID IS NOT NULL THEN '('''||P_BTTS_ID||''')' END ||';
                                             end;',
                              ENABLED    => TRUE,
                              AUTO_DROP  => TRUE,
                              JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                              );
  END IF;
END;


PROCEDURE RUN_WORK(P_BTSE_ID IN NUMBER,
                   P_BLCL_ID IN NUMBER,
                   P_BTTS_ID IN VARCHAR2 DEFAULT NULL,
                   P_TRACE_LEVEL IN NUMBER DEFAULT 0, 
                   P_JOB_NUM IN NUMBER DEFAULT NULL
  )
IS
  V_OP_ERR_CLNTS PACK_BILLING.T_ERR_CLNTS;
  V_NUM NUMBER;
  V_LOG_ID NUMBER;
  
  GC_USER_PROC_CALC_DISC_PARAMS APP_PARAMETERS.VALUE_NUMBER%TYPE := 10289;
  V_USER_PROC_CALC_DISC_PARAMS  APP_PARAMETERS.VALUE_STRING%TYPE;
  V_PERIOD_DATE DATE;
  V_RESULT      NUMBER;
  
  
  V_MSG VARCHAR2(32000) := 'btse_id = '|| P_BTSE_ID ||' , p_blcl_id = ' || P_BLCL_ID || ' , p_btts_id = ' || P_BTTS_ID;
  
  V_BT_SETS_REC BT_SETS%ROWTYPE; 
  V_NEW_BTSE_ID_1 BT_SETS.BTSE_ID%TYPE; 
  V_NEW_BTSE_ID_2 BT_SETS.BTSE_ID%TYPE; 
  V_COUNT NUMBER;
  
  
  FUNCTION SET_NEW_BTSE_ID(P_BTSE_ID  IN NUMBER,
                           P_ERR_TYPE IN NUMBER
                          ) RETURN NUMBER
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    V_NUM NUMBER := MOD(P_BTSE_ID, 1000)+1;
    V_BASE_ID NUMBER := FLOOR(P_BTSE_ID/10000)*10000 + P_ERR_TYPE * 1000;
  BEGIN
    V_BT_SETS_REC.BTST_BTST_ID := GC_BTST_ERROR; 
    V_BT_SETS_REC.TRY_COUNT    := NULL;
    V_BT_SETS_REC.START_AFTER  := NULL;
    FOR I IN V_NUM..998 LOOP
      BEGIN
        V_BT_SETS_REC.BTSE_ID := V_BASE_ID + V_NUM; 
        
        INSERT INTO BT_SETS VALUES V_BT_SETS_REC;
        COMMIT;
        RETURN V_BT_SETS_REC.BTSE_ID;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
    RETURN NULL; 
  END;
  
  PROCEDURE DEL_NEW_BTSE_ID
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DELETE FROM BT_SETS WHERE BTSE_ID IN (V_NEW_BTSE_ID_1, V_NEW_BTSE_ID_2);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END;
  
BEGIN
  
  DBMS_OUTPUT.DISABLE;

  V_LOG_ID := TO_SYS_LOG(P_MESSAGE => 'BT_BGI billing_START_CLNT: '|| V_MSG);

  IF P_TRACE_LEVEL > 0 THEN
    BEGIN
      EXECUTE IMMEDIATE 'alter session set max_dump_file_size = unlimited';
      EXECUTE IMMEDIATE 'alter session set tracefile_identifier = ''bt_trace_'||P_BTSE_ID||'''';
      EXECUTE IMMEDIATE 'alter session set events ''10046 trace name context forever, level '||P_TRACE_LEVEL||'''';
    EXCEPTION
      WHEN OTHERS THEN
        V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI ERROR: trace_ERROR',
                            P_SLOG_ID => V_LOG_ID,
                            P_MSG_TYPE => LOG_COMMON.ERRORMSG);
    END;
  END IF;

  BEGIN
    
    
    SELECT * INTO V_BT_SETS_REC
      FROM BT_SETS
     WHERE BTSE_ID = P_BTSE_ID;
    
    V_USER_PROC_CALC_DISC_PARAMS := BFAM_COMMON_PG.GET_PRMT_STRING(GC_USER_PROC_CALC_DISC_PARAMS);
    IF V_USER_PROC_CALC_DISC_PARAMS IS NOT NULL AND 
       NVL(V_BT_SETS_REC.TRY_COUNT, 1) = 1 
    THEN
      
      CHANGE_BTSE_STATUS(P_BTSE_ID => P_BTSE_ID,
                         P_STATUS  => GC_BTST_CALC_DISC_PRMTS); 
      SELECT BC.CYCLE_DATE INTO V_PERIOD_DATE FROM BILL_CYCLES BC WHERE BC.BLCL_ID = P_BLCL_ID;
      EXECUTE IMMEDIATE
        'BEGIN '||V_USER_PROC_CALC_DISC_PARAMS||'(p_btse_id => :p_btse_id, p_period_date => :p_period_date, p_result => :p_result); END;'
      USING P_BTSE_ID, V_PERIOD_DATE, V_RESULT;
      IF V_RESULT != 0 THEN
        
        RAISE_APPLICATION_ERROR(-20001, GET_APPLICATION_MESSAGE(10405, PACK_BILLING.APPL_LANG,
                                          V_USER_PROC_CALC_DISC_PARAMS||'(p_btse_id => '||P_BTSE_ID||', p_period_date => '||TO_CHAR(V_PERIOD_DATE, 'DD.MM.YYYY')||', p_result => :p_result)',
                                          GC_USER_PROC_CALC_DISC_PARAMS,
                                          SQLERRM || ' BT: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                          )
                                );
      END IF;
      
      CHANGE_BTSE_STATUS(P_BTSE_ID => P_BTSE_ID,
                         P_STATUS  => GC_BTST_PROCESSING); 
    END IF;
    
    PACK_BILLING.BILL_CLUSTERS(OP_ERR_CLNTS => V_OP_ERR_CLNTS, 
                               IP_BTSE_ID   => P_BTSE_ID, 
                               IP_BLCL_ID   => P_BLCL_ID, 
                               IP_TYPE_CLUSTER => 0, 
                               IP_RANGE_CLNT => 31, 
                               IP_SLOG_ID => V_LOG_ID
                              );

    
    IF V_OP_ERR_CLNTS.COUNT > 0 THEN 
      FOR I IN 1..V_OP_ERR_CLNTS.COUNT LOOP
        IF V_OP_ERR_CLNTS(I).ERR_TYPE = 1 THEN
          BEGIN
            PACK_BILLING.BILL_ONE_CLIENT(V_BLCL_ID => P_BLCL_ID,
                                         V_CLNT_ID => V_OP_ERR_CLNTS(I).CLNT_ID,
                                         V_WITHOUT_LOCK_BILL_CYCLES => 1,
                                         V_WITHOUT_EXCEPT_FLAG => 1,
                                         V_WITHOUT_ROAM_EXCEPT_FLAG => 1,
                                         V_SLOG_ID => V_LOG_ID
                                        );
            V_OP_ERR_CLNTS(I).ERR_TYPE := -1; 
          EXCEPTION
            WHEN OTHERS THEN
              
              IF PACK_BILLING.GV_WAITING_OCS THEN
                V_OP_ERR_CLNTS(I).ERR_TYPE := 2;  
              END IF;
              
          END;
        END IF;
      END LOOP;

      
      





      
      V_COUNT := NVL(V_BT_SETS_REC.TRY_COUNT, 1) + 1;

      
      
      FOR I IN 1..V_OP_ERR_CLNTS.COUNT LOOP
        IF V_OP_ERR_CLNTS(I).ERR_TYPE = 2 THEN

          
          IF V_NEW_BTSE_ID_2 IS NULL THEN
            V_NEW_BTSE_ID_2 := SET_NEW_BTSE_ID(P_BTSE_ID  => V_BT_SETS_REC.BTSE_ID,
                                               P_ERR_TYPE => 2);
          END IF;

          
          UPDATE BT_BTSE_CLNT S
             SET S.BTSE_BTSE_ID = V_NEW_BTSE_ID_2
           WHERE S.BTSE_BTSE_ID = P_BTSE_ID
             AND S.CLNT_CLNT_ID = V_OP_ERR_CLNTS(I).CLNT_ID;
        END IF;
      END LOOP;

      IF V_NEW_BTSE_ID_2 IS NOT NULL AND 
         V_COUNT <= G_MAX_COUNT THEN  
        UPDATE BT_SETS
           SET START_AFTER = SYSDATE + G_TIME_OUT, 
               TRY_COUNT = V_COUNT, 
               BTST_BTST_ID = GC_BTST_WAITING_FOR_RUN 
         WHERE BTSE_ID = V_NEW_BTSE_ID_2;
      END IF;

      
      FOR I IN 1..V_OP_ERR_CLNTS.COUNT LOOP
        IF V_OP_ERR_CLNTS(I).ERR_TYPE IN (0, 1) THEN
          
          IF V_NEW_BTSE_ID_1 IS NULL THEN
            V_NEW_BTSE_ID_1 := SET_NEW_BTSE_ID(P_BTSE_ID  => V_BT_SETS_REC.BTSE_ID,
                                               P_ERR_TYPE => 1);
          END IF;
          
          UPDATE BT_BTSE_CLNT S
             SET S.BTSE_BTSE_ID = V_NEW_BTSE_ID_1
           WHERE S.BTSE_BTSE_ID = P_BTSE_ID
             AND S.CLNT_CLNT_ID = V_OP_ERR_CLNTS(I).CLNT_ID;
        END IF;
      END LOOP;
      
    END IF;

    COMMIT;
    
    CHANGE_BTSE_STATUS(P_BTSE_ID => P_BTSE_ID,
                       P_STATUS  => GC_BTST_COMPLETED); 
  EXCEPTION
    WHEN OTHERS THEN
       
       V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI ERROR: ' || SQLERRM,
                           P_SLOG_ID => V_LOG_ID,
                           P_MSG_TYPE => LOG_COMMON.ERRORMSG);

       
       DEL_NEW_BTSE_ID;

       
       CHANGE_BTSE_STATUS(P_BTSE_ID => P_BTSE_ID,
                          P_STATUS  => GC_BTST_ERROR); 
       ROLLBACK;
  END;
  
  V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI billing_END_CLNT',
                      P_SLOG_ID => V_LOG_ID);
  
  RUN_JOB_INIT(P_BTTS_ID, P_JOB_NUM);
END;


PROCEDURE RUN_ASSC_WORK(P_ASSC_ID     IN NUMBER, 
                        P_ID          IN NUMBER, 
                        P_BLCL_ID     IN NUMBER, 
                        P_BTSG_ID     IN NUMBER, 
                        P_BTST_ID     IN NUMBER, 
                        P_BTTS_ID     IN VARCHAR2 DEFAULT NULL, 
                        P_TRACE_LEVEL IN NUMBER DEFAULT 0, 
                        P_JOB_NUM     IN NUMBER DEFAULT NULL
  )
IS
  V_OP_ERR_CLNTS PACK_BILLING.T_ERR_CLNTS;
  V_NUM NUMBER;
  V_LOG_ID NUMBER;
  V_TYPE_CLUSTER NUMBER;
  V_MSG VARCHAR2(32000) := 'p_btts_id = '||P_BTTS_ID
                      ||' , p_assc_id = '||P_ASSC_ID
                      ||' , p_id = '     ||P_ID
                      ||' , p_blcl_id = '||P_BLCL_ID
                      ||' , p_btsg_id = '||P_BTSG_ID
                      ||' , p_btst_id = '||P_BTST_ID ;
BEGIN
  
  DBMS_OUTPUT.DISABLE;

  V_LOG_ID := TO_SYS_LOG(P_MESSAGE => 'BT_BGI billing_START_ASSC: '|| V_MSG);

  IF P_TRACE_LEVEL > 0 THEN
    BEGIN
      EXECUTE IMMEDIATE 'alter session set max_dump_file_size = unlimited';
      EXECUTE IMMEDIATE 'alter session set tracefile_identifier = ''bt_trace_'||P_ID ||'_'||P_BTSG_ID||'_'||P_BTST_ID||'''';
      EXECUTE IMMEDIATE 'alter session set events ''10046 trace name context forever, level '||P_TRACE_LEVEL||'''';
    EXCEPTION
      WHEN OTHERS THEN
        V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI ERROR: trace_ERROR',
                            P_SLOG_ID => V_LOG_ID,
                            P_MSG_TYPE => LOG_COMMON.ERRORMSG);
    END;
  END IF;

  BEGIN
    
    G_LOCK_ASSC_BTSE_ON := 1;

    IF P_ASSC_ID = -1 THEN 
      
      V_TYPE_CLUSTER := 5; 

      PACK_BILLING.BILL_CLUSTERS(OP_ERR_CLNTS    => V_OP_ERR_CLNTS, 
                                 IP_BTSE_ID      => P_ID, 
                                 IP_BLCL_ID      => P_BLCL_ID, 
                                 IP_ASSC_ID      => NULL,      
                                 IP_RANGE_CLNT   => 31,
                                 IP_TYPE_CLUSTER => V_TYPE_CLUSTER,
                                 IP_CLEAN_TMP_TBLS => TRUE, 
                                 IP_SLOG_ID => V_LOG_ID
                                );
      
      IF V_OP_ERR_CLNTS.COUNT > 0 THEN 
        
        FOR I IN 1..V_OP_ERR_CLNTS.COUNT LOOP
          
          UPDATE BT_BTSE_CLNT S
             SET S.BTSE_BTSE_ID = P_ID + 1
           WHERE S.BTSE_BTSE_ID = P_ID
             AND S.ROOT_ASSC_ID = V_OP_ERR_CLNTS(I).CLNT_ID;
        END LOOP;

        
        INSERT INTO BT_SETS(BTTS_BTTS_ID, BTSE_ID, ASSC_ASSC_ID, BTSG_BTSG_ID, BTST_BTST_ID)
          VALUES(P_BTTS_ID, P_ID + 1, -1, 0, 4); 
      END IF;
      
    ELSE
      V_TYPE_CLUSTER := CASE WHEN P_BTSG_ID = 2 AND P_BTST_ID IN (1,5) THEN 1  
                             WHEN P_BTSG_ID = 3 AND P_BTST_ID = 1 THEN 2  
                             WHEN P_BTSG_ID = 2 AND P_BTST_ID = 3 THEN 2  
                             WHEN P_BTSG_ID = 4 AND P_BTST_ID = 1 THEN 3  
                             WHEN P_BTSG_ID = 4 AND P_BTST_ID = 3 THEN 4  
                        END; 
      PACK_BILLING.BILL_CLUSTERS(OP_ERR_CLNTS    => V_OP_ERR_CLNTS, 
                                 IP_BTSE_ID      => CASE WHEN P_ID > 0 THEN P_ID END, 
                                 IP_BLCL_ID      => P_BLCL_ID, 
                                 IP_ASSC_ID      => P_ASSC_ID, 
                                 IP_RANGE_CLNT   => 31, 
                                 IP_TYPE_CLUSTER => V_TYPE_CLUSTER, 
                                 IP_CLEAN_TMP_TBLS => FALSE, 
                                 IP_SET_ASSC_BLCL => (P_BTSG_ID = 4 AND P_BTST_ID = 3), 
                                 IP_SLOG_ID => V_LOG_ID
                                );
      
    END IF;
    
    COMMIT;
    
    CHANGE_ASSC_STATUS(P_ID      => P_ID,
                       P_BTSG_ID => P_BTSG_ID,
                       P_BTST_ID => P_BTST_ID,
                       P_NEW_STATUS  => 3,
                       P_SLOG_ID => V_LOG_ID
                      ); 
    
    G_LOCK_ASSC_BTSE_ON := 0;
  EXCEPTION
    WHEN OTHERS THEN
       
       V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI ERROR:' || SQLERRM,
                           P_SLOG_ID => V_LOG_ID,
                           P_MSG_TYPE => LOG_COMMON.ERRORMSG);
       
       CHANGE_ASSC_STATUS(P_ID      => P_ID,
                          P_BTSG_ID => P_BTSG_ID,
                          P_BTST_ID => P_BTST_ID,
                          P_NEW_STATUS  => 4,
                          P_SLOG_ID => V_LOG_ID
                         ); 
       
       G_LOCK_ASSC_BTSE_ON := 0;
       
       ROLLBACK;
  END;
  
  V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI billing_END_ASSC',
                      P_SLOG_ID => V_LOG_ID
                     );
  
  RUN_JOB_INIT(P_BTTS_ID, P_JOB_NUM);
END;


PROCEDURE START_PROCESSES(P_BTTS_ID VARCHAR2 DEFAULT NULL 
  )
IS
  V_BTTS_ID VARCHAR2(1000) := NVL(P_BTTS_ID, '-');
  
  PROCEDURE RUN_CLNT_TASK
  IS
    V_QT_JOB NUMBER;  
    V_QT_JOB_MAX NUMBER; 

    
    CURSOR C_BTSE_LIST(P_BTTS_ID VARCHAR2,
                       P_QTY NUMBER
      )
    IS
      
      SELECT BTSE_ID, BLCL_BLCL_ID
        FROM (SELECT H.BTSE_ID,
                     T.BLCL_BLCL_ID,
                     ROW_NUMBER() OVER(ORDER BY T.PRIORITY, T.BTTS_ID, H.START_AFTER DESC NULLS FIRST) RN 
                FROM BT_TASKS T 
                     INNER JOIN BT_SETS H 
                             ON H.BTTS_BTTS_ID = T.BTTS_ID AND
                                H.ASSC_ASSC_ID IS NULL AND
                                H.BGIRQ_BGIRQ_ID > 0 AND 
                                
                                H.BTST_BTST_ID = GC_BTST_READY_FOR_BILLING AND
                                (H.START_AFTER IS NULL OR H.START_AFTER < SYSDATE)
               WHERE P_BTTS_ID = '-' OR INSTR(','||P_BTTS_ID||',', ','||T.BTTS_ID||',') > 0
                 AND T.START_CLNT_ID IS NOT NULL 
                 AND T.BTTS_SRC = 1
             ) AA
       WHERE RN <= P_QTY; 
    
    TYPE T_ARR_BTSE_LIST IS TABLE OF C_BTSE_LIST%ROWTYPE INDEX BY PLS_INTEGER;
    V_BTSE_LIST T_ARR_BTSE_LIST;
    V_JOB_NUM NUMBER;
    
    V_AFTER_TIME DATE; 
  BEGIN
    
    V_QT_JOB := GET_QT_JOB_MASK('bt_bgi_job_work_%'); 
    V_QT_JOB_MAX := GET_QT_JOB_MAX; 

    IF V_QT_JOB < V_QT_JOB_MAX THEN
      
      OPEN C_BTSE_LIST(V_BTTS_ID, V_QT_JOB_MAX - V_QT_JOB);
      FETCH C_BTSE_LIST BULK COLLECT INTO V_BTSE_LIST;
      CLOSE C_BTSE_LIST;

      IF GET_QT_JOB_MASK('bt_bgi_stop_billing') = 0 THEN 
        
        IF V_BTSE_LIST.COUNT = 0 THEN 
          
          SELECT MIN(H.START_AFTER) INTO V_AFTER_TIME
            FROM BT_SETS H
           WHERE P_BTTS_ID = '-' OR INSTR(','||P_BTTS_ID||',', ','||H.BTTS_BTTS_ID||',') > 0
             AND H.ASSC_ASSC_ID IS NULL
             
             AND H.BTST_BTST_ID = GC_BTST_READY_FOR_BILLING
             AND H.START_AFTER IS NOT NULL; 

          IF V_AFTER_TIME IS NOT NULL THEN 
            
            START_JOB_WAITING(P_AFTER_TIME => V_AFTER_TIME,
                              P_BTTS_ID    => P_BTTS_ID
                             );
          END IF;
          
        ELSE 
          FOR I IN 1..V_BTSE_LIST.COUNT LOOP
            BEGIN
              
              CHANGE_BTSE_STATUS(P_BTSE_ID => V_BTSE_LIST(I).BTSE_ID,
                                 P_STATUS  => GC_BTST_PROCESSING); 
              V_JOB_NUM := BTJB_SEQ.NEXTVAL;
              
              DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_job_work_' || V_JOB_NUM,
                                        JOB_TYPE   => 'PLSQL_BLOCK',
                                        JOB_ACTION => 'PACK_BILLING_TASK_BGI.run_work(' || V_BTSE_LIST(I).BTSE_ID || ','
                                                                        || V_BTSE_LIST(I).BLCL_BLCL_ID
                                                                        || ',''' || V_BTTS_ID || ''','
                                                                        || NVL(GV_NEED_TRACE, 0)
                                                                        || ','|| V_JOB_NUM || ');',
                                        ENABLED    => TRUE,
                                        AUTO_DROP  => TRUE,
                                        JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                                        );
            EXCEPTION
              WHEN OTHERS THEN
                
                CHANGE_BTSE_STATUS(P_BTSE_ID => V_BTSE_LIST(I).BTSE_ID,
                                   P_STATUS  => GC_BTST_ERROR); 
                
                ROLLBACK;
            END;
          END LOOP;
        END IF;
      END IF;
    END IF;
  END;

  
  PROCEDURE RUN_ASSC_TASK
  IS
    V_QT_JOB NUMBER;  
    V_QT_JOB_MAX NUMBER; 

    
    CURSOR C_BTSE_ASSC_LIST(P_BTTS_ID VARCHAR2,
                            P_QTY NUMBER
      )
    IS
      SELECT ASSC_ASSC_ID,
             ID,
             BTSG_BTSG_ID,
             BTST_BTST_ID,
             BLCL_BLCL_ID
        FROM (SELECT DISTINCT
                     AA.ASSC_ASSC_ID, 
                     CASE
                       WHEN AA.ASSC_ASSC_ID = -1 OR 
                            (AA.BTSG_BTSG_ID = 2 AND AA.BTST_BTST_ID IN (1,5)) OR  
                            (AA.BTSG_BTSG_ID = 4 AND AA.BTST_BTST_ID = 1)
                         THEN AA.BTSE_ID 
                       WHEN (AA.BTSG_BTSG_ID = 4 AND AA.MIN_BTST = 3) OR
                            (AA.BTSG_BTSG_ID = 0 AND AA.BTST_BTST_ID = 1)
                         THEN AA.BTSE_5  
                       ELSE ASSC_ASSC_ID           
                     END ID,          
                     AA.BTSG_BTSG_ID, 
                     AA.BTST_BTST_ID, 
                     AA.PRIORITY,     
                     AA.BLCL_BLCL_ID, 
                     AA.BTTS_BTTS_ID  
                FROM (SELECT 
                             A.ASSC_ASSC_ID, 
                             A.BTSG_BTSG_ID, 
                             A.BTST_BTST_ID, 
                             A.BTSE_ID, 
                             A.BTTS_BTTS_ID, 
                             A.BGIRQ_BGIRQ_ID, 
                             T.PRIORITY,     
                             T.BLCL_BLCL_ID, 
                             
                             MAX(CASE WHEN A.BTSG_BTSG_ID = 5 AND A.BTST_BTST_ID = 1 THEN A.BTSE_ID END) OVER(PARTITION BY A.ASSC_ASSC_ID) BTSE_5, 
                             MIN(CASE WHEN A.BTSG_BTSG_ID < 5 THEN A.BTST_BTST_ID END) OVER(PARTITION BY A.ASSC_ASSC_ID) MIN_BTST, 
                             COUNT(CASE WHEN A.BTST_BTST_ID = 4 THEN 1 END) OVER(PARTITION BY A.ASSC_ASSC_ID) QT_ERR  
                        FROM BT_SETS A
                             INNER JOIN BT_TASKS T
                                     ON T.BTTS_ID = A.BTTS_BTTS_ID
                       WHERE A.ASSC_ASSC_ID IS NOT NULL
                         AND P_BTTS_ID = '-' OR INSTR(','||P_BTTS_ID||',', ','||A.BTTS_BTTS_ID||',') > 0
                     ) AA
               WHERE (AA.ASSC_ASSC_ID = -1 OR 
                      AA.QT_ERR = 0 
                     )
                 AND (AA.BTSG_BTSG_ID NOT IN (0, 2) OR AA.BGIRQ_BGIRQ_ID > 0) 
                     
                 AND ((AA.BTSG_BTSG_ID = 0 AND AA.BTST_BTST_ID = 1) OR  
                      (AA.BTSG_BTSG_ID = 2 AND AA.BTST_BTST_ID IN (1,5)) OR  
                      (AA.BTSG_BTSG_ID = 3 AND AA.BTST_BTST_ID = 1) OR  
                      (AA.BTSG_BTSG_ID = 2 AND AA.MIN_BTST = 3)     OR  
                      (AA.BTSG_BTSG_ID = 4 AND AA.BTST_BTST_ID = 1) OR  
                      (AA.BTSG_BTSG_ID = 4 AND AA.MIN_BTST = 3 AND AA.BTSE_5 IS NOT NULL) 
                     )
               ORDER BY AA.PRIORITY, AA.BTTS_BTTS_ID
             )
       WHERE ROWNUM <= P_QTY; 
    
    TYPE T_ARR_BTSE_ASSC_LIST IS TABLE OF C_BTSE_ASSC_LIST%ROWTYPE INDEX BY PLS_INTEGER;
    V_BTSE_ASSC_LIST T_ARR_BTSE_ASSC_LIST;
    V_JOB_NUM NUMBER;
    
  BEGIN
    
    V_QT_JOB := GET_QT_JOB_MASK('bt_bgi_job_work_%'); 
    V_QT_JOB_MAX := GET_QT_JOB_MAX; 

    IF V_QT_JOB < V_QT_JOB_MAX THEN
      
      OPEN C_BTSE_ASSC_LIST(V_BTTS_ID, V_QT_JOB_MAX - V_QT_JOB);
      FETCH C_BTSE_ASSC_LIST BULK COLLECT INTO V_BTSE_ASSC_LIST;
      CLOSE C_BTSE_ASSC_LIST;

      IF GET_QT_JOB_MASK('bt_bgi_stop_billing') = 0 THEN 
        FOR I IN 1..V_BTSE_ASSC_LIST.COUNT LOOP
          BEGIN
            
            CHANGE_ASSC_STATUS(P_ID      => V_BTSE_ASSC_LIST(I).ID,
                               P_BTSG_ID => V_BTSE_ASSC_LIST(I).BTSG_BTSG_ID,
                               P_BTST_ID => V_BTSE_ASSC_LIST(I).BTST_BTST_ID,
                               P_NEW_STATUS  => 2); 











            V_JOB_NUM := BTJB_SEQ.NEXTVAL;
            
            DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_job_work_assc_' || V_JOB_NUM,
                                      JOB_TYPE   => 'PLSQL_BLOCK',
                                      JOB_ACTION => 'PACK_BILLING_TASK_BGI.run_assc_work(' || V_BTSE_ASSC_LIST(I).ASSC_ASSC_ID || ','
                                                                           || NVL(V_BTSE_ASSC_LIST(I).ID, -1) || ','
                                                                           || V_BTSE_ASSC_LIST(I).BLCL_BLCL_ID || ','
                                                                           || V_BTSE_ASSC_LIST(I).BTSG_BTSG_ID || ','
                                                                           || V_BTSE_ASSC_LIST(I).BTST_BTST_ID
                                                                           || ',''' || V_BTTS_ID ||''','
                                                                           || NVL(GV_NEED_TRACE, 0)
                                                                           || ','|| V_JOB_NUM || ');',
                                      ENABLED    => TRUE,
                                      AUTO_DROP  => TRUE,
                                      JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                                      );
          EXCEPTION
            WHEN OTHERS THEN
              
              CHANGE_ASSC_STATUS(P_ID      => V_BTSE_ASSC_LIST(I).ID,
                                 P_BTSG_ID => V_BTSE_ASSC_LIST(I).BTSG_BTSG_ID,
                                 P_BTST_ID => V_BTSE_ASSC_LIST(I).BTST_BTST_ID,
                                 P_NEW_STATUS  => 4); 
              
              ROLLBACK;
          END;
        END LOOP;
      END IF;
    END IF;
  END;
  
BEGIN
  RUN_ASSC_TASK;
  RUN_CLNT_TASK;
END;



PROCEDURE RUN_PACK_BILLING(P_BTTS_ID VARCHAR2 DEFAULT NULL, 
                           RECALC_ROLLBACKED BOOLEAN DEFAULT TRUE 
                           )
IS
BEGIN
  
  IF GET_QT_JOB_MASK('bt_bgi_stop_billing') > 0 THEN 
    RAISE_ERROR(10280); 
  END IF;

  IF GET_QT_JOB_MASK('bt_bgi_job_%') + GET_QT_JOB_MASK('bt_bgi_run_job_init%') > 0 THEN 
    RAISE_ERROR(10281); 
  END IF;

  
  UPDATE BT_SETS T
     SET BTST_BTST_ID = 
                        CASE WHEN ASSC_ASSC_ID IS NOT NULL AND BTSG_BTSG_ID = 2 THEN 5 
                        
                        ELSE GC_BTST_READY_FOR_BILLING END,
                        
         
         START_AFTER  = NULL,
         TRY_COUNT = NULL
   WHERE BTST_BTST_ID = GC_BTST_ERROR 
     AND (P_BTTS_ID IS NULL OR INSTR(','||P_BTTS_ID||',', ','||BTTS_BTTS_ID||',') > 0);

  
  IF RECALC_ROLLBACKED THEN
    UPDATE BT_SETS T
       SET BTST_BTST_ID = CASE WHEN BTST_BTST_ID = GC_BTST_ROLLBACK_AND_AGGR_DEL THEN GC_BTST_WAITING_FOR_RUN ELSE GC_BTST_READY_FOR_BILLING END,
           START_AFTER  = NULL,
           TRY_COUNT    = NULL
     WHERE BTST_BTST_ID IN (GC_BTST_ROLLBACK, GC_BTST_ROLLBACK_AND_AGGR_DEL)
       AND (P_BTTS_ID IS NULL OR INSTR(','||P_BTTS_ID||',', ','||BTTS_BTTS_ID||',') > 0);
  END IF;
  

  COMMIT;

  
  START_JOB_INIT(P_BTTS_ID);
END;




PROCEDURE RUN_ERR_PACK(P_CLNT_ID NUMBER DEFAULT NULL) 
IS                                                    
  V_NUM NUMBER;
  V_LOG_ID NUMBER;
BEGIN
  IF P_CLNT_ID IS NULL THEN
    RAISE_ERROR(10226, 'run_err_pack'); 
  END IF;
  
  IF GET_QT_JOB_MASK('bt_bgi_stop_billing') > 0 THEN 
    RAISE_ERROR(10280); 
  END IF;

  IF GET_QT_JOB_MASK('bt_bgi_job_%') + GET_QT_JOB_MASK('bt_bgi_run_job_init%') = 0 THEN 
    
    UPDATE BT_SETS T
       SET BTST_BTST_ID = CASE WHEN ASSC_ASSC_ID IS NOT NULL AND BTSG_BTSG_ID = 2 THEN 5 
                          ELSE 1 END, 
           
           START_AFTER  = NULL,
           TRY_COUNT = NULL
     WHERE T.BTST_BTST_ID = GC_BTST_ERROR 
       AND (T.ASSC_ASSC_ID IS NULL  
            OR T.BTSG_BTSG_ID = 2)  
       AND T.BTSE_ID IN (SELECT R.BTSE_BTSE_ID
                           FROM BT_BTSE_CLNT R
                          WHERE R.CLNT_CLNT_ID = P_CLNT_ID);

    COMMIT;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI run_err_pack ERROR: ' || SQLERRM,
                        P_SLOG_ID => V_LOG_ID,
                        P_MSG_TYPE => LOG_COMMON.ERRORMSG);
    ROLLBACK;
    RAISE;
END;





PROCEDURE BT_ADD_TASK(
  P_BILL_DATE     IN DATE, 
  P_BLCL_ID       IN NUMBER DEFAULT NULL, 
  P_PRIORITY      IN NUMBER DEFAULT 500, 
  
  P_BRNC_ID       IN NUMBER DEFAULT NULL,
  P_BLGR_ID       IN NUMBER DEFAULT NULL,
  P_AFKT_ID       IN NUMBER DEFAULT NULL,
  
  P_START_CLNT_ID IN NUMBER DEFAULT 0,
  P_END_CLNT_ID   IN NUMBER DEFAULT 9999999999,
  
  P_START_ASSC_ID IN NUMBER DEFAULT 0,
  P_END_ASSC_ID   IN NUMBER DEFAULT 9999999999,
  
  P_SETS_MAX      IN NUMBER DEFAULT 1000, 
  P_TEST_MODE     IN NUMBER DEFAULT 0,    
                                          
  P_MACR_ID       IN MACROREGIONS.MACR_ID%TYPE DEFAULT NULL, 
  P_ADD_CONDITION IN VARCHAR2 DEFAULT NULL 
)
IS
  V_BLCL_ID  NUMBER := P_BLCL_ID;
  V_BLGR_ID  NUMBER := P_BLGR_ID;
  V_BLCL_MIN NUMBER;
  V_BLCL_MAX NUMBER;
  V_NUM NUMBER;
  V_LOG_ID NUMBER;
  
  V_SETS_MAX NUMBER := NVL(P_SETS_MAX, 1000);
  V_SAVED_SESSION_STATE PACK_BILLING_TASK.SESSION_PARALLEL_STATE; 

  
  
  
  PROCEDURE PREPARE_BT_CLNT(P_BILL_DATE IN DATE,
                            P_BLCL_ID   IN NUMBER,
                            P_PRIORITY  IN NUMBER,
                            P_BRNC_ID   IN NUMBER,
                            P_BLGR_ID   IN NUMBER,
                            P_START_CLNT_ID IN NUMBER,
                            P_END_CLNT_ID   IN NUMBER,
                            P_MACR_ID       IN MACROREGIONS.MACR_ID%TYPE 
    )
  IS
    V_BTTS_ID NUMBER; 
    
    V_BORD_ID NUMBER := NULL; 
    
    V_CLNT_ID_ARR     BFAM_NUMBER_TABLE := BFAM_NUMBER_TABLE();
    V_CLNT_ID_OK_ARR  BFAM_NUMBER_TABLE := BFAM_NUMBER_TABLE();
    V_CLNT_ID_OFF_ARR BFAM_NUMBER_TABLE := BFAM_NUMBER_TABLE();
    V_CHECK_FEATURE   NUMBER := 0;
    
    
    V_START_AFTER     DATE := NULL;
    
  BEGIN
    
    
    IF G_CHDB_USE_MODE = 1 THEN 
       V_BORD_ID := PACK_BILLING.PREV_START_BILL_PROCESS(
                      P_PERIOD_DATE => P_BILL_DATE,
                      P_BCT_ID => 1, 
                      P_DIRECTION => 0, 
                      P_START_CLNT_ID => P_START_CLNT_ID,
                      P_END_CLNT_ID => P_END_CLNT_ID,
                      P_BRNC_ID => P_BRNC_ID,
                      P_BLGR_ID => P_BLGR_ID);
      IF V_BORD_ID IS NULL THEN
        
        RAISE_ERROR(10352); 
      END IF;
    END IF;
    
    
    IF P_MACR_ID IS NOT NULL AND I_BIS_TIME.IS_TIMEZONE_ON = 1 AND BFAM_COMMON_PG.GET_PRMT_NUMBER(PRM_AGGREGATE_BY_MACRO_TZ, 0) > 0 THEN
      V_START_AFTER := PACK_BILLING_AGGR_ONLINE.GET_AGGREGATE_DATE(P_PERIOD_DATE => P_BILL_DATE, P_MACR_ID => P_MACR_ID);
    END IF;
    
    
    IF NVL(P_TEST_MODE, 0) != 1 THEN
      V_CHECK_FEATURE := BFAM_FEATURES_PG.CHECK_FEATURE(P_FMOD_ID         => 2, 
                                                        P_CLNT_ID_ARR     => V_CLNT_ID_ARR,
                                                        P_OPER_DATE       => P_BILL_DATE,
                                                        P_CLNT_ID_OK_ARR  => V_CLNT_ID_OK_ARR,
                                                        P_CLNT_ID_OFF_ARR => V_CLNT_ID_OFF_ARR
                                                        );
    END IF;
    
    V_BTTS_ID := BTTS_SEQ.NEXTVAL;
    
    
    
    EXECUTE IMMEDIATE
'declare
   v_btts_id number := :v_btts_id;
   v_sets_max number := :v_sets_max;
   p_bill_date date := :p_bill_date;
   p_start_clnt_id number := :p_start_clnt_id;
   p_end_clnt_id number := :p_end_clnt_id;
   g_types_not_bill varchar2(1000) := :g_types_not_bill;
   p_brnc_id number := :p_brnc_id;
   p_blgr_id number := :p_blgr_id;
   g_flg_1   number := :g_flg_1;
   g_flg_2   number := :g_flg_2;
   g_flg_3   number := :g_flg_3;
   g_flg_4   number := :g_flg_4;
   g_flg_5   number := :g_flg_5;
   v_macr_id number := :v_macr_id;
 begin
   insert /*+ append parallel(bt_btse_clnt, '||G_PARALLEL||')*/ into bt_btse_clnt
            (btse_btse_id, clnt_clnt_id, assc_assc_id, btts_btts_id, root_assc_id, abtp_abtp_id, main_clnt_id, no_bill, assc_tree, range_clnt,
             -- clients
             jrtp_jrtp_id, clim_clim_id, activation_date, ext_bills,
             -- client_histories
             clpt_clpt_id, ctyp_ctyp_id, clis_clis_id, cur_cur_id, name, ccat_ccat_id, clcl_clcl_id,
             brnc_brnc_id, start_date, blgr_blgr_id, bnac_bnac_id, assc_state, dprm_dprm_id,
             -- jur_addresses
             inn, kpp
             )
      select btse_id, clnt_id, assc_assc_id, v_btts_id, null, null, null, null, null, n_range,
             -- clients
             jrtp_jrtp_id, clim_clim_id, activation_date, ext_bills,
             -- client_histories
             clpt_clpt_id, ctyp_ctyp_id, clis_clis_id, cur_cur_id, name, ccat_ccat_id, clcl_clcl_id,
             brnc_brnc_id, start_date, blgr_blgr_id, bnac_bnac_id, assc_state, dprm_dprm_id,
             -- jur_addresses
             inn, kpp
        from (select rr.*,
                     -- ����� ����� (20 ������)
/* �������� ������������ ������ �����
                     xxxxx                -- (16-20) - ����� ������ (�� 99999 �����)
                          xxxxxx          -- (10-15) - ����� ��������� (�� ��������� ������� �������� �� ��������� - mod_clnt)
                                xxxxx     -- (5-9)   - ����� ������ � ���������
                                     xxxx -- (1-4)   - ���������� ����� ������ ��� ��������� �����
                     xxxxxxxxxxxxxxxxxxxx -- ����� max 20 ������
*/
                     v_btts_id * 1000000000000000 -- ����� ������
                       + rr.n_range  * 1000000000 -- ����� ���������
                       + ceil(rr.rn / v_sets_max) * 10000 btse_id  -- ����� ������ � ���������
              from (select r.*,
                           row_number() over(partition by r.n_range order by r.clnt_id) rn
                      from (
                           select '||CASE WHEN V_CHECK_FEATURE != 1 
                                          THEN '/*+ full(cl) full(c) full(p) full(j) full(legf) parallel('||G_PARALLEL||')*/'
                                     END||'
                                  -- clients
                                  cl.clnt_id,
                                  cl.jrtp_jrtp_id,
                                  cl.clim_clim_id,
                                  cl.activation_date,
                                  cl.ext_bills,
                                  -- client_histories
                                  c.clpt_clpt_id,
                                  c.ctyp_ctyp_id,
                                  c.clis_clis_id,
                                  c.cur_cur_id,
                                  case when nvl(c.LGFM_LGFM_ID,0) = 0 then c.NAME
                                       else substr(LEGF.SHORT_NAME||'' ''||c.NAME ,1,240)
                                  end as name,
                                  c.ccat_ccat_id,
                                  c.clcl_clcl_id,
                                  c.brnc_brnc_id,
                                  c.start_date,
                                  c.blgr_blgr_id,
                                  c.bnac_bnac_id,
                                  c.assc_state,
                                  c.assc_assc_id,
                                  c.dprm_dprm_id,
                                  -- jur_addresses
                                  j.inn,
                                  j.kpp,
                                  -- ����������� ���������� �� ��������� �� balances
                                  p.mod_clnt n_range -- ����� �������� �� ����������
                              from client_histories c -- ������ �������� ������� ���� ������� �� p_bill_date
'||

CASE WHEN V_CHECK_FEATURE = 1 THEN
'                                   inner join bfam_feature_test_clients tc
                                           on tc.clnt_clnt_id = c.clnt_clnt_id and tc.fmod_fmod_id = 2
'
END||

'                                   inner join clients cl
                                           on cl.clnt_id = c.clnt_clnt_id
                                   inner join bfam_clnt_partitions p
                                           on p.clnt_clnt_id = c.clnt_clnt_id
                                  '||
                                  CASE WHEN P_MACR_ID IS NOT NULL THEN
                                  'inner join branches br
                                           on br.brnc_id = c.brnc_brnc_id
                                          and br.macr_macr_id = v_macr_id
                                  '
                                  END||
                                  ' left join jur_addresses j
                                           on j.clnt_clnt_id = c.clnt_clnt_id and
                                              j.start_date < p_bill_date and j.end_date >= p_bill_date
                                    left join LEGAL_FORMS LEGF
                                           on LEGF.LGFM_ID = C.LGFM_LGFM_ID
                             where c.assc_state is null -- ������� ��� ������ �� ������ � ��� � �� �������� ������� ������ ���
                               and c.start_date < p_bill_date and c.end_date >= p_bill_date
                               and c.clnt_clnt_id between p_start_clnt_id and p_end_clnt_id
                               and instr('',''||g_types_not_bill||'','', '',''||c.CTYP_CTYP_ID||'','') = 0
                               and (p_brnc_id is null or nvl(c.brnc_brnc_id, 0) = p_brnc_id) -- ������ �� �������
                               and nvl(c.blgr_blgr_id, 0) = p_blgr_id -- ������ �� ����������� ������
                              '||
                              
                              CASE WHEN P_ADD_CONDITION IS NOT NULL THEN
                              'and c.clnt_clnt_id in ('||P_ADD_CONDITION||')
                              'END
                              
                              ||'
                           ) r
                   ) rr
             );
 end;'
      USING V_BTTS_ID, V_SETS_MAX, P_BILL_DATE, P_START_CLNT_ID, P_END_CLNT_ID,
            G_TYPES_NOT_BILL, P_BRNC_ID, P_BLGR_ID,
            G_FLG_1, G_FLG_2, G_FLG_3, G_FLG_4, G_FLG_5,
            P_MACR_ID; 


    
    INSERT INTO BT_TASKS(BTTS_ID, BLGR_BLGR_ID, BILL_DATE, PRIORITY,
                         START_CLNT_ID, END_CLNT_ID, BLCL_BLCL_ID, BRNC_BRNC_ID,
                         BILL_BTST_ID,
                         BORD_BORD_ID, 
                         BTTS_SRC      
                        )
      VALUES(V_BTTS_ID, P_BLGR_ID, P_BILL_DATE, P_PRIORITY,
             P_START_CLNT_ID, P_END_CLNT_ID, P_BLCL_ID, P_BRNC_ID,
             GC_BTST_WAITING_FOR_RUN,
             V_BORD_ID, 
             DECODE(P_TEST_MODE, 1, 3, 1) 
            );
    COMMIT;

    
    
    INSERT INTO BT_SETS(BTTS_BTTS_ID, BTSE_ID, BTST_BTST_ID, BTSG_BTSG_ID, MACR_MACR_ID, START_AFTER)
      SELECT DISTINCT V_BTTS_ID, BTSE_BTSE_ID, GC_BTST_WAITING_FOR_RUN, 0, P_MACR_ID, V_START_AFTER
        FROM BT_BTSE_CLNT
       WHERE BTTS_BTTS_ID = V_BTTS_ID;

    COMMIT;
  END;
  
  
  
  
  PROCEDURE PREPARE_BT_ASSC(P_BILL_DATE IN DATE,
                            P_BLCL_ID   IN NUMBER,
                            P_PRIORITY  IN NUMBER,
                            P_BRNC_ID   IN NUMBER,
                            P_BLGR_ID   IN NUMBER,
                            P_AFKT_ID   IN NUMBER,
                            P_START_ASSC_ID IN NUMBER,
                            P_END_ASSC_ID   IN NUMBER
    )
  IS
    V_BTTS_ID NUMBER; 
    
    V_BORD_ID NUMBER := NULL; 
  BEGIN
    
    
    IF G_CHDB_USE_MODE = 1 THEN 
       V_BORD_ID := PACK_BILLING.PREV_START_BILL_PROCESS(
                      P_PERIOD_DATE => P_BILL_DATE,
                      P_BCT_ID => 1, 
                      P_DIRECTION => 0, 
                      P_START_CLNT_ID => NULL,
                      P_END_CLNT_ID => NULL,
                      P_START_ASSC_ID => P_START_ASSC_ID,
                      P_END_ASSC_ID => P_END_ASSC_ID,
                      P_BRNC_ID => P_BRNC_ID,
                      P_BLGR_ID => P_BLGR_ID);
      IF V_BORD_ID IS NULL THEN
        
        RAISE_ERROR(10352); 
      END IF;
    END IF;
    

    V_BTTS_ID := BTTS_SEQ.NEXTVAL;
    
    
    
    EXECUTE IMMEDIATE
'declare
   v_btts_id number := :v_btts_id;
   g_sets_min number := :g_sets_min;
   v_sets_max number := :v_sets_max;
   p_bill_date date := :p_bill_date;
   p_start_assc_id number := :p_start_assc_id;
   p_end_assc_id number := :p_end_assc_id;
   p_brnc_id number := :p_brnc_id;
   p_blgr_id number := :p_blgr_id;
   p_afkt_id number := :p_afkt_id;
 begin
   insert /*+ append parallel(bt_btse_clnt, '||G_PARALLEL||')*/ into bt_btse_clnt
            (btse_btse_id, clnt_clnt_id, assc_assc_id, btts_btts_id, root_assc_id, abtp_abtp_id, main_clnt_id, no_bill, assc_tree, range_clnt,
             -- clients
             jrtp_jrtp_id, clim_clim_id, activation_date, ext_bills,
             -- client_histories
             clpt_clpt_id, ctyp_ctyp_id, clis_clis_id, cur_cur_id, name, ccat_ccat_id, clcl_clcl_id,
             brnc_brnc_id, start_date, blgr_blgr_id, bnac_bnac_id, assc_state, dprm_dprm_id,
             -- jur_addresses
             inn, kpp
             )
      select btse_id, clnt_clnt_id, assc_assc_id, v_btts_id, root_assc_id, abtp_abtp_id, main_clnt_id, no_bill, assc_lv, n_range,
             -- clients
             jrtp_jrtp_id, clim_clim_id, activation_date, ext_bills,
             -- client_histories_view
             clpt_clpt_id, ctyp_ctyp_id, clis_clis_id, cur_cur_id, name_legf, ccat_ccat_id, clcl_clcl_id,
             brnc_brnc_id, start_date, blgr_blgr_id, bnac_bnac_id, assc_state, dprm_dprm_id,
             -- jur_addresses
             inn, kpp
        from (select rr.*,
                     -- ����� ����� (20 ������)
                     /* �������� ������������ ������ �����
                     xxxxx                -- (16-20) - ����� ������ (�� 99999 �����)
                          0               -- (15)    - ��� �����: ������� ����� �������� ������������ (��� ������� �� ������)
                          5               -- (15)    - ��� �����: ������� ����� ������� ������������ (��� ������� �������)
                         +1               -- (15)    - ��� �����: ����.����� (����� main_clnt_id �� ����������� ��� ����� 5)
                           -- ��� ����� ������� �����������
                           xxxxx          -- (10-14) - ����� ����������� (��� ����� ������� �����������)
                                xxxxx     -- (5-9)   - ����� ������ �� ����������� (��� ����� ������� �����������)
                           -- ��� ����� ������ �����������
                           xxx            -- (12-14) - mod_clnt
                              xxxxxxx     -- (5-11)  - ����� ������ (�� mod_clnt)
                                     xxxx -- (1-4)   - ���������� ����� ������ ��� ��������� ����� (��� ����� ������ �����������)
                     xxxxxxxxxxxxxxxxxxxx -- ����� max 20 ������
                     */
                     v_btts_id                  * 1000000000000000 -- ����� ������
                        + case when rr.qt_assc < g_sets_min then
                               5  -- ����� ������ ���
                          else 0  -- ����� �������� ���
                          end                    * 100000000000000 -- ��� �����
                        + case when rr.qt_assc >= g_sets_min then  -- ���� ����������� ������� ����� ��� �� ����������� ���� (������� ���������)
                             rr.rn_assc               * 1000000000 -- ���������� ����� rn_assc
                             + ceil(rr.rn / v_sets_max)    * 10000 -- ����� ������ (�� �����������)
                          else -- ��������� ������ ����������� (������ ����������� ������ ��������� ����������� ������ � 1 ����)
                             rr.n_range             * 100000000000    -- mod_clnt
                             + ceil(rr.rn_assc/v_sets_max) * 10000    -- ����� ������ (�� mod_clnt)
                          end btse_id
                from (select ss.*,
                             case when ss.qt_assc >= g_sets_min then
                               -- �������� ������� �����������
                               dense_rank() over(order by case when ss.qt_assc >= g_sets_min then ss.root_assc_id end)
                             else
                               -- ���-�� �������� � ������ ������������ ����������� ������ � ������� �������� ���-�� �������� � ����������� !!! � ������ mod_clnt
                               sum(case when ss.qt_assc < g_sets_min and ss.rn = 1 then ss.qt_assc end) over(partition by p.mod_clnt order by ss.qt_assc desc, ss.root_assc_id, ss.rn)
                             end rn_assc,
                             p.mod_clnt n_range
                        from (select r.*,
                                     row_number() over(partition by r.root_assc_id order by 1) rn, -- ��������� �������� ������ ������������
                                     count(1) over(partition by r.root_assc_id) qt_assc -- ���-�� �������� � �����������
                                     '||'
                                from (select /*+ full(cl) full(j) full(ch) full(legf) parallel('||G_PARALLEL||')*/
                                             ass.*,
                                             ch.*,
                                             case when nvl(ch.LGFM_LGFM_ID,0) = 0 then ch.NAME
                                                  else substr(LEGF.SHORT_NAME||'' ''||ch.NAME ,1,240)
                                             end as name_legf,
                                             -- ������� ��� �� ���� �������� ������ �� ������ � ������������
                                             case when ch.end_date < p_bill_date then 1 end no_bill,
                                             -- ��� ���������� �� �������� �� p_bill_date
                                             -- �� clients
                                             cl.jrtp_jrtp_id,
                                             cl.clim_clim_id,
                                             cl.activation_date,
                                             cl.ext_bills,
                                             -- �� jur_addresses
                                             j.inn,
                                             j.kpp,
                                             row_number() over(partition by ch.clnt_clnt_id order by ch.end_date desc) ch_rn
                                        from -- �������� ������������ �� ���� ��������
                                             (select connect_by_root s.assc_assc_id as root_assc_id, -- �������� �����������
                                                     s.assc_assc_id ass_assc_id,
                                                     s.main_clnt_id,
                                                     s.abtp_abtp_id,
                                                     reverse(sys_connect_by_path(reverse(to_char(s.assc_assc_id)),'','')) assc_lv -- ������ � �������� �������
                                                from (select h.assc_assc_id,
                                                             h.par_assc_id,
                                                             h.alev_alev_id,
                                                             h.abtp_abtp_id,
                                                             h.main_clnt_id,
                                                             h.brnc_brnc_id
                                                        from association_histories h
                                                       where h.start_date < p_bill_date and h.end_date >= p_bill_date -- ���������� ������
                                                         and h.alev_alev_id is not null -- ������� ���
                                                         and nvl(h.blgr_blgr_id, 0) = p_blgr_id -- ������ �� ����������� ������
                                                         and nvl(p_afkt_id, 0) = nvl(h.afkt_afkt_id, 0) -- ������ �� ���� ���
                                                     ) s
                                               where CONNECT_BY_ISLEAF = 1 -- ��������� ������ ����������� ������� ������ (� ���������)
                                                     -- ������� �� ��������� ���
                                                 and connect_by_root s.assc_assc_id between p_start_assc_id and p_end_assc_id
                                                 and (p_brnc_id is null or nvl(connect_by_root s.brnc_brnc_id, 0) = p_brnc_id)
                                             connect by prior s.assc_assc_id = s.par_assc_id  -- ���� �� ������
                                               start with s.par_assc_id is null -- ������� � ��� �������� ������
                                             ) ass
                                               -- ������ �������� ������� ������� � ��� ����������� � ����������� ������ (�� ������ ������ �� p_bill_date)
                                               inner join client_histories ch
                                                               on ch.assc_assc_id = ass.ass_assc_id and
                                                                  ch.start_date <= p_bill_date and ch.end_date > trunc(p_bill_date, ''MM'') and
                                                                  ch.start_date < ch.end_date and
                                                                  ch.assc_state = ''A'' -- ������� ��� ������ ������ � ���
                                               -- ��� ���������� �� �������� �� p_bill_date
                                               inner join clients cl
                                                       on cl.clnt_id = ch.clnt_clnt_id
                                                left join jur_addresses j
                                                       on j.clnt_clnt_id = ch.clnt_clnt_id and
                                                          j.start_date < p_bill_date and j.end_date >= p_bill_date
                                                left join LEGAL_FORMS LEGF
                                                       on LEGF.LGFM_ID = CH.LGFM_LGFM_ID
                                     ) r
                               where r.ch_rn = 1 -- ��������� ������ 1 ������ �� ������� (� ����� ������� �����)
                             ) ss
                             inner join bfam_clnt_partitions p
                                     on p.clnt_clnt_id = ss.clnt_clnt_id
                     ) rr
             );
 end;'
      USING V_BTTS_ID, G_SETS_MIN, V_SETS_MAX, P_BILL_DATE, P_START_ASSC_ID, P_END_ASSC_ID,
            P_BRNC_ID, P_BLGR_ID, P_AFKT_ID;


    
    INSERT INTO BT_TASKS(BTTS_ID, BLGR_BLGR_ID, BILL_DATE, PRIORITY,
                         START_ASSC_ID, END_ASSC_ID, BLCL_BLCL_ID, BRNC_BRNC_ID, AFKT_AFKT_ID,
                         BILL_BTST_ID,
                         BORD_BORD_ID 
                        )
      VALUES(V_BTTS_ID, P_BLGR_ID, P_BILL_DATE, P_PRIORITY,
             P_START_ASSC_ID, P_END_ASSC_ID, P_BLCL_ID, P_BRNC_ID, P_AFKT_ID,
             1,
             V_BORD_ID 
            );
    COMMIT;

    
    
    
    INSERT INTO BT_BTSE_CLNT
            (BTSE_BTSE_ID, CLNT_CLNT_ID, ASSC_ASSC_ID, BTTS_BTTS_ID, ROOT_ASSC_ID, ABTP_ABTP_ID, MAIN_CLNT_ID, NO_BILL, ASSC_TREE, RANGE_CLNT,
             
             JRTP_JRTP_ID, CLIM_CLIM_ID, ACTIVATION_DATE, EXT_BILLS,
             
             CLPT_CLPT_ID, CTYP_CTYP_ID, CLIS_CLIS_ID, CUR_CUR_ID, NAME, CCAT_CCAT_ID, CLCL_CLCL_ID,
             BRNC_BRNC_ID, START_DATE, BLGR_BLGR_ID, BNAC_BNAC_ID, ASSC_STATE, DPRM_DPRM_ID,
             
             INN, KPP
             )
      SELECT DISTINCT
             MIN(BC.BTSE_BTSE_ID) OVER(PARTITION BY BC.ROOT_ASSC_ID) + 100000000000000 BTSE_BTSE_ID,
             BC.MAIN_CLNT_ID,
             BC.ASSC_ASSC_ID,
             V_BTTS_ID,
             BC.ROOT_ASSC_ID,
             NULL, NULL, NULL, NULL, NULL,
             
             CL.JRTP_JRTP_ID, CL.CLIM_CLIM_ID, CL.ACTIVATION_DATE, CL.EXT_BILLS,
             
             CH.CLPT_CLPT_ID, CH.CTYP_CTYP_ID, CH.CLIS_CLIS_ID, CH.CUR_CUR_ID, CH.NAME, CH.CCAT_CCAT_ID, CH.CLCL_CLCL_ID,
             CH.BRNC_BRNC_ID, CH.START_DATE, CH.BLGR_BLGR_ID, CH.BNAC_BNAC_ID, CH.ASSC_STATE, CH.DPRM_DPRM_ID,
             
             J.INN, J.KPP
        FROM BT_BTSE_CLNT BC
             INNER JOIN CLIENT_HISTORIES_VIEW CH
                     ON CH.CLNT_CLNT_ID = BC.MAIN_CLNT_ID AND
                        CH.START_DATE < P_BILL_DATE AND CH.END_DATE >= P_BILL_DATE
             
             INNER JOIN CLIENTS CL
                     ON CL.CLNT_ID = BC.MAIN_CLNT_ID
              LEFT JOIN JUR_ADDRESSES J
                     ON J.CLNT_CLNT_ID = BC.MAIN_CLNT_ID AND
                        J.START_DATE < P_BILL_DATE AND J.END_DATE >= P_BILL_DATE
      WHERE BC.ROOT_ASSC_ID IS NOT NULL
        AND BC.MAIN_CLNT_ID IS NOT NULL
        AND BC.ABTP_ABTP_ID = 2
        AND BC.BTTS_BTTS_ID = V_BTTS_ID
        
        AND SUBSTR(LPAD(TO_CHAR(BC.BTSE_BTSE_ID), 20, 0), 6, 1) <> '5'; 

    COMMIT;

    
    
    INSERT INTO BT_SETS(BTTS_BTTS_ID, BTSE_ID, ASSC_ASSC_ID, BTSG_BTSG_ID, BTST_BTST_ID)
      SELECT DISTINCT V_BTTS_ID, BTSE_BTSE_ID,
             CASE WHEN SUBSTR(LPAD(TO_CHAR(BTSE_BTSE_ID), 20, 0), 6, 1) = '5' THEN -1 ELSE ROOT_ASSC_ID END,
             CASE WHEN ASSC_TREE IS NULL THEN 5 
                  WHEN SUBSTR(LPAD(TO_CHAR(BTSE_BTSE_ID), 20, 0), 6, 1) = '5' THEN 0 
             ELSE 2
             END, 1
        FROM BT_BTSE_CLNT
       WHERE BTTS_BTTS_ID = V_BTTS_ID;

    COMMIT;

    
    
    
    INSERT INTO BT_SETS(BTTS_BTTS_ID, BTSE_ID, ASSC_ASSC_ID, BTSG_BTSG_ID, BTST_BTST_ID)
      SELECT V_BTTS_ID, - MIN(BTSE_ID), ASSC_ASSC_ID, 5, 1
        FROM BT_SETS
       WHERE BTTS_BTTS_ID = V_BTTS_ID
         AND BTSG_BTSG_ID > 0 
       GROUP BY ASSC_ASSC_ID
      HAVING MAX(BTSG_BTSG_ID) = 2; 

    COMMIT;

  END;
  
  
  
  
  FUNCTION GET_BLCL_ID(
    P_BLCL_ID_MIN NUMBER,
    P_BLCL_ID_MAX NUMBER
    ) RETURN NUMBER
  IS
    V_RES NUMBER;
  BEGIN
    FOR REC IN (SELECT B.*,
                       COUNT(1) OVER() QT_BLCL 
                  FROM BILL_CYCLES B
                 WHERE B.CYCLE_DATE = P_BILL_DATE
                   AND B.BCT_BCT_ID = 1 
                   AND B.BLCL_ID BETWEEN P_BLCL_ID_MIN AND P_BLCL_ID_MAX
                   AND (B.BLGR_BLGR_ID = P_BLGR_ID OR P_BLGR_ID IS NULL)
                   AND (B.BRNC_BRNC_ID IS NULL OR B.BRNC_BRNC_ID = P_BRNC_ID)
                   AND ROWNUM < 3
               ) LOOP
      IF REC.QT_BLCL > 1 THEN
        
        RAISE_ERROR(10282); 
      END IF;
      IF REC.CLST_CLST_ID = 3 AND REC.END_VOLUME >= P_BILL_DATE THEN
        V_RES := REC.BLCL_ID;
        V_BLGR_ID := NVL(REC.BLGR_BLGR_ID, 0);
      ELSE
        
        RAISE_ERROR(10292); 
      END IF;
      EXIT;
    END LOOP;
    
    IF V_RES IS NULL THEN 
      
      RAISE_ERROR(10283); 
    END IF;
    RETURN V_RES;
  END;
  
BEGIN
  
  V_SAVED_SESSION_STATE := PACK_BILLING_TASK.GET_SESSION_PARALLEL_STATE();
  BEGIN
    PACK_BILLING_TASK.SET_FORCE_SESSION();
  
    V_LOG_ID := TO_SYS_LOG(P_MESSAGE => 'BT_BGI add_task_START: blcl_id = '     ||V_BLCL_ID
                                                          ||' , brnc_id = '     ||P_BRNC_ID
                                                          ||' , start_clnt_id ='||P_START_CLNT_ID
                                                          ||' , end_clnt_id='   ||P_END_CLNT_ID
                                                          ||' , start_assc_id ='||P_START_ASSC_ID
                                                          ||' , end_assc_id='   ||P_END_ASSC_ID
                                                          ||' , test_mode='     ||P_TEST_MODE  
                                                          ||' , macr_id='       ||P_MACR_ID 
                                                          );
    
    IF GET_QT_JOB_MASK('bt_bgi_job_%') + GET_QT_JOB_MASK('bt_bgi_run_job_init%') > 0 THEN 
      RAISE_ERROR(10281); 
    END IF;

    
    IF V_BLCL_ID IS NULL THEN
      V_BLCL_MIN := API_PART_PG.GET_MIN_ID_BY_DATE('BILL_CYCLES', TRUNC(P_BILL_DATE, 'mm'));
      V_BLCL_MAX := API_PART_PG.GET_MAX_ID_BY_DATE('BILL_CYCLES', P_BILL_DATE);
    ELSE 
      V_BLCL_MIN := V_BLCL_ID;
      V_BLCL_MAX := V_BLCL_ID;
    END IF;
    IF NVL(P_TEST_MODE, 0) != 1 THEN 
      V_BLCL_ID := GET_BLCL_ID(V_BLCL_MIN, V_BLCL_MAX);
    END IF;
    
    IF NVL(P_START_CLNT_ID, P_END_CLNT_ID) IS NOT NULL THEN 
      
      IF P_MACR_ID IS NULL AND I_BIS_TIME.IS_TIMEZONE_ON = 1 AND BFAM_COMMON_PG.GET_PRMT_NUMBER(PRM_AGGREGATE_BY_MACRO_TZ, 0) > 0 THEN
        FOR C_MACR IN (SELECT M.MACR_ID FROM MACROREGIONS M) LOOP
          PREPARE_BT_CLNT(P_BILL_DATE, V_BLCL_ID, P_PRIORITY, P_BRNC_ID, V_BLGR_ID, P_START_CLNT_ID, P_END_CLNT_ID,
                          P_MACR_ID => C_MACR.MACR_ID);
        END LOOP;
      ELSE
      
        PREPARE_BT_CLNT(P_BILL_DATE, V_BLCL_ID, P_PRIORITY, P_BRNC_ID, V_BLGR_ID, P_START_CLNT_ID, P_END_CLNT_ID,
                        P_MACR_ID => P_MACR_ID); 
      END IF;
    END IF;
    IF NVL(P_START_ASSC_ID, P_END_ASSC_ID) IS NOT NULL THEN 
      PREPARE_BT_ASSC(P_BILL_DATE, V_BLCL_ID, P_PRIORITY, P_BRNC_ID, V_BLGR_ID, P_AFKT_ID, P_START_ASSC_ID, P_END_ASSC_ID);
    END IF;
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI add_task_END',
                        P_SLOG_ID => V_LOG_ID);
  
    PACK_BILLING_TASK.SET_SESSION_PARALLEL_STATE(V_SAVED_SESSION_STATE);
  EXCEPTION
    WHEN OTHERS THEN
      PACK_BILLING_TASK.SET_SESSION_PARALLEL_STATE(V_SAVED_SESSION_STATE);
      RAISE;
  END;
  
EXCEPTION
  WHEN OTHERS THEN
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI add_task ERROR: ' || SQLERRM,
                        P_SLOG_ID => V_LOG_ID,
                        P_MSG_TYPE => LOG_COMMON.ERRORMSG);
    ROLLBACK;
    RAISE;
END;

  
  PROCEDURE BT_ADD_ROLLBACK_TASK(P_BILL_DATE   IN DATE, 
                                 P_CLNT_ID_ARR IN BFAM_NUMBER_TABLE, 
                                 P_PRIORITY    IN NUMBER DEFAULT 500, 
                                 P_BLCL_ID     BILL_CYCLES.BLCL_ID%TYPE, 
                                 P_TEST_MODE   IN NUMBER DEFAULT 0, 
                                                                    
                                 P_NEED_REBILL    IN BOOLEAN DEFAULT FALSE, 
                                 P_ROLLBACK_CALLS IN BOOLEAN DEFAULT TRUE 
                                 ) AS
    C_SETS_MAX CONSTANT NUMBER := 1000; 
    V_BTTS_ID         NUMBER; 
    V_BTSE_ID         NUMBER; 
    V_BTSE_ID_ARR     BFAM_NUMBER_TABLE; 
    V_BTSE_ID_ARR_ERR BFAM_NUMBER_TABLE; 
    V_BTSE_ID_ARR_OK  BFAM_NUMBER_TABLE; 
    V_CLNT_ID_ARR_OK  BFAM_NUMBER_TABLE; 
    V_CLNT_ID_ARR_ERR BFAM_NUMBER_TABLE; 

    
    TYPE T_BGIRQ_CLNT_REC IS RECORD(
      CLNT_ID  NUMBER,
      BGIRQ_ID NUMBER);
    TYPE T_BGIRQ_CLNT_ARR IS TABLE OF T_BGIRQ_CLNT_REC;
    V_BGIRQ_CLNT_ARR T_BGIRQ_CLNT_ARR := T_BGIRQ_CLNT_ARR();

    
    PROCEDURE STORE_BGIRQ_ID(LP_BTTS_ID IN NUMBER) AS
    BEGIN
      SELECT /*+ cardinality(t, 1) */
             BBC.CLNT_CLNT_ID,
             BTSE.BGIRQ_BGIRQ_ID
        BULK COLLECT
        INTO V_BGIRQ_CLNT_ARR
        FROM BT_BTSE_CLNT BBC
        JOIN TABLE(P_CLNT_ID_ARR) T
          ON (T.COLUMN_VALUE = BBC.CLNT_CLNT_ID)
        JOIN BT_TASKS BTTS
          ON (BTTS.BTTS_ID = BBC.BTTS_BTTS_ID)
        JOIN BT_SETS BTSE
          ON (BTSE.BTSE_ID = BBC.BTSE_BTSE_ID)
       WHERE BTTS.BLCL_BLCL_ID = P_BLCL_ID
             AND BBC.BTTS_BTTS_ID <> LP_BTTS_ID
             AND BTSE.BGIRQ_BGIRQ_ID IS NOT NULL;
    END STORE_BGIRQ_ID;

    
    PROCEDURE CLEAR_BT_BTSE_CLNT(LP_CLNT_ID_ARR IN BFAM_NUMBER_TABLE,
                                 LP_BTTS_ID     IN BT_SETS.BTST_BTST_ID%TYPE) AS
    BEGIN
      IF LP_CLNT_ID_ARR.COUNT > 0
      THEN
        
        FORALL I IN 1 .. LP_CLNT_ID_ARR.COUNT
          DELETE FROM BT_BTSE_CLNT BBC
           WHERE BBC.CLNT_CLNT_ID = LP_CLNT_ID_ARR(I)
                 AND BBC.BTTS_BTTS_ID <> LP_BTTS_ID
                 AND BBC.ASSC_ASSC_ID IS NULL;
        
      END IF;
    END CLEAR_BT_BTSE_CLNT;

    
    PROCEDURE BUILD_TASK(LP_BTTS_ID           IN BT_TASKS.BTTS_ID%TYPE, 
                         LP_BTST_ID           IN BT_SETS.BTST_BTST_ID%TYPE, 
                         LP_CLNT_ID_ARR       IN BFAM_NUMBER_TABLE DEFAULT NULL, 
                         LP_FOR_ROLLBACK_MODE IN BOOLEAN DEFAULT TRUE, 
                         LP_BTSE_ID_ARR       OUT BFAM_NUMBER_TABLE 
                         ) AS
      LV_BTSE_ID_ARR BFAM_NUMBER_TABLE; 
      
      PROCEDURE MAKE_BT_BTSE_CLNT AS
      BEGIN
        INSERT INTO BT_BTSE_CLNT
          (BTSE_BTSE_ID,
           CLNT_CLNT_ID,
           ASSC_ASSC_ID,
           BTTS_BTTS_ID,
           RANGE_CLNT,
           JRTP_JRTP_ID,
           CLIM_CLIM_ID,
           ACTIVATION_DATE,
           EXT_BILLS,
           CLPT_CLPT_ID,
           CTYP_CTYP_ID,
           CLIS_CLIS_ID,
           CUR_CUR_ID,
           "NAME",
           CCAT_CCAT_ID,
           CLCL_CLCL_ID,
           BRNC_BRNC_ID,
           START_DATE,
           BLGR_BLGR_ID,
           BNAC_BNAC_ID,
           ASSC_STATE,
           DPRM_DPRM_ID,
           INN,
           KPP)
          SELECT BTSE_ID,
                 CLNT_ID,
                 ASSC_ASSC_ID,
                 LP_BTTS_ID,
                 N_RANGE,
                 
                 JRTP_JRTP_ID,
                 CLIM_CLIM_ID,
                 ACTIVATION_DATE,
                 EXT_BILLS,
                 
                 CLPT_CLPT_ID,
                 CTYP_CTYP_ID,
                 CLIS_CLIS_ID,
                 CUR_CUR_ID,
                 "NAME",
                 CCAT_CCAT_ID,
                 CLCL_CLCL_ID,
                 BRNC_BRNC_ID,
                 START_DATE,
                 BLGR_BLGR_ID,
                 BNAC_BNAC_ID,
                 ASSC_STATE,
                 DPRM_DPRM_ID,
                 
                 INN,
                 KPP
            FROM (SELECT RR.*,
                         
                         






                         V_BTTS_ID * 1000000000000000 
                         + RR.N_RANGE * 1000000000 
                         + CEIL(RR.RN / C_SETS_MAX) *
                         10000 BTSE_ID 
                    FROM (SELECT R.*,
                                 ROW_NUMBER() OVER(PARTITION BY R.N_RANGE ORDER BY R.CLNT_ID) RN
                            FROM (SELECT
                                  
                                   CL.CLNT_ID,
                                   CL.JRTP_JRTP_ID,
                                   CL.CLIM_CLIM_ID,
                                   CL.ACTIVATION_DATE,
                                   CL.EXT_BILLS,
                                   
                                   C.CLPT_CLPT_ID,
                                   C.CTYP_CTYP_ID,
                                   C.CLIS_CLIS_ID,
                                   C.CUR_CUR_ID,
                                   DECODE(NVL(C.LGFM_LGFM_ID, 0),
                                          0,
                                          C.NAME,
                                          SUBSTR(LEGF.SHORT_NAME || ' ' ||
                                                 C.NAME,
                                                 1,
                                                 240)) AS "NAME",
                                   C.CCAT_CCAT_ID,
                                   C.CLCL_CLCL_ID,
                                   C.BRNC_BRNC_ID,
                                   C.START_DATE,
                                   C.BLGR_BLGR_ID,
                                   C.BNAC_BNAC_ID,
                                   C.ASSC_STATE,
                                   C.ASSC_ASSC_ID,
                                   C.DPRM_DPRM_ID,
                                   
                                   J.INN,
                                   J.KPP,
                                   
                                   P.MOD_CLNT N_RANGE 
                                    FROM TABLE(LP_CLNT_ID_ARR) CORE
                                    JOIN CLIENT_HISTORIES C 
                                      ON (CORE.COLUMN_VALUE = C.CLNT_CLNT_ID)
                                    JOIN CLIENTS CL
                                      ON (CL.CLNT_ID = C.CLNT_CLNT_ID)
                                    JOIN BFAM_CLNT_PARTITIONS P
                                      ON (P.CLNT_CLNT_ID = C.CLNT_CLNT_ID)
                                    LEFT JOIN BRANCHES BR
                                      ON (BR.BRNC_ID = C.BRNC_BRNC_ID)
                                    LEFT JOIN JUR_ADDRESSES J
                                      ON (J.CLNT_CLNT_ID = C.CLNT_CLNT_ID AND
                                         J.START_DATE < P_BILL_DATE AND
                                         J.END_DATE >= P_BILL_DATE)
                                    LEFT JOIN LEGAL_FORMS LEGF
                                      ON (LEGF.LGFM_ID = C.LGFM_LGFM_ID)
                                   WHERE C.ASSC_STATE IS NULL 
                                         AND C.START_DATE < P_BILL_DATE
                                         AND C.END_DATE >= P_BILL_DATE) R) RR);
        
        SELECT UNIQUE(BBC.BTSE_BTSE_ID)
          BULK COLLECT
          INTO LV_BTSE_ID_ARR
          FROM BT_BTSE_CLNT BBC
         WHERE BBC.BTTS_BTTS_ID = LP_BTTS_ID;
      END MAKE_BT_BTSE_CLNT;

      
      PROCEDURE MAKE_BT_SETS AS
        TYPE T_BTSE_REC IS RECORD(
          BTTS_BTTS_ID   BT_SETS.BTTS_BTTS_ID%TYPE,
          BTSE_ID        BT_SETS.BTSE_ID%TYPE,
          BTST_BTST_ID   BT_SETS.BTST_BTST_ID%TYPE,
          BTSG_BTSG_ID   BT_SETS.BTSG_BTSG_ID%TYPE,
          BGIRQ_BGIRQ_ID BT_SETS.BGIRQ_BGIRQ_ID%TYPE);
        TYPE T_BTSE_ARR IS TABLE OF T_BTSE_REC;
        V_BTSE_ARR T_BTSE_ARR := T_BTSE_ARR();

        
        FUNCTION GET_BGIRQ_ID(LP_BTSE_ID NUMBER) RETURN NUMBER AS
        BEGIN
          FOR J IN (SELECT BBC.CLNT_CLNT_ID
                      FROM BT_BTSE_CLNT BBC
                     WHERE BBC.BTSE_BTSE_ID = LP_BTSE_ID)
          LOOP
            
            IF V_BGIRQ_CLNT_ARR.COUNT > 0
            THEN
              FOR I IN V_BGIRQ_CLNT_ARR.FIRST .. V_BGIRQ_CLNT_ARR.LAST
              LOOP
                IF V_BGIRQ_CLNT_ARR(I).CLNT_ID = J.CLNT_CLNT_ID
                THEN
                  
                  RETURN V_BGIRQ_CLNT_ARR(I).BGIRQ_ID;
                END IF;
              END LOOP I;
            ELSE
              RETURN NULL; 
            END IF;
          END LOOP J;
        END GET_BGIRQ_ID;
        
      BEGIN
        
        FOR I IN LV_BTSE_ID_ARR.FIRST .. LV_BTSE_ID_ARR.LAST
        LOOP
          V_BTSE_ARR.EXTEND;
          V_BTSE_ARR(I).BTTS_BTTS_ID := LP_BTTS_ID;
          V_BTSE_ARR(I).BTSE_ID := LV_BTSE_ID_ARR(I);
          V_BTSE_ARR(I).BTST_BTST_ID := LP_BTST_ID;
          V_BTSE_ARR(I).BTSG_BTSG_ID := 0;
          V_BTSE_ARR(I).BGIRQ_BGIRQ_ID := NULL;
        END LOOP I;

        
        IF LP_FOR_ROLLBACK_MODE
        THEN
          FOR I IN V_BTSE_ARR.FIRST .. V_BTSE_ARR.LAST
          LOOP
            V_BTSE_ARR(I).BGIRQ_BGIRQ_ID := GET_BGIRQ_ID(V_BTSE_ARR(I).BTSE_ID);
          END LOOP I;
        END IF;

        
        FORALL I IN V_BTSE_ARR.FIRST .. V_BTSE_ARR.LAST
          INSERT INTO BT_SETS
            (BTTS_BTTS_ID,
             BTSE_ID,
             BTST_BTST_ID,
             BTSG_BTSG_ID,
             BGIRQ_BGIRQ_ID)
          VALUES
            (V_BTSE_ARR(I).BTTS_BTTS_ID,
             V_BTSE_ARR(I).BTSE_ID,
             V_BTSE_ARR(I).BTST_BTST_ID,
             V_BTSE_ARR(I).BTSG_BTSG_ID,
             V_BTSE_ARR(I).BGIRQ_BGIRQ_ID);
        COMMIT; 
      END MAKE_BT_SETS;

      
      PROCEDURE MAKE_BT_TASK AS
      BEGIN
        INSERT INTO BT_TASKS
          (BTTS_ID,
           BILL_DATE,
           PRIORITY,
           BLCL_BLCL_ID,
           BILL_BTST_ID,
           BTTS_SRC)
        VALUES
          (LP_BTTS_ID,
           P_BILL_DATE,
           P_PRIORITY,
           P_BLCL_ID,
           LP_BTST_ID,
           DECODE(P_TEST_MODE, 1, 3, 1));
        COMMIT;
      END MAKE_BT_TASK;
    BEGIN
      
      CLEAR_BT_BTSE_CLNT(P_CLNT_ID_ARR, LP_BTTS_ID);
      
      MAKE_BT_BTSE_CLNT();
      
      MAKE_BT_SETS();
      
      MAKE_BT_TASK();
      
      LP_BTSE_ID_ARR := LV_BTSE_ID_ARR;
    END BUILD_TASK;
    
    PROCEDURE ROLLBACK_HANDLER AS
    BEGIN
      
      V_BTSE_ID_ARR_OK  := BFAM_NUMBER_TABLE();
      V_BTSE_ID_ARR_ERR := BFAM_NUMBER_TABLE();
      V_CLNT_ID_ARR_OK  := BFAM_NUMBER_TABLE();
      V_CLNT_ID_ARR_ERR := BFAM_NUMBER_TABLE();
      
      FOR I IN V_BTSE_ID_ARR.FIRST .. V_BTSE_ID_ARR.LAST
      LOOP
        <<BTSE_CYCLE>>
        DECLARE
          V_CLNT_ID_ARR_ERR_TMP BFAM_NUMBER_TABLE;
          V_CLNT_ID_ARR_OK_TMP  BFAM_NUMBER_TABLE;
        BEGIN
          
          BT_ROLLBACK(P_ID             => V_BTSE_ID_ARR(I),
                      P_ROLLBACK_CALLS => P_ROLLBACK_CALLS);
          
          SELECT CLNT_CLNT_ID
            BULK COLLECT
            INTO V_CLNT_ID_ARR_OK_TMP 
            FROM BT_BTSE_CLNT BBC
           WHERE BBC.BTSE_BTSE_ID = V_BTSE_ID_ARR(I);
          DELETE BT_BTSE_CLNT WHERE BTSE_BTSE_ID = V_BTSE_ID_ARR(I); 
          COMMIT;
          V_CLNT_ID_ARR_OK := V_CLNT_ID_ARR_OK MULTISET UNION
                              V_CLNT_ID_ARR_OK_TMP; 
        EXCEPTION
          WHEN OTHERS THEN
            
            SELECT CLNT_CLNT_ID
              BULK COLLECT
              INTO V_CLNT_ID_ARR_ERR_TMP
              FROM BT_BTSE_CLNT BBC
             WHERE BBC.BTSE_BTSE_ID = V_BTSE_ID_ARR(I);
            DELETE BT_BTSE_CLNT WHERE BTSE_BTSE_ID = V_BTSE_ID_ARR(I); 
            COMMIT;
            V_CLNT_ID_ARR_ERR := V_CLNT_ID_ARR_ERR MULTISET UNION
                                 V_CLNT_ID_ARR_ERR_TMP; 
        END BTSE_CYCLE;
      END LOOP I;
      
      
      IF V_CLNT_ID_ARR_ERR.COUNT > 0
      THEN
        V_BTTS_ID := BTTS_SEQ.NEXTVAL;
        BUILD_TASK(LP_BTTS_ID     => V_BTTS_ID,
                   LP_BTST_ID     => GC_BTST_ROLLBACK_ERROR,
                   LP_CLNT_ID_ARR => V_CLNT_ID_ARR_ERR,
                   LP_BTSE_ID_ARR => V_BTSE_ID_ARR_ERR);
      END IF;
      
      IF V_CLNT_ID_ARR_OK.COUNT > 0
      THEN
        V_BTTS_ID := BTTS_SEQ.NEXTVAL;
        BUILD_TASK(V_BTTS_ID,
                   (CASE WHEN P_ROLLBACK_CALLS AND P_NEED_REBILL THEN
                    GC_BTST_WAITING_FOR_RUN WHEN
                    P_ROLLBACK_CALLS AND NOT P_NEED_REBILL THEN
                    GC_BTST_ROLLBACK_AND_AGGR_DEL WHEN
                    NOT P_ROLLBACK_CALLS AND P_NEED_REBILL THEN
                    GC_BTST_READY_FOR_BILLING WHEN
                    NOT P_ROLLBACK_CALLS AND NOT P_NEED_REBILL THEN
                    GC_BTST_ROLLBACK END),
                   V_CLNT_ID_ARR_OK,
                   FALSE, 
                   V_BTSE_ID_ARR_OK);
      END IF;
    END ROLLBACK_HANDLER;
    
    PROCEDURE REBILL_HANDLER AS
      V_ERR_CLNTS PACK_BILLING.T_ERR_CLNTS;
    BEGIN
      
      IF P_NEED_REBILL
         AND V_BTSE_ID_ARR_OK.COUNT > 0
      THEN
        
        START_BGI_PROCCESS(P_BTTS_ID => V_BTTS_ID);
      END IF;
    END REBILL_HANDLER;
    
  BEGIN
    IF P_CLNT_ID_ARR.COUNT > 0
    THEN
      V_BTTS_ID := BTTS_SEQ.NEXTVAL;
      STORE_BGIRQ_ID(V_BTTS_ID); 
      
      BUILD_TASK(LP_BTTS_ID     => V_BTTS_ID,
                 LP_BTST_ID     => GC_BTST_WAITING_FOR_ROLLBACK,
                 LP_CLNT_ID_ARR => P_CLNT_ID_ARR,
                 LP_BTSE_ID_ARR => V_BTSE_ID_ARR);
      
      IF V_BTSE_ID_ARR.COUNT > 0
      THEN
        ROLLBACK_HANDLER(); 
        REBILL_HANDLER(); 
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END BT_ADD_ROLLBACK_TASK;



PROCEDURE BT_ADD_IND
IS
  V_SAVED_SESSION_STATE PACK_BILLING_TASK.SESSION_PARALLEL_STATE; 
BEGIN
  
  V_SAVED_SESSION_STATE := PACK_BILLING_TASK.GET_SESSION_PARALLEL_STATE();
  BEGIN
    PACK_BILLING_TASK.SET_FORCE_SESSION();
  
    
    

    EXECUTE IMMEDIATE 'CREATE INDEX "BTCL_BTSE_CLNT_I" ON "BT_BTSE_CLNT" ("BTSE_BTSE_ID", "CLNT_CLNT_ID") compute statistics';
    
    EXECUTE IMMEDIATE 'CREATE INDEX "BTCL_CLNT_I" ON "BT_BTSE_CLNT" ("CLNT_CLNT_ID") compute statistics';
    EXECUTE IMMEDIATE 'CREATE INDEX "BTCL_ASSC_I" ON "BT_BTSE_CLNT" ("ASSC_ASSC_ID") compute statistics';
    EXECUTE IMMEDIATE 'CREATE INDEX "BTCL_RASSC_I" ON "BT_BTSE_CLNT" ("ROOT_ASSC_ID") compute statistics';
    
    EXECUTE IMMEDIATE 'alter table BT_BTSE_CLNT LOGGING';

    
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'',
                                  TABNAME => 'BT_BTSE_CLNT',
                                  ESTIMATE_PERCENT => 9,
                                  BLOCK_SAMPLE => TRUE,
                                  METHOD_OPT => 'FOR ALL INDEXED COLUMNS SIZE AUTO',
                                  GRANULARITY => 'ALL',
                                  CASCADE =>FALSE,
                                  DEGREE => G_PARALLEL);
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'',
                                  TABNAME => 'BT_SETS',
                                  ESTIMATE_PERCENT => 9,
                                  BLOCK_SAMPLE => TRUE,
                                  METHOD_OPT => 'FOR ALL INDEXED COLUMNS SIZE AUTO',
                                  GRANULARITY => 'ALL',
                                  CASCADE =>TRUE,
                                  DEGREE => G_PARALLEL);
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'',
                                  TABNAME => 'BT_STAGES',
                                  ESTIMATE_PERCENT => 9,
                                  BLOCK_SAMPLE => TRUE,
                                  METHOD_OPT => 'FOR ALL INDEXED COLUMNS SIZE AUTO',
                                  GRANULARITY => 'ALL',
                                  CASCADE =>TRUE,
                                  DEGREE => G_PARALLEL);
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'',
                                  TABNAME => 'BT_STATES',
                                  ESTIMATE_PERCENT => 9,
                                  BLOCK_SAMPLE => TRUE,
                                  METHOD_OPT => 'FOR ALL INDEXED COLUMNS SIZE AUTO',
                                  GRANULARITY => 'ALL',
                                  CASCADE =>TRUE,
                                  DEGREE => G_PARALLEL);
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'',
                                  TABNAME => 'BT_TASKS',
                                  ESTIMATE_PERCENT => 9,
                                  BLOCK_SAMPLE => TRUE,
                                  METHOD_OPT => 'FOR ALL INDEXED COLUMNS SIZE AUTO',
                                  GRANULARITY => 'ALL',
                                  CASCADE =>TRUE,
                                  DEGREE => G_PARALLEL);
  
    PACK_BILLING_TASK.SET_SESSION_PARALLEL_STATE(V_SAVED_SESSION_STATE);
  EXCEPTION
    WHEN OTHERS THEN
      PACK_BILLING_TASK.SET_SESSION_PARALLEL_STATE(V_SAVED_SESSION_STATE);
      RAISE;
  END;
  
END;



PROCEDURE BT_INIT(P_CHEK_STATE NUMBER DEFAULT 1) 
IS
BEGIN
  
  IF GET_QT_JOB_MASK('bt_bgi_job_%') + GET_QT_JOB_MASK('bt_bgi_run_job_init%') > 0 THEN 
    RAISE_ERROR(10281); 
  END IF;

  
  IF P_CHEK_STATE = 1 THEN
    FOR REC IN (SELECT 1
                  FROM DUAL
                 WHERE EXISTS(SELECT 1 FROM BT_SETS WHERE BTST_BTST_ID = GC_BTST_ERROR)
                    OR (EXISTS(SELECT 1 FROM BT_SETS WHERE BTST_BTST_ID = GC_BTST_WAITING_FOR_RUN) AND
                        EXISTS(SELECT 1 FROM BT_SETS WHERE BTST_BTST_ID <> GC_BTST_WAITING_FOR_RUN))
               ) LOOP
      RAISE_ERROR(10284); 
      EXIT;
    END LOOP;
  END IF;

  
  EXECUTE IMMEDIATE 'alter table BT_BTSE_CLNT NOLOGGING';
  
  

  BEGIN EXECUTE IMMEDIATE 'drop index BTCL_BTSE_CLNT_I'; EXCEPTION WHEN OTHERS THEN NULL; END;
  
  BEGIN EXECUTE IMMEDIATE 'drop index BTCL_CLNT_I'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'drop index BTCL_ASSC_I'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'drop index BTCL_RASSC_I'; EXCEPTION WHEN OTHERS THEN NULL; END;
  
  EXECUTE IMMEDIATE 'truncate table bt_btse_clnt';
  EXECUTE IMMEDIATE 'truncate table BT_SETS';
  EXECUTE IMMEDIATE 'truncate table bt_tasks';
  
  




  
  PACK_BILLING.CLEAN_TMP_TBLS(NULL);

  COMMIT;
END;



PROCEDURE BT_ROLLBACK(P_ID IN NUMBER, 
                      P_ROLLBACK_CALLS IN BOOLEAN DEFAULT TRUE 
                      )
IS
  V_ROLLBAK_BTST_ID BOOLEAN := FALSE;
  V_ASSC_ID NUMBER;
  V_BTSE_ID NUMBER;
  V_BLCL_ID NUMBER;
  V_LOG_ID NUMBER;
  V_NUM NUMBER;
BEGIN
  
  G_LOCK_ASSC_BTSE_ON := 1;

  
  
  IF GET_QT_JOB_MASK('bt_bgi_bt_job_%') + GET_QT_JOB_MASK('bt_bgi_run_job_init%') > 0 THEN
    RAISE_ERROR(10281); 
  END IF;

  
  FOR REC IN (
              SELECT B.ASSC_ASSC_ID, B.BTSE_ID, T.BLCL_BLCL_ID
                FROM BT_SETS B
                     INNER JOIN BT_TASKS T
                             ON T.BTTS_ID = B.BTTS_BTTS_ID
               WHERE B.ASSC_ASSC_ID = P_ID
                 AND ROWNUM < 2
              UNION ALL
              
              SELECT B.ASSC_ASSC_ID, B.BTSE_ID, T.BLCL_BLCL_ID
                FROM BT_SETS B
                     INNER JOIN BT_TASKS T
                             ON T.BTTS_ID = B.BTTS_BTTS_ID
               WHERE B.BTSE_ID = P_ID
             ) LOOP
    V_BLCL_ID := REC.BLCL_BLCL_ID;
    IF REC.ASSC_ASSC_ID = -1 THEN 
      V_ASSC_ID := REC.ASSC_ASSC_ID;
      V_BTSE_ID := REC.BTSE_ID;
    ELSIF REC.ASSC_ASSC_ID IS NOT NULL THEN 
      V_ASSC_ID := REC.ASSC_ASSC_ID;
    ELSE 
      V_BTSE_ID := REC.BTSE_ID;
    END IF;
    EXIT;
  END LOOP;

  IF NVL(V_BTSE_ID, V_ASSC_ID) IS NULL THEN

    RAISE_ERROR(10293); 
  END IF;

  V_LOG_ID := TO_SYS_LOG(P_MESSAGE => 'BT_BGI rollback_START');

  IF V_BTSE_ID IS NOT NULL THEN 
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI rollback_CLNT_CLUSTER: btse_id = '||V_BTSE_ID||' , blcl_id = '||V_BLCL_ID,
                        P_SLOG_ID => V_LOG_ID);

    IF V_ASSC_ID IS NULL THEN 
      PACK_BILLING.BILL_ROLLBACK_CLUSTER(IP_BTSE_ID => V_BTSE_ID,
                                         IP_BLCL_ID => V_BLCL_ID,
                                         IP_SLOG_ID => V_LOG_ID,
                                         IP_ROLLBACK_CALLS => P_ROLLBACK_CALLS 
                                         );
    ELSE 
      FOR REC IN (SELECT DISTINCT T.ROOT_ASSC_ID FROM BT_BTSE_CLNT T WHERE T.BTSE_BTSE_ID = V_BTSE_ID) LOOP
        PACK_BILLING.BILL_ROLLBACK_ONE_ASSC(P_ASSC_ID  => REC.ROOT_ASSC_ID,
                                            P_BLCL_ID  => V_BLCL_ID,
                                            IP_SLOG_ID => V_LOG_ID);
      END LOOP;
    END IF;

    


    IF P_ROLLBACK_CALLS THEN
      UPDATE BT_SETS B
         SET B.BTST_BTST_ID = GC_BTST_ROLLBACK_AND_AGGR_DEL
       WHERE B.BTSE_ID = V_BTSE_ID
         AND B.BTST_BTST_ID = GC_BTST_COMPLETED;
    ELSE
      UPDATE BT_SETS B
         SET B.BTST_BTST_ID = GC_BTST_ROLLBACK
       WHERE B.BTSE_ID = V_BTSE_ID
         AND B.BTST_BTST_ID = GC_BTST_COMPLETED;
    END IF;
    
  ELSE 
    V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI rollback_ASSC: assc_id = '||V_ASSC_ID||' , blcl_id = '||V_BLCL_ID,
                        P_SLOG_ID => V_LOG_ID);
    FOR REC IN (SELECT 
                       COUNT(CASE WHEN B.BTST_BTST_ID = 1 THEN 1 END) OVER() IS_BTST_1,
                       COUNT(CASE WHEN B.BTST_BTST_ID = 2 THEN 1 END) OVER() IS_BTST_2,
                       COUNT(CASE WHEN B.BTST_BTST_ID = 3 THEN 1 END) OVER() IS_BTST_3,
                       COUNT(CASE WHEN B.BTST_BTST_ID = 4 THEN 1 END) OVER() IS_BTST_4,
                       B.*
                  FROM BT_SETS B
                 WHERE B.ASSC_ASSC_ID = V_ASSC_ID
                 ORDER BY B.BTSG_BTSG_ID DESC 
               ) LOOP

      IF REC.IS_BTST_1>0 AND REC.IS_BTST_2=0 AND REC.IS_BTST_3=0 AND REC.IS_BTST_4=0 THEN 
        
        PACK_BILLING.BILL_ROLLBACK_ONE_ASSC(P_ASSC_ID  => V_ASSC_ID,
                                            P_BLCL_ID  => V_BLCL_ID,
                                            IP_SLOG_ID => V_LOG_ID);
        EXIT; 
      ELSIF REC.IS_BTST_3>0 AND REC.IS_BTST_2=0 AND REC.IS_BTST_1=0 AND REC.IS_BTST_4=0 THEN 
        
        PACK_BILLING.BILL_ROLLBACK_ONE_ASSC(P_ASSC_ID  => V_ASSC_ID,
                                            P_BLCL_ID  => V_BLCL_ID,
                                            IP_SLOG_ID => V_LOG_ID);
        V_ROLLBAK_BTST_ID := TRUE;
        EXIT; 
      ELSE 
        
        PACK_BILLING.BILL_ROLLBACK_CLUSTER(IP_BTSE_ID => REC.BTSE_ID,
                                           IP_BLCL_ID => V_BLCL_ID,
                                           IP_ASSC_ID => V_ASSC_ID,
                                           IP_SLOG_ID => V_LOG_ID);
        V_ROLLBAK_BTST_ID := TRUE;
      END IF;
    END LOOP;

    
    IF V_ROLLBAK_BTST_ID THEN
      UPDATE BT_SETS B
         SET B.BTST_BTST_ID = 1,
             B.BTSG_BTSG_ID = CASE WHEN B.BTSG_BTSG_ID IN (0, 5) THEN B.BTSG_BTSG_ID
                              ELSE 2
                              END
       WHERE B.ASSC_ASSC_ID = V_ASSC_ID
         AND B.BTST_BTST_ID > 1;
    END IF;
  END IF;

  COMMIT;

  V_NUM := TO_SYS_LOG(P_MESSAGE => 'BT_BGI rollback_END',
                      P_SLOG_ID => V_LOG_ID);

  
  G_LOCK_ASSC_BTSE_ON := 0;
EXCEPTION
  WHEN OTHERS THEN
    
    G_LOCK_ASSC_BTSE_ON := 0;
    RAISE;
END;






PROCEDURE BT_LOCK_ASSC(P_OPER    IN NUMBER, 

                       P_ASSC_ID IN NUMBER,
                       P_BLCL_ID IN NUMBER,
                       P_BTSE_ID IN NUMBER DEFAULT NULL
                      )
IS
BEGIN
  
  
  





  
  IF P_BTSE_ID IS NOT NULL AND G_LOCK_ASSC_BTSE_ON = 0 THEN

    RAISE_ERROR(10294); 
  END IF;

  RETURN;
END;




PROCEDURE BT_UNLOCK_ASSC(P_OPER    IN NUMBER, 
                         P_ASSC_ID IN NUMBER,
                         P_BLCL_ID IN NUMBER,
                         P_TYPE    IN NUMBER DEFAULT 1,     
                         P_BTSE_ID IN NUMBER DEFAULT NULL
                        )
IS
BEGIN
  
  IF P_BTSE_ID IS NOT NULL AND G_LOCK_ASSC_BTSE_ON = 0 THEN

    RAISE_ERROR(10294); 
  END IF;

  RETURN;
END;



PROCEDURE INIT_START_BGI_PROCESS(P_BTTS_ID VARCHAR2 DEFAULT NULL 
                                  ) AS
BEGIN
  
  DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => 'bt_bgi_start_bgi_proccess',
                            JOB_TYPE   => 'PLSQL_BLOCK',
                            JOB_ACTION => 'BEGIN PACK_BILLING_TASK_BGI.start_bgi_proccess(' ||
                                          P_BTTS_ID || '); END;',
                            ENABLED    => TRUE,
                            AUTO_DROP  => TRUE,
                            JOB_CLASS  => G_BFAM_BILL_JOB_CLASS 
                            );
END INIT_START_BGI_PROCESS;

PROCEDURE START_BGI_PROCCESS(P_BTTS_ID VARCHAR2 DEFAULT NULL 
                             
                            ,P_START_PROCESS_AFTER_QUEUE IN NUMBER DEFAULT 1
                             )
IS
  V_BTTS_SRC_ARR DBMS_SQL.NUMBER_TABLE; 
  V_BTSE_ARR     DBMS_SQL.NUMBER_TABLE;
  V_INTERRUPT_BTSE_ARR DBMS_SQL.NUMBER_TABLE; 
  V_PRIORITY_ARR DBMS_SQL.NUMBER_TABLE;
  V_BILL_PERIOD  DATE;
  
  V_MIN_BILL_PERIOD DATE;
  V_MAX_BILL_PERIOD DATE;
  
  V_PRIORITY     NUMBER;
  V_BTTS_SRC     NUMBER; 
  
  PROCEDURE CREATE_RQ(P_BTSE_ID IN NUMBER,   
                      P_BILL_PERIOD IN DATE, 
                      P_PRIORITY IN NUMBER,  
                      P_BGIRQ_TYPE IN NUMBER DEFAULT 1 
                     )
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    V_CLNT_ARR DBMS_SQL.NUMBER_TABLE; 
    V_JSON_CLOB CLOB;
    V_RQ_ID NUMBER := BGIRQ_SEQ.NEXTVAL; 
    V_MOD_CLNT NUMBER;
    V_HOME_MACR_ID NUMBER; 
  BEGIN
    
    SELECT T.MACR_MACR_ID INTO V_HOME_MACR_ID FROM BT_SETS T WHERE T.BTSE_ID = P_BTSE_ID;
    
    
    SELECT T.MOD_CLNT INTO V_MOD_CLNT
      FROM BFAM_CLNT_PARTITIONS T
     WHERE T.CLNT_CLNT_ID = (SELECT CLNT_CLNT_ID FROM BT_BTSE_CLNT WHERE BTSE_BTSE_ID = P_BTSE_ID AND ROWNUM < 2);

    
    SELECT T.CLNT_CLNT_ID
      BULK COLLECT INTO V_CLNT_ARR
      FROM BT_BTSE_CLNT T
            LEFT JOIN BGI_REQ_DONE B
                   ON B.MOD_CLNT = V_MOD_CLNT AND
                      B.CLNT_CLNT_ID = T.CLNT_CLNT_ID AND
                      B.MONTH_BILL = P_BILL_PERIOD AND
                      
                      B.BGIRQ_TYPE = 1
     WHERE T.BTSE_BTSE_ID = P_BTSE_ID
       AND B.BGIRQ_BGIRQ_ID IS NULL; 


    IF V_CLNT_ARR.COUNT > 0 THEN  
      
      BGI_RQ_PG.PREPARE_JSON_CLOB(P_RQ_ID         => V_RQ_ID,        
                                  P_MOD_CLNT      => V_MOD_CLNT,
                                  P_BILLPERIOD    => P_BILL_PERIOD,  
                                  P_BILLMONTH     => 1,              
                                  P_LIST_CLNT_ARR => V_CLNT_ARR,     
                                  P_JSON_CLOB     => V_JSON_CLOB,    
                                  P_HOME_MACR_ID  => NVL(V_HOME_MACR_ID, 0) 
                                 );

      INSERT INTO BGI_REQ_QUEUE(BGIRQ_ID, BILLING_REQUIRED, PRIORITY, MOD_CLNT, BGIRQ_TYPE, MONTH_BILL, REQ_BODY)
        VALUES(V_RQ_ID, 'Y', P_PRIORITY, V_MOD_CLNT, P_BGIRQ_TYPE, P_BILL_PERIOD, V_JSON_CLOB);
    END IF;
    
    

    UPDATE BT_SETS T
       SET T.BGIRQ_BGIRQ_ID = V_RQ_ID,
           T.BTST_BTST_ID = GC_BTST_REQUESTING_GUS_AGGR
     WHERE T.BTSE_ID = P_BTSE_ID;

    COMMIT;


    IF V_CLNT_ARR.COUNT > 0 THEN
      
      IF NOT(P_START_PROCESS_AFTER_QUEUE = 1) THEN
      
        
        BFAM_SERVICES_PG.SEND_SERVICE_MSG(P_SERV_NAME => BGI_RQ_PG.GV_AGGR_SRV_NAME, 
                                          P_OPER_NAME => 'bgi_send_rq' 
                                         );
      END IF;
    ELSE
      
      RUN_BGI_BILLING(V_RQ_ID);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;

  
  PROCEDURE RESUME_RQ(P_BTSE_ID     IN NUMBER, 
                      P_BILL_PERIOD IN DATE 
                      ) AS
    V_CLNT_ARR DBMS_SQL.NUMBER_TABLE; 
    V_RQ_ID    NUMBER; 
    V_MOD_CLNT NUMBER;
  BEGIN
    
    SELECT BTSE.BGIRQ_BGIRQ_ID
      INTO V_RQ_ID
      FROM BT_SETS BTSE
     WHERE BTSE.BTSE_ID = P_BTSE_ID;

    
    SELECT T.MOD_CLNT
      INTO V_MOD_CLNT
      FROM BFAM_CLNT_PARTITIONS T
     WHERE T.CLNT_CLNT_ID = (SELECT CLNT_CLNT_ID
                               FROM BT_BTSE_CLNT
                              WHERE BTSE_BTSE_ID = P_BTSE_ID
                                    AND ROWNUM < 2);

    
    SELECT T.CLNT_CLNT_ID
      BULK COLLECT
      INTO V_CLNT_ARR
      FROM BT_BTSE_CLNT T
      JOIN BGI_REQ_DONE B
        ON B.MOD_CLNT = V_MOD_CLNT
           AND B.CLNT_CLNT_ID = T.CLNT_CLNT_ID
           AND B.MONTH_BILL = P_BILL_PERIOD
           AND B.BGIRQ_TYPE = 1 
     WHERE T.BTSE_BTSE_ID = P_BTSE_ID
           AND B.BGIRQ_BGIRQ_ID = V_RQ_ID; 

    IF V_CLNT_ARR.COUNT = 0
    THEN
      
      BFAM_SERVICES_PG.SEND_SERVICE_MSG(P_SERV_NAME => BGI_RQ_PG.GV_AGGR_SRV_NAME, 
                                        P_OPER_NAME => 'bgi_send_rq' 
                                        );
    ELSE
      
      RUN_BGI_BILLING(V_RQ_ID);
    END IF;
  END RESUME_RQ;
  
BEGIN
  
  
  
  

  
  IF BFAM_SERVICES_PG.CHECK_STOP(BGI_RQ_PG.GV_RQ_SRV_NAME) <> 0
  THEN
    BFAM_SERVICES_PG.START_SERVICE(BGI_RQ_PG.GV_RQ_SRV_NAME);
  END IF;

  
  
  IF P_BTTS_ID IS NOT NULL THEN
    
    SELECT T.PRIORITY, TRUNC(T.BILL_DATE, 'mm'), T.BTTS_SRC
      INTO V_PRIORITY, V_BILL_PERIOD, V_BTTS_SRC
      FROM BT_TASKS T
     WHERE T.BTTS_ID = P_BTTS_ID;

    
    
    SELECT T.BTSE_ID BULK COLLECT INTO V_BTSE_ARR
      FROM BT_SETS T
     WHERE T.BGIRQ_BGIRQ_ID IS NULL
       AND T.BTSG_BTSG_ID IN (0, 2)
       AND T.BTTS_BTTS_ID = P_BTTS_ID;

    
    
    SELECT T.BTSE_ID BULK COLLECT INTO V_INTERRUPT_BTSE_ARR
      FROM BT_SETS T
     WHERE T.BGIRQ_BGIRQ_ID IS NOT NULL
       AND T.BTSG_BTSG_ID IN (0, 2)
       AND T.BTTS_BTTS_ID = P_BTTS_ID
       AND T.BTST_BTST_ID NOT IN (3)
       AND EXISTS (SELECT 1 FROM BT_BTSE_CLNT C WHERE C.BTSE_BTSE_ID = T.BTSE_ID);
  ELSE
    
    

    SELECT MIN(T.BILL_DATE) INTO V_MIN_BILL_PERIOD FROM BT_TASKS T;
    SELECT MAX(T.BILL_DATE) INTO V_MAX_BILL_PERIOD FROM BT_TASKS T;
    IF V_MIN_BILL_PERIOD <> V_MAX_BILL_PERIOD THEN RAISE_ERROR(10415);
    ELSE V_BILL_PERIOD := V_MIN_BILL_PERIOD;
      SELECT TRUNC(T.BILL_DATE, 'mm')
        INTO V_BILL_PERIOD
        FROM BT_TASKS T
       WHERE ROWNUM < 2;
       

      
      
      SELECT S.BTSE_ID, T.PRIORITY, T.BTTS_SRC
        BULK COLLECT INTO V_BTSE_ARR, V_PRIORITY_ARR, V_BTTS_SRC_ARR
        FROM BT_SETS S, BT_TASKS T
       WHERE S.BGIRQ_BGIRQ_ID IS NULL
         AND S.BTSG_BTSG_ID IN (0, 2)
         AND T.BTTS_ID = S.BTTS_BTTS_ID;

      
      
      SELECT S.BTSE_ID
        BULK COLLECT INTO V_INTERRUPT_BTSE_ARR
        FROM BT_SETS S, BT_TASKS T
       WHERE S.BGIRQ_BGIRQ_ID IS NOT NULL
         AND S.BTSG_BTSG_ID IN (0, 2)
         AND T.BTTS_ID = S.BTTS_BTTS_ID
         AND S.BTST_BTST_ID NOT IN (3)
         AND EXISTS (SELECT 1 FROM BT_BTSE_CLNT C WHERE C.BTSE_BTSE_ID = S.BTSE_ID);
    END IF;
  END IF;

  
  
  IF P_START_PROCESS_AFTER_QUEUE = 1 THEN
    
    BFAM_SERVICES_PG.STOP_SERVICE(P_SERV_NAME => BGI_RQ_PG.GV_AGGR_SRV_NAME); 
  END IF;
  

  
  FOR J IN 1..V_INTERRUPT_BTSE_ARR.COUNT LOOP
    
    IF BFAM_SERVICES_PG.CHECK_STOP(BGI_RQ_PG.GV_RQ_SRV_NAME) = 0 THEN
      RESUME_RQ(P_BTSE_ID => V_INTERRUPT_BTSE_ARR(J), P_BILL_PERIOD => V_BILL_PERIOD); 
    END IF;
  END LOOP;
  

  
  FOR I IN 1..V_BTSE_ARR.COUNT LOOP
    IF P_BTTS_ID IS NULL THEN
      V_PRIORITY := V_PRIORITY_ARR(I);
      V_BTTS_SRC := V_BTTS_SRC_ARR(I); 
    END IF;
    
    IF BFAM_SERVICES_PG.CHECK_STOP(BGI_RQ_PG.GV_RQ_SRV_NAME) = 0 THEN
      CREATE_RQ(P_BTSE_ID     => V_BTSE_ARR(I),
                P_BILL_PERIOD => V_BILL_PERIOD,
                P_PRIORITY    => V_PRIORITY,
                P_BGIRQ_TYPE  => CASE WHEN V_BTTS_SRC = 3 THEN 3 ELSE 1 END 
                                                                            
               );
    END IF;
  END LOOP;

  
  IF P_START_PROCESS_AFTER_QUEUE = 1 THEN
    
    BFAM_SERVICES_PG.START_SERVICE(P_SERV_NAME => BGI_RQ_PG.GV_AGGR_SRV_NAME); 
    
    BFAM_SERVICES_PG.SEND_SERVICE_MSG(P_SERV_NAME => BGI_RQ_PG.GV_AGGR_SRV_NAME, 
                                      P_OPER_NAME => 'bgi_send_rq' 
                                     );
  END IF;
  
END;


PROCEDURE RUN_BGI_BILLING(P_BGIRQ_ID NUMBER) 
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  
  




  UPDATE BT_SETS T
     SET T.BTST_BTST_ID = GC_BTST_READY_FOR_BILLING
   WHERE T.BGIRQ_BGIRQ_ID = P_BGIRQ_ID;

  COMMIT;

  
  RUN_JOB_INIT(P_BTTS_ID => NULL); 
END;

BEGIN
  INIT_PARAMS;
END PACK_BILLING_TASK_BGI;
