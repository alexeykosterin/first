select s.clnt_clnt_id,
bd.bvdh_id, 
bb.bvdt_bvdt_id, 
ch.subs_subs_id,
b.bvtv_bvtv_id, 
--(case  when end) as DETG_P,
b.* from bill_details b 
join charges ch on ch.bill_bill_id = b.bill_bill_id
join subscribers s on ch.subs_subs_id = subs_id
join bvd_clnt_bvdt bb on bb.clnt_clnt_id = s.clnt_clnt_id
join bvd_discount_table_histories bd on bd.bvdt_bvdt_id = bb.bvdt_bvdt_id
join bvd_bvdh_detg bg on bg.bvdh_bvdh_id = bd.bvdh_id
where b.bill_bill_id in (select tt.bill_bill_id from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where 1=1--clnt_clnt_id in (select t.clnt_clnt_id from bvd_clnt_bvdt t where navi_user like 'PS_MIGR173')
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
and t.navi_user like 'PS_MIGR173'
--and b.bill_bill_id =190601779840401
)
and ch.amount_$ = b.amount_$_orig
and b.detg_detg_id = bg.detg_detg_id



select * From charges where bill_bill_id = 190601779840401


select * from bills

select * from subscribers where subs_id = 7185280
select * from bvd_clnt_bvdt where clnt_clnt_id = 398451
select * from bvd_bvvd_detg where bvvd_bvvd_id = 1
select * from Bvd_Discount_Tables where bvdt_id = 16
select * from bvd_values_descs
select * from bvd_discount_table_values where bvdh_bvdh_id = 68
select * from bvd_discount_table_histories where bvdt_bvdt_id = 16

select * from bvd_bvdh_detg where bvdh_bvdh_id = 68
and detg_detg_id in (61994,
65821
)



begin
  SIB_EASR;
  end;

select * from bvd_discount_tables bdt where bvdt_id = 16
where name like '������ 10%  �� ������ ��������';
