declare
p_column_name varchar2(20) := 'RTPL_ID'; ---column_name �� �������� ������� �����������
p_id number(10) := 112; ---ID ���������� ������ column_name
sql_qry varchar2(600);
emp_count number(10);

begin
  
for rec in (select distinct t.table_name as forSelect1, COLUMN_NAME as forSelect2 From USER_CONSTRAINTS t
inner join USER_CONS_COLUMNS tt on tt.table_name = t.table_name
where t.constraint_type = 'P'
and tt.column_name like '%'||p_column_name||'%'
) 

loop

sql_qry:= 'select count(1) from '||rec.forselect1||' where '||rec.forselect2||' = '||p_id;
EXECUTE IMMEDIATE sql_qry INTO emp_count;

if emp_count > 0 then

execute immediate 
      '
      declare
      p_table_col clob;
      v_c clob;
      begin 
      select LISTAGG(column_name, '', '') WITHIN GROUP (order by column_id) as list into p_table_col from user_tab_columns t where table_name = :1 group by table_name;
      
      dbms_output.put_line(''select ''||p_table_col||'' from ''||:1||'' where ''||:2||''=''||:3||'';'');
      
      
      --select count(1) into v_c from '||rec.forselect1||' where '||rec.forselect2||' = '||p_id||';
      --dbms_output.put_line(v_c);
      
      end;' 
using rec.forselect1,rec.forselect2,p_id;

end if;

end loop;
end;







insert into akk_packs1 (pack_id, rtpl_rtpl_id, name_e, name_r, expire_date, navi_user, navi_date, ptyp_ptyp_id, avail_date, duration_limit_date, duration_months, duration_days, poty_poty_id, pcct_pcct_id, switch_pack_id, pack_code, recurring_flag, check_rtpl_charge, is_legacy)
select * from :1;



create table test_forall_dyn (val varchar2(1));

declare
  type tab_char is table of varchar2(1) index by binary_integer;
  t_char tab_char;
begin
  for i in 1..26 loop
    t_char(i) := chr(64 + i);
  end loop;
  forall i in 1..26
    execute immediate 
      'begin 
         insert into test_forall_dyn (val) values(:1);  
         insert into test_forall_dyn (val) values(:1); 
         dbms_output.put_line(1);
       end;' 
       using t_char(i);
      -- dbms_output.put_line
end;
/

select * from test_forall_dyn;




