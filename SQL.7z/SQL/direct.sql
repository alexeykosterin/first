create table aak_for1
(name_pack varchar2(300), name_city varchar2(300),code_id number(10),name_country varchar2(300),zone_id number(10),avt_price number(10,5), zak_price number(10,5),pack_id number(10))



select * from aak_for1 

where name_country not like '%�� %'
--for update

select distinct pack_id, NAME_COUNTRY, avt_price, zak_price from aak_for1 


select count(1),pack_id, zak_price, avt_price,NAME_COUNTRY from aak_for1 
group by pack_id, zak_price, avt_price,NAME_COUNTRY

select distinct pack_id, zak_price, avt_price,NAME_COUNTRY from aak_for1 where pack_id = 299 and name_country like '%�������%'
select * from aak_for1 where pack_id = 299 and name_country like '%�������%'



select * from directions where name_r like '%�������%'
select * from pset_directions
select * from Rate_Plan_Directions




select distinct pack_id, NAME_COUNTRY, avt_price, zak_price from aak_for1 



select regexp_replace(regexp_replace('9_��� �� �������� (�����)', ('[+.,()-]*'), ''),'9_��� �� |�����|�������','') from dual;

select regexp_replace(regexp_replace('9_��� �� ��������', ('[+.,()-]*'), ''),'9_��� �� |�����|�������','') from dual;


create table aak_for2 as
select distinct pack_id, 
(case when NAME_COUNTRY like '%���%' and NAME_COUNTRY not like '%�����%' then regexp_replace(regexp_replace(NAME_COUNTRY, ('[+,-]*'), ''),'9_��� �� |9_��� �� |��� �� ','')
when NAME_COUNTRY like '%�����%' then regexp_replace(regexp_replace(NAME_COUNTRY, ('[+.,()-]*'), ''),'9_��� �� |9_��� �� |��� �� |�����|�������','')||'DEF'
end) as NAME_COUNTRY
, avt_price, zak_price from aak_for1 

select regexp_replace(regexp_replace('����������� (�����.)', ('[+.,()-]*'), ''),'�����|�������','')||' DEF' from dual

select distinct NAME_COUNTRY from aak_for2
select distinct name_r from directions 
select distinct * from directions 
select name_r from directions where name_r like '%DEF%'

update directions set name_r = regexp_replace(regexp_replace(name_r, ('[+.,()-]*'), ''),'�����|�������','')||'DEF' where name_r like '%�����%'

select distinct regexp_replace(regexp_replace(name_r, ('[+.,()-]*'), ''),'�����|�������','')||'DEF' from directions where name_r like '%�����%'
select * from directions where name_r like '%DEF%' for update



delete from directions t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by NAME_R) as min_rw
from directions
) where rw <> min_rw)



select rw from (select rowid as rw,
min(rowid) over(partition by NAME_R) as min_rw
from directions s
) where rw <> min_rw

select * from directions where rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by NAME_R) as min_rw
from directions s
) where rw <> min_rw
)



select * from directions where name_r like '%��������%'


select distinct NAME_COUNTRY from aak_for2
select distinct name_r from directions 
select distinct * from directions 
select name_r from directions where name_r like '%DEF%'


select distinct NAME_COUNTRY from aak_for2
join 

select distinct dd.drct_id, pack_id, NAME_COUNTRY, AVT_PRICE, ZAK_PRICE
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))


select distinct name_country from aak_for2 where rowid not in  (select pp.rowid
from aak_for2 pp
join directions on lower(NAME_COUNTRY) like (lower(name_r)))

select distinct dd.drct_id, NAME_COUNTRY
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))


select * from aak_for2
where NAME_COUNTRY like '������'


------------------
begin
for rec in (select distinct dd.drct_id, NAME_COUNTRY, pack_id
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))) loop
insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
select rpdr_seq.nextval, 0, 0, translit(rec.name_country), rec.name_country, rec.drct_id, null, 'AAK', trunc(sysdate), 1, rec.pack_id, null from dual;
end loop;
end;
-----------------



select * from prefix_sets where drct_drct_id = 4141

select distinct *
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))

select * from trafics_by_directions 
where rpdr_rpdr_id = 31276
select * from pset_directions
select * from rate_plan_directions where navi_date = trunc(sysdate)



select * from prefix_sets


select distinct dd.drct_id, d.name_country
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))
where dd.drct_id not in (select distinct drct_drct_id from prefix_sets)

select distinct drct_id from directions 
inner join prefix_sets on drct_id = drct_drct_id


---��������� ��� ���������
SELECT distinct drct_id, name_r FROM directions
LEFT OUTER JOIN prefix_sets ps ON drct_id = drct_drct_id
WHERE drct_drct_id is NULL

---��������� � ����������
SELECT distinct drct_id, name_r FROM directions
INNER JOIN prefix_sets ps ON drct_id = drct_drct_id

456
371
827

select * from countries where lower(name_r) like '%�����%'
select * from prefix_sets where cou_cou_id = 107
select * from directions where drct_id = 1009



select * from aak_for3 ak
join countries c on c.name_r like ak.name_r

----3162
select distinct ak.* from aak_for4 ak where rowid not in  (select pp.rowid
from aak_for4 pp
join countries p on lower(pp.name_country) like (lower(p.name_r)))

---6645
select *
from aak_for4 pp
join countries p on lower(pp.name_country) like (lower(p.name_r))


/*create table aak_for4 as
select distinct dd.drct_id, NAME_COUNTRY, pack_id,AVT_PRICE, ZAK_PRICE
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))*/


select * from countries where lower(name_r) like '%����%'
select * from prefix_sets where cou_cou_id = 205
select * from directions where drct_id = 1005


-------
select distinct d.drct_id,d.name_r,cc.name_r, cou_id,cou_code, ps.drct_drct_id,dr.name_r from directions d 
join countries cc on lower(cc.name_r) like lower(d.name_r)
join prefix_sets ps on cou_cou_id = cou_id
join directions dr on dr.drct_id = ps.drct_drct_id
where d.drct_id in (
select distinct dd.drct_id
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))
where drct_id in (SELECT distinct drct_id FROM directions
LEFT OUTER JOIN prefix_sets ps ON drct_id = drct_drct_id
WHERE drct_drct_id is NULL))
and d.name_r not like '%DEF%'


-------
select * from prefix_sets where cou_cou_id in (select cou_id from directions d 
join countries cc on lower(cc.name_r) like lower(d.name_r)
where drct_id in (
select distinct dd.drct_id
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))
where drct_id in (SELECT distinct drct_id FROM directions
LEFT OUTER JOIN prefix_sets ps ON drct_id = drct_drct_id
WHERE drct_drct_id is NULL))
and d.name_r not like '%DEF%')




create table cou_drct as
select distinct d.drct_id,d.name_r,cc.name_r as name_r1, cou_id,cou_code, ps.drct_drct_id,dr.name_r as name_r2 from directions d 
join countries cc on lower(cc.name_r) like lower(d.name_r)
join prefix_sets ps on cou_cou_id = cou_id
join directions dr on dr.drct_id = ps.drct_drct_id
where d.drct_id in (
select distinct dd.drct_id
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r))
where drct_id in (SELECT distinct drct_id FROM directions
LEFT OUTER JOIN prefix_sets ps ON drct_id = drct_drct_id
WHERE drct_drct_id is NULL))
and d.name_r not like '%DEF%'




select * from cou_drct;

SELECT distinct drct_id, name_r FROM directions
LEFT OUTER JOIN prefix_sets ps ON drct_id = drct_drct_id
WHERE drct_drct_id is NULL;



select * from aak_for4 where drct_id


----22 DRCT ������ � prefix_sets
SELECT distinct drct_id
FROM aak_for4 p
INNER JOIN prefix_sets ps ON ps.drct_drct_id = p.drct_id

----180 DRCT_ID �� ������ � prefix_sets, ������������� �� COU_ID
SELECT distinct drct_id
FROM aak_for4 p
LEFT OUTER JOIN prefix_sets ps ON ps.drct_drct_id = p.drct_id
WHERE ps.drct_drct_id is NULL

----119 ��������� � cou_id
select distinct drct_id from cou_drct where drct_id in (SELECT distinct drct_id
FROM aak_for4 p
LEFT OUTER JOIN prefix_sets ps ON ps.drct_drct_id = p.drct_id
WHERE ps.drct_drct_id is NULL)

----61 ��������� � cou_id � ������ ��������
SELECT distinct drct_id
FROM aak_for4 p
LEFT OUTER JOIN prefix_sets ps ON ps.drct_drct_id = p.drct_id
WHERE ps.drct_drct_id is NULL
and drct_id not in (select distinct drct_id from cou_drct)


/*------------����
select * from directions where drct_id in (SELECT distinct drct_id
FROM aak_for4 p
LEFT OUTER JOIN prefix_sets ps ON ps.drct_drct_id = p.drct_id
WHERE ps.drct_drct_id is NULL
and drct_id not in (select distinct drct_id from cou_drct))*/


select * from trafics_by_directions where pack_pack_id = 3795
select * from rate_plan_directions  where pack_pack_id = 3795
select * from pset_directions where rpdr_rpdr_id in (select rpdr_id from rate_plan_directions  where pack_pack_id = 3795)

--create table aak_for5 as
select distinct * from cou_drct where drct_id in (SELECT distinct drct_id
FROM aak_for4 p
LEFT OUTER JOIN prefix_sets ps ON ps.drct_drct_id = p.drct_id
WHERE ps.drct_drct_id is NULL);

--create table aak_for6 as
select distinct dd.drct_id, NAME_COUNTRY, pack_id
from aak_for2 d
join directions dd on lower(NAME_COUNTRY) like (lower(name_r));

select * from aak_for5;
select * from aak_for6;
select * from aak_for7;

create table aak_for7 as
select tt.*, t.pack_id, t.name_country, t.drct_id as drct_id2 from aak_for5 tt 
join aak_for6 t on t.drct_id = tt.drct_id

select distinct * from aak_for7 t 
join prefix_sets tt on tt.cou_cou_id = t.cou_id

select distinct t.DRCT_DRCT_ID,pset_id,COU_COU_ID,t.pack_id from aak_for7 t 
join prefix_sets tt on tt.cou_cou_id = t.cou_id


select * from pset_directions


select * from cou_drct where drct_id = 2290;
select * from prefix_sets where drct_drct_id = 2290
or cou_cou_id = 98

select * from cou_drct where drct_id = 1004;
select * from prefix_sets where drct_drct_id = 1004
or cou_cou_id = 98

select * From rate_plan_directions where navi_date = trunc(sysdate)


declare
v_cnt1 number(30);
v_cnt2 number(30);
v_cnt3 number(30);
begin
  for rec in (select * From rate_plan_directions where navi_date = trunc(sysdate)) loop
  select count(pset_id) into v_cnt1 from prefix_sets where drct_drct_id = rec.name_1;
    
    
    if v_cnt1 = 0 then
      select count(cou_id) into v_cnt2 from cou_drct where drct_id = rec.name_1;
      
      
      
      if v_cnt2 = 0 then
        dbms_output.put_line(rec.rpdr_id||' �� ������ �� pset_id �� cou_id');
      end if;
      if v_cnt2 > 0 then
        select distinct cou_id into v_cnt3 from cou_drct where drct_id = rec.name_1;
        for rec2 in (select * from prefix_sets where cou_cou_id = v_cnt3) loop
          
        
          insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
          select psdr_seq.nextval, 1, rec2.pset_id, rec.rpdr_id, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), null, null from dual;
      end loop;
      end if;

    end if;
    
    if v_cnt1 > 0 then
          insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
          select psdr_seq.nextval, 1, null, rec.rpdr_id, to_date('01.01.2018','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), rec.name_1, null from dual;
    end if;
  end loop;
end;








select * From rate_plan_directions where navi_date = trunc(sysdate)
select * from pset_directions where navi_date = trunc(sysdate)
select * from trafics_by_directions where navi_date = trunc(sysdate)


select count(1) from trafics_by_directions where navi_date = trunc(sysdate)



select * from trafics_by_directions where rpdr_rpdr_id in (select rpdr_id From rate_plan_directions where pack_pack_id = 3795)
and rpdr_rpdr_id = 31386

begin
  for rec4 in (select * from serv_lists where srls_id in (104,105)) loop
  for rec3 in (select * from logic_calls where lcal_id in (5,9)) loop
  for rec2 in (select * from time_classes where tmcl_id in (82,83)) loop
  for rec in (select * from aak_for9 where rpdr_id in (select rpdr_rpdr_id from pset_directions where navi_date = trunc(sysdate) and pset_pset_id is null)) loop
    if rec4.srls_id = 104 then
    insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select
rec2.tmcl_id, 1, rec.avt_price, 2, rec.name_1, rec.rpdr_id, null, to_date('31.12.1990','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 
1, 1, rec3.lcal_id, 0, 'Y', null, null, rec4.srls_id, 0, null, null, null, null, null, rec.pack_pack_id, null, 0, null, 60899, 100100, null, 228
from dual;
end if;
if rec4.srls_id = 105 then
    insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, add_drct_id, add_rpdr_id, pack_pack_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
select
rec2.tmcl_id, 1, rec.zak_price, 2, rec.name_1, rec.rpdr_id, null, to_date('31.12.1990','dd.mm.yyyy'), to_date('31.12.2999','dd.mm.yyyy'), 'AAK', trunc(sysdate), 
1, 1, rec3.lcal_id, 0, 'Y', null, null, rec4.srls_id, 0, null, null, null, null, null, rec.pack_pack_id, null, 0, null, 60899, 100100, null, 228
from dual;
end if;
end loop;
end loop;
end loop;
  end loop;
end;


select * from trafics_by_directions where navi_date = trunc(sysdate)

select * from trafics_by_directions where navi_date = trunc(sysdate)
and pack_pack_id != 0 


select * from serv_lists where srls_id in (104,105)



select * from pset_directions where navi_date = trunc(sysdate) and pset_pset_id is not null

select * from aak_for9

create table aak_for9 as
select distinct rpd.*, ak.avt_price,ak.zak_price From rate_plan_directions rpd 
join aak_for8 ak on ak.drct_id = rpd.name_1
where rpd.navi_date = trunc(sysdate)



select * from rate_plan_directions rpd 
where rpd.navi_date = trunc(sysdate)



select * from aak_for8
select * from aak_for9
select count(1) from aak_for9
create table aak_for9 as
select rpd.*, ak.avt_price,ak.zak_price from rate_plan_directions rpd, aak_for8 ak
where ak.drct_id = rpd.name_1
--and rpd.name_1 = 2285
and rpd.pack_pack_id = ak.pack_id


select * from aak_for8 where drct_id = 2285

select * from rate_plan_directions rpd 
where rpd.navi_date = trunc(sysdate) and name_1 = '2285'


select * from pset_directions where navi_date = trunc(sysdate) and pset_pset_id is not null

select * from aak_for9 where rpdr_id not in (select rpdr_rpdr_id from pset_directions where navi_date = trunc(sysdate))
select * from aak_for9 where rpdr_id in (select rpdr_rpdr_id from pset_directions where navi_date = trunc(sysdate) and pset_pset_id is null)
5916
1046
-----2845
9807


select * from trafics_by_directions where pack_pack_id in (475)
select * from rate_plan_directions where navi_date = trunc(sysdate)
select * from aak_for2 where pack_id = 475






