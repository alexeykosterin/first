select * from discount_predicate_links_view


create or replace view aak_discount_predicate_links_v as


select * from scaled_price
select * from scaled_price_parts
for update


select
       lpad(' ', (decode(c_prior,6,lv-1,
           4,lv-1,
           lv) - 1) * 5) ||
       case
         when dclt_id = 3 then 'and '
         when dclt_id = 4 then 'or '
         when dclt_id = 2 then 'else if '
         when dclt_id = 1 then 'then if '
         when dclt_id = 5 and tree.dpre_id like 'CLR%' then 'and call ('''
         when dclt_id = 5 and tree.dpre_id like 'CLT%' then 'and call_tree ('''
       end ||
       case lv when 2 then 'if ' else '' end ||
       case inverse_yn when 'Y' then 'not ' else '' end ||
       case when level_diff=-1 and lv <> 1 then '( ' else '' end ||
       tree.predicate ||
       case when dclt_id = 5 then ''')' else '' end ||
       case
          when level_diff>0 and c_prior not in (4,6)
             then rpad(' ', level_diff*2+1,' )')
          else ''
       end pred_links, level_diff,lv,c_prior,
       dth.dtre_dtre_id as dtre_id,
       tree.dtrh_id,
       case
         when tree.dpre_id like 'DP%' then to_number(substr(tree.dpre_id,3))
       end dpre_id,
       first_dpar_id,
       second_dpar_id,
       case
         when tree.dpre_id like 'CLR%' then to_number(substr(tree.dpre_id,4))
       end call_dpre_id,
       case
         when tree.dpre_id like 'CLT%' then to_number(substr(tree.dpre_id,4))
       end call_dtre_id,
       case
         when tree.dpre_id like 'PR%' then to_number(substr(tree.dpre_id,3))
       end priority_dpre_id,
       dlit_id_list,
       row_number() over(partition by tree.dtrh_id order by rn) line
  from (
        select lv,
               predicate,
               dpre_id,
               dclt_id,
               dtrh_id,
               rn,
               c_prior,
               lv - lead(lv) over(partition by dtrh_id order by rn)+
       case
          when lead(c_prior) over(partition by dtrh_id order by rn) in (4,6)
            then 1
          else 0
       end level_diff,
               inverse_yn,
               first_dpar_id,
               second_dpar_id,
               dlit_id_list
          from (
                select level lv,
 predicate,
 s.child_dpre_id dpre_id,
 dclt_id,
 dtrh_dtrh_id dtrh_id,
 rownum rn,
 c_prior,
 inverse_yn,
 first_dpar_id,
 second_dpar_id,
 dlit_id_list
                  from (
  select hierar.parent_dpre_id,
         hierar.child_dpre_id,
         hierar.c_prior,
         predic.dtrh_dtrh_id,
         hierar.dclt_id,
         predic.predicate,
         predic.inverse_yn,
         predic.first_dpar_id,
         predic.second_dpar_id,
         dplk_id,
         predic.dlit_id_list
    from (
          select
                 decode(temp.cn,1,'HD',
          2,'THD',
          3,'DP')||to_char(root_dpre_id) parent_dpre_id,
                 decode(temp.cn,1,'DP',
          2,'HD',
          3,'EP')||to_char(root_dpre_id) child_dpre_id,
                 decode(temp.cn,1,1,
          2,1,
          3,6) c_prior,
                 null as dclt_id,
                 null as dtrh_id,
                 null as dplk_id
            from discount_tree_hist dth,
                 (select level cn from dual connect by level < 4) temp
          union all
          select 'DP'||to_char(dpl.parent_dpre_id),
                 case dclt_dclt_id
                   when 5 then
                      case
   when dpl.dpre_dpre_id is not null and dpl.dtre_dtre_id is null
     then 'CLR'||to_char(dpl.dpre_dpre_id)
   when dpl.dpre_dpre_id is null and dpl.dtre_dtre_id is not null
     then 'CLT'||to_char(dpl.dtre_dtre_id)
   else 'null'
                      end
                   else 'DP'||to_char(dpl.dpre_dpre_id)
                 end child_dpre_id,
                 case
                   when dclt_dclt_id in (3, 4, 5) then 2
                   when dclt_dclt_id = 1 then 3
                   when dclt_dclt_id = 2 then 5
                 end c_prior,
                 dclt_dclt_id,
                 dp.dtrh_dtrh_id,
                 dplk_id
            from discount_predicate_links dpl,
                 discount_predicates dp
           where dpl.parent_dpre_id = dp.dpre_id
          union all
          select 'DP'||to_char(dl.dpre_dpre_id) parent_dpre_id,
                 'PR'||to_char(dl.dpre_dpre_id) dpre_id,
                 4 c_prior,
                 null as dclt_id,
                 null,
                 null as dplk_id
            from discount_leaves dl
           where dl.del_date is null
          union all
          select 'DP'||to_char(dpl.dpre_dpre_id) parent_dpre_id,
                 'EP'||to_char(dpl.dpre_dpre_id) dpre_id,
                 6 c_prior,
                 null, null, null
             from discount_predicate_links dpl
            where dclt_dclt_id in (1,2)
         ) hierar,
         discount_predicates_view predic
   where hierar.child_dpre_id = predic.dpre_id
     and (hierar.dtrh_id = predic.dtrh_dtrh_id or hierar.dtrh_id is null)) s
               connect by NOCYCLE parent_dpre_id = prior s.child_dpre_id
                 start with parent_dpre_id =
      (select 'THD'||to_char(root_dpre_id)
         from discount_tree_hist v
        where v.dtrh_id = s.dtrh_dtrh_id)
                 order siblings by c_prior, dplk_id
               )
       )tree,
       discount_tree_hist dth
 where tree.dtrh_id = dth.dtrh_id /*and dth.dtre_dtre_id = 243*/ and end_date > sysdate
 order by dth.dtre_dtre_id, dtrh_id, line
;


select * from aak_discount_predicate_links_v where dtre_id = 263


----������ ������
select * from discount_trees
where dtre_id in (223,243,263,264)

select * from discount_tree_hist 
where dtre_dtre_id in (223,243,263,264) and end_date > sysdate
for update

select * from discount_predicates where dtrh_dtrh_id = 307
---������������ ������� DPRE_SEQ
select * from discount_predicate_conditions
select * from discount_predicate_arguments
---������������ ������� DPAR_SEQ
select * from discount_predicate_attributes
select * from discount_trees where dtre_id = 243 
for update
select * from discount_pred_attribute_types

select dp.rowid, dpar_id, dc.name, dat.name, dtrh_dtrh_id, dl.priority, dp.* from discount_predicates dp
left join discount_predicate_conditions dc on dpcn_id = dpcn_dpcn_id
left join discount_predicate_arguments da on first_dpar_id = dpar_id
left join discount_predicate_attributes dat on dat.dpat_id = da.dpat_dpat_id
left join discount_leaves dl on dl.dpre_dpre_id = dp.dpre_id
left join discount_tree_hist on dtrh_id = dtrh_dtrh_id
where dtre_dtre_id in (143)
and end_date > sysdate
for update

----��������; ������� DLIT_SEQ
select * from discount_literals
where dpar_dpar_id = 195 
for update
--264 ---223
--263 ---243
select * from discount_literals
where dpar_dpar_id = 357

insert into discount_literals (dlit_id, dpar_dpar_id, pred_arg_number, pred_arg_string, pred_arg_date, navi_user, navi_date, del_user, del_date)
select DLIT_SEQ.NEXTVAL, 195,212, NULL, NULL, 'AAK', SYSDATE, NULL, NULL from dual


begin
for rec in (select dl.pred_arg_number from discount_literals dl
where dpar_dpar_id = 357 and pred_arg_number not in (2,175)) loop
insert into discount_literals (dlit_id, dpar_dpar_id, pred_arg_number, pred_arg_string, pred_arg_date, navi_user, navi_date, del_user, del_date)
select DLIT_SEQ.NEXTVAL, 386,rec.pred_arg_number, NULL, NULL, 'AAK', SYSDATE, NULL, NULL from dual;
end loop;
end;


--- 326 ��� 386 ���

select * from user_sequences
where sequence_name like '%DLIT%'

select * from discount_predicates_view where dtrh_dtrh_id = 307
----���������

select * from 
discount_predicates dp,        
discount_leaves dl  
where dp.dpre_id = dl.dpre_dpre_id
and dtrh_dtrh_id = 284 

select 'then priority ' || decode(dl.priority, 0, 'is null',      ':= ' || to_char(dl.priority)) || ';' 
as predicate
,'PR' || to_char(dp.dpre_id) dpre_id,dp.dtrh_dtrh_id,        
null, null,null, null   from discount_predicates dp,        
discount_leaves dl  where dp.dpre_id = dl.dpre_dpre_id    
and dl.del_date is null and dtrh_dtrh_id = 284

                   




with discount_predicate_attrib_mod as (select case         
  when name like '%ID' and name not in ('OWN_ZONE_ID','SPG_RTPL_ID','DCPL_TMCL_ID')     
             then substr (name, 1, instr(name, '_')-1)           when name = 'DIALLED_NUMBER'     
    then 'DIALLED'           when name = 'CALLED_NUMBER'              
        then 'CALLED'           when name like 'PAY_PHONE_%_$'         
                 then substr(name, 1, instr(name, '_PRICE_$') - 1)     
   when name = 'DCPL_TMCL_ID'             
        then 'DP_TMCL'       
              when name like '%_$'    
   
                 then substr(name, 1, instr(name, '_$') - 1)   
     else substr(name, 1, instr(name, '_', 1, 2) - 1)    
            end name,      
               dpat_id    
               from discount_predicate_attributes)
                ( /*------------------------------------------------------------------------------*/ /* ������ ������������ 
                ������ ����������. �������� ��� ��������� � ���� ������. */ /*------------------------------------------------------------------------------*/ 
                select         case          when fa.dpat_dpat_id is not null then            case               when fa.darf_darf_id is not null      
     then lower(decode(daf.darf_id, 13, 'SHIFT', daf.name)) || ' ('               else ''            end ||     
              lower(fda.name) ||            case              when fa.dcfa_dcfa_id is not null then               case   
      when dfa.pred_func_arg_number is not null then ', ' || to_char(dfa.pred_func_arg_number) || ')'    
                     when dfa.pred_func_arg_string is not null then ', ' || dfa.pred_func_arg_string || ')'    
            end              when fa.darf_darf_id is not null then ')'              else ''   
                     end ||            case              when dp.dpcn_dpcn_id = 1 then ' is null'     
        when dp.dpcn_dpcn_id = 2 then ' is not null'            
            when dp.dpcn_dpcn_id = 3 then                case        
  when liter.cn_liter = 1 and dp.second_dpar_id is null then ' = '          
            when dp.second_dpar_id is not null then ' = '               
                 else  ' in ('                end           
                      when dp.dpcn_dpcn_id = 4 then       
           case               
                when liter.cn_liter = 1 and dp.second_dpar_id is null then ' <> ' 
      when dp.second_dpar_id is not null then ' != '  
  else ' not in ('                
    end              when dp.dpcn_dpcn_id = 5 then ' any '
                  when dp.dpcn_dpcn_id = 6 then ' > '              
                    when dp.dpcn_dpcn_id = 7 then ' < '              
                      when dp.dpcn_dpcn_id = 8 then ' >= '              
  when dp.dpcn_dpcn_id = 9 then ' <= '              
    when dp.dpcn_dpcn_id = 11 then ' between '     
when dp.dpcn_dpcn_id = 12 then ' not between '            end ||            case              
  when dp.second_dpar_id is null then                case                  
     when dp.dpcn_dpcn_id in (11,12)                      then substr(liter.liter, 1, instr(liter.liter, ',') - 1) || ' and ' ||        
    substr(liter.liter, instr(liter.liter, ',') + 1)                   else liter.liter                end       
           when dp.second_dpar_id is not null then lower(sda.name)            end ||            case          
                 when dpcn_dpcn_id in (3,4) and liter.cn_liter > 1 then ')'              else ''            end 
      when fa.darf_darf_id is null and dpcn_dpcn_id = 10 then 'false'       
           when fa.darf_darf_id is null and dpcn_dpcn_id = 0 then 'true'        end predicate
     ,        'DP' || to_char(dp.dpre_id) dpre_id,        dp.dtrh_dtrh_id,        dp.inverse_yn,        
     dp.first_dpar_id,        dp.second_dpar_id,        liter.dlit_id_list   
     from (select distinct dpar_dpar_id,   listagg(case             
     when pred_arg_number like ',%' or pred_arg_number like '.%' then '0' || 
       translate(pred_arg_number, ', ', ' . ')             else 
       translate(pred_arg_number, ',', '.')           end, ',') 
       within group (order by dpar_dpar_id, pred_arg_number) as liter,   
       listagg(dlit_id, ',') within group (order by dpar_dpar_id) as dlit_id_list,   
       count(pred_arg_number) as cn_liter           
       from (select dpar_dpar_id, pred_arg_number, dlit_id                   
       from discount_literals                  where pred_arg_number is not null                    
       and del_user is null                  order by 1, 2)          group by dpar_dpar_id          
       union all         
       
       select distinct dpar_dpar_id,   listagg(pred_arg_string) 
       within group (order by dpar_dpar_id, pred_arg_string) as liter,   listagg(dlit_id, ',') 
       within group (order by dpar_dpar_id) as dlit_id_list,   count(pred_arg_string) as cn_liter           
       from (select dpar_dpar_id, pred_arg_string, dlit_id                   from discount_literals                  
       where pred_arg_string is not null                    and del_user is null                  order by 1, 2)          
       group by dpar_dpar_id          union all         select distinct dpar_dpar_id,   listagg('''' || pred_arg_date || '''') 
       within group (order by dpar_dpar_id, pred_arg_date) as liter,   listagg(dlit_id, ',') 
       within group (order by dpar_dpar_id) as dlit_id_list,   count(pred_arg_date) as cn_liter           
       from (select dpar_dpar_id, pred_arg_date, dlit_id                   from discount_literals                  
       where pred_arg_date is not null                    and del_user is null                  
       order by 1, 2)          group by dpar_dpar_id) liter,        discount_predicate_arguments fa,        
       discount_predicate_arguments sa,        discount_predicates dp,        discount_predicate_attrib_mod fda,        
       discount_predicate_attrib_mod sda,        discount_func_arguments dfa,        
       discount_attribute_func daf  where dp.first_dpar_id = fa.dpar_id (+)    
       and dp.second_dpar_id = sa.dpar_id (+)    and fa.dpat_dpat_id = fda.dpat_id (+)    
       and fa.dpar_id = liter.dpar_dpar_id (+)    and sa.dpat_dpat_id = sda.dpat_id (+)    
       and fa.dcfa_dcfa_id = dfa.dcfa_id (+)    and fa.darf_darf_id = daf.darf_id (+) 
       
       union all /*---------------------------------------------------------
       -----------------------*/ /* �������� ��������������� ���������, ��� ������������ ������ ������� ���������� */ /*--------
       ------------------------------------------------------------------------*/ 
       select 'then priority ' || decode(dl.priority, 0, 'is null',      ':= ' || to_char(dl.priority)) || ';' 
       as predicate
       ,        'PR' || to_char(dp.dpre_id) dpre_id,        dp.dtrh_dtrh_id,        
       null, null,null, null   from discount_predicates dp,        
       discount_leaves dl  where dp.dpre_id = dl.dpre_dpre_id    
       and dl.del_date is null 
       union all 
       /*--------------------------------------------------------------------
       ------------*/ /* �������� ��������������� ���������, ��� ������������ ������ ������ call ������ */ /*-------------
       -------------------------------------------------------------------*/ 
       select distinct dth.def,        
       'CLR' || to_char(dpc.dpre_id),        dpp.dtrh_dtrh_id,        
       null, null, null, null   from discount_predicate_links dpl,        
       discount_predicates dpc,        discount_tree_hist dth,        
       discount_predicates dpp  where dpl.dclt_dclt_id = 5    
       and dpl.dpre_dpre_id = dpc.dpre_id    and dpc.dtrh_dtrh_id = dth.dtrh_id    
       and dpl.parent_dpre_id = dpp.dpre_id 
       union all /*--------------------------------------------------------------
       ------------------*/ /* �������� ��������������� ���������, ��� ������������ ������ ������ call ������ */ /*--------------------
       ------------------------------------------------------------*/ 
       select distinct dt.def,        
       'CLT' || to_char(dt.dtre_id),        dp.dtrh_dtrh_id,        
       null, null, null, null   from discount_predicate_links dpl,        
       discount_trees dt,        discount_predicates dp  where dpl.dclt_dclt_id = 5    
       and dpl.dtre_dtre_id = dt.dtre_id    and dpl.parent_dpre_id = dp.dpre_id 
       union all /*-----------------
       --------------------------------------------------------------
       -------------*/ /* �������� ��������������� ��������� ��������� ������ � ������������ ��� ���������� (end if) */ /*--------
       ------------------------------------------------------------------------------------*/ 
       select        decode(temp.cn,  1, 'tree_info := (' || dt.def || ', ' || dth.def || ', ' || nvl2(dth.editing, '1', '0') || ', 
       to_date(' || to_char(dth.start_date,'dd.mm.yyyy hh24:mi') || '));',  2, 'end if;'),        decode(temp.cn, 1, 'HD' || 
       dth.root_dpre_id,  2, 'EP' || dth.root_dpre_id),        dth.dtrh_id,        null, null, null, null   from discount_tree_hist dth,        
       discount_trees dt,        (select level cn from dual connect by level < 3) temp  where dt.dtre_id = dth.dtre_dtre_id union all /*-----------
       -----------------------------------------------------------------
       ----------------*/ /* �������� ��������������� ��������� ���������� (end if) ��� ��������� �������� if � else if */ /*--------------------
       ------------------------------------------------------------------------*/ 
       select 'end if;',        'EP' || dpl.dpre_dpre_id,        dp.dtrh_dtrh_id,        null, null, null, null   
       from discount_predicate_links dpl,        discount_predicates dp  where dpl.dclt_dclt_id in (1,2)    and dpl.dpre_dpre_id = dp.dpre_id
       )
;

      
