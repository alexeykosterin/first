select * from subscribers where subs_id = 1625104

select * from clients where clnt_id = 148242

select * From bis_versions
select * From app_parameters where prmt_id = 49
for update

select * from client_types

select distinct sys.USER_CONSTRAINTS.CONSTRAINT_NAME, sys.USER_CONSTRAINTS.TABLE_NAME, sys.USER_CONSTRAINTS.CONSTRAINT_TYPE,sys.USER_CONS_COLUMNS.column_name  from 
sys.USER_CONSTRAINTS inner join sys.USER_CONS_COLUMNS 
on sys.USER_CONS_COLUMNS.table_name = sys.USER_CONSTRAINTS.table_name
and
sys.USER_CONS_COLUMNS.owner = sys.USER_CONSTRAINTS.owner
where 1=1
--and sys.USER_CONSTRAINTS.table_name = 'DETAIL_GROUPS'
and sys.USER_CONSTRAINTS.constraint_type = 'P'
and column_name like '%RT%'

select * From subs_histories where subs_subs_id = 7673
select * From client_histories where clnt_clnt_id = 148242
select * from client_types
select * From subs_clnt_histories where subs_subs_id = 1625104

select * from dba_tables where TABLE_NAME like '%CLNT%HIST%'

select * from bba_calls_00_082018
where duration = 0

select count(1) from bba_calls_00_082018
20180815024038,734003

select distinct subs_subs_id from bba_calls_00_082018

select b.in_balance_$/(b.duration/1048576), b.in_balance_$, dctv_dctv_id,
(select 'start '||start_value||' end '||end_value||' '||NAVI_USER||' '||price_$ from discount_thread_volumes where dctv_id = b.dctv_dctv_id) as DCTV, 
b.duration/1048576,b.duration, b.subs_subs_id, b.* from bba_calls_00_082018 b
where 1=1
--and dctv_dctv_id is not null
and subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
and pack_pack_id = 3729)
order by b.subs_subs_id, b.dctv_dctv_id



/*
select b.in_balance_$/(b.duration/1048576), tmcl_tmcl_id from bba_calls_00_082018 b
where 1=1
--and dctv_dctv_id is not null
--and IN_balance_$ != 0
and subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
and pack_pack_id = 3729)*/

-------------
select min(b.in_balance_$/(b.duration/1048576)),max(b.in_balance_$/(b.duration/1048576))  from bba_calls_00_082018 b
where 1=1
and dctv_dctv_id is null
and IN_balance_$ != 0
and subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
and pack_pack_id = 3729)


----------
select sum(b.duration)/1048576 as "���-��_��", sum(in_balance_$), subs_subs_id from bba_calls_00_082018 b
where 1=1 --dctv_dctv_id is not null
and subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
and pack_pack_id = 3729)
group by subs_subs_id




----------
select sum(b.duration)/1048576 as "���-��_��", sum(in_balance_$), subs_subs_id from bba_calls_00_082018 b
where 1=1 
and dctv_dctv_id is not null
and subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
and pack_pack_id = 3729)
group by subs_subs_id


select sum(b.duration)/1048576 from bba_calls_00_082018 b
where dctv_dctv_id is null
and IN_balance_$ != 0

42349,0966663361
30000,000000


select *  from subscriber_discount_threads where subs_subs_id in (select distinct subs_subs_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
and pack_pack_id = 3729)
and end_thread > sysdate



delete from subscriber_discount_threads where subs_subs_id in (1625103)
and end_thread > sysdate



