select * from CALL_CREDITS where subs_subs_id = 7673 ---- AIU_CALL_CREDITS bis_events.register_event(bis_events.evnt_call_credits, :new.clcr_id);
select * from PHONE_HISTORIES where subs_subs_id = 7673 ----   bis_events.register_event(bis_events.evnt_phone_histories, :new.subs_subs_id);
select * from SERV_HISTORIES where subs_subs_id = 7673 ---- bis_events.register_serv_hist_event(:new.subs_subs_id, :new.srls_srls_id);
select * from SUBS_CLNT_HISTORIES where subs_subs_id = 7673 ----
select * from SUBSCRIBER_DISCOUNT_THREADS where subs_subs_id = 7673 ----
select * from SUBSCRIBERS where subs_subs_id = 7673 ----
select * from SUBS_HISTORIES where subs_subs_id = 7673 ----
select * from SUBS_LC_ACTUAL where subs_subs_id = 7673 ----
select * from SUBS_PACKS where subs_subs_id = 7673 ----
select * from SUBS_RTPL_HISTORIES where subs_subs_id = 7673 ----


select AIU_SUBS_PACKS


bis_events.register_event(bis_events.evnt_call_credits, :new.clcr_id);
bis_events.register_event(bis_events.evnt_subs_packs, :new.subs_subs_id);
bis_events.register_event(bis_events.evnt_phone_histories, :new.subs_subs_id);
bis_events.register_serv_hist_event(:new.subs_subs_id, :new.srls_srls_id);
bis_events.register_event(bis_events.evnt_subs_clnt_histories, :new.subs_subs_id);
bis_events.register_event(bis_events.evnt_subscribers_aiu, :new.subs_id);
bis_events.register_event(bis_events.evnt_subs_histories, :new.subs_subs_id);




  IF INSERTING THEN
    BIS_NOTIFY_PG.UPDATE_SUBSCRIBERS(P_SUBSCRIBERS_ROW => V_ROW, P_MODE => 0);
  ELSE
    BIS_NOTIFY_PG.UPDATE_SUBSCRIBERS(P_SUBSCRIBERS_ROW => V_ROW, P_MODE => 1);
  END IF;




create or replace procedure UPDATE_SUBS_INFO (WORK_TABLE in VARCHAR) as
clcr_clnt_cur SYS_REFCURSOR;
begin
  sst_get_subs_coll(WORK_TABLE);
  if REC_SUBS.COUNT != 0 then
    for rec1 in rec_subs.first .. rec_subs.last loop
      dbms_output.put_line(rec_subs(rec1));
      bis.sib_send_pack_aq_brt(PSUBS_ID => REC_SUBS(REC1),
      PPACK_ID => NULL);
BIS.BIS_EVENTS.REGISTER_EVENT(BIS.BIS_EVENTS.EVNT_SUBS_HISTORIES,
rec_subs(REC1));
bis.bis_events.register_event(bis.bis_events.evnt_serv_histories, rec_subs(rec1));

if rec_subs.count != 0 THEN
  for rec2 in (select clcr_id from bis.call_credits
    wheree subs_subs_id = rec_subs(rec1)) loop
    bis.sib_send_clcr_aq_brt(p_clcr_id => rec2.clcr_id);
    sst_step_commit;
end loop rec2;
end if;
sst_step_commit;
end loop rec_evnt;
--commit;
open clcr_clnt_cur for 'select clcr_id from bis.call_credits where clnt_clnt_id in (select distinct clnt_clnt_id from 
' || WORK_TABLEE ||')';
loop
  FETCH CLCR_CLNT_CUR BULK COLLECT 
  INTO REC_CLCR_CLNT;
  exit when clcr_clnt_CUR%NOTFOUND;
  END LOOP;
  CLOSE CLCR_CLNT_CUR;

if rec_CLCR_CLNT.COUNT != 0 THEN
  for rec3 in rec_CLCR_CLNT.FIRST .. REC_CLCR)CLNT.LAST LOOP
bis.sib_send_CLCR_AQ_BRT(P_CLCR_ID => REC_CLCR_CLNT(REC3));
dbms_output.put_line(REC_CLCR_CLNT(REC3));
sst_step_COMMIT(100);
end loop rec3;
--commit;
end if;
else
  dbms_output.put_line('no subs in your table');
  end if;
sst_finalite;
dbms_output.put_line('END SYNC DATA IN BRT');
exception
  when others then
    dbms_output.put_line('chek your work table');
end;




DECLARE
	PSUBS number :=7673;
	CURSOR get_clcr IS
	SELECT * FROM call_credits where subs_subs_id = PSUBS;
  CURSOR get_srls IS
	SELECT * FROM serv_histories where subs_subs_id = PSUBS;
	v_gt get_clcr%ROWTYPE;
  v_gt2 get_srls%ROWTYPE;
BEGIN
	OPEN get_clcr;
	LOOP 
		EXIT WHEN get_clcr%NOTFOUND;
		FETCH get_clcr INTO v_gt;	
bis_events.register_event(bis_events.evnt_call_credits, v_gt.clcr_id);
DBMS_OUTPUT.put_line('SYNC CLCR='||v_gt.clcr_id);
	END LOOP;
	CLOSE get_clcr; 
bis_events.register_event(bis_events.evnt_subs_packs, PSUBS);
bis_events.register_event(bis_events.evnt_phone_histories, PSUBS);
bis_events.register_event(bis_events.evnt_subs_clnt_histories, PSUBS);
bis_events.register_event(bis_events.evnt_subscribers_aiu, PSUBS);
bis_events.register_event(bis_events.evnt_subs_histories, PSUBS);
DBMS_OUTPUT.put_line('SYNC WITH BRT SUBS='||PSUBS);
OPEN get_srls;
	LOOP 
		EXIT WHEN get_srls%NOTFOUND;
		FETCH get_srls INTO v_gt2;	
bis_events.register_serv_hist_event(PSUBS, v_gt2.srls_srls_id);
DBMS_OUTPUT.put_line('SYNC SRLS='||v_gt.clcr_id ||' FOR SUBS='||PSUBS);
	END LOOP;
	CLOSE get_srls; 
--commit;
END;



create or replace procedure UPDATE_SUBS_INFO (WORK_TABLE in VARCHAR) as

PSUBS number :=7673;
	CURSOR get_clcr IS
	SELECT * FROM call_credits where subs_subs_id = PSUBS;
  CURSOR get_srls IS
	SELECT * FROM serv_histories where subs_subs_id = PSUBS;
	v_gt get_clcr%ROWTYPE;
  v_gt2 get_srls%ROWTYPE;
BEGIN
	OPEN get_clcr;
	LOOP 
		EXIT WHEN get_clcr%NOTFOUND;
		FETCH get_clcr INTO v_gt;	
bis_events.register_event(bis_events.evnt_call_credits, v_gt.clcr_id);
DBMS_OUTPUT.put_line('SYNC CLCR='||v_gt.clcr_id);
	END LOOP;
	CLOSE get_clcr; 
bis_events.register_event(bis_events.evnt_subs_packs, PSUBS);
bis_events.register_event(bis_events.evnt_phone_histories, PSUBS);
bis_events.register_event(bis_events.evnt_subs_clnt_histories, PSUBS);
bis_events.register_event(bis_events.evnt_subscribers_aiu, PSUBS);
bis_events.register_event(bis_events.evnt_subs_histories, PSUBS);
DBMS_OUTPUT.put_line('SYNC WITH BRT SUBS='||PSUBS);
OPEN get_srls;
	LOOP 
		EXIT WHEN get_srls%NOTFOUND;
		FETCH get_srls INTO v_gt2;	
bis_events.register_serv_hist_event(PSUBS, v_gt2.srls_srls_id);
DBMS_OUTPUT.put_line('SYNC SRLS='||v_gt.clcr_id ||' FOR SUBS='||PSUBS);
	END LOOP;
	CLOSE get_srls; 
--commit;
END;








select * from serv_histories









DECLARE
	PSUBS number :=7673;
begin
  bis_events.register_event(bis_events.evnt_subs_packs, PSUBS);
bis_events.register_event(bis_events.evnt_phone_histories, PSUBS);
bis_events.register_serv_hist_event(:new.subs_subs_id, v_gt.srls_srls_id);
bis_events.register_event(bis_events.evnt_subs_clnt_histories, PSUBS);
bis_events.register_event(bis_events.evnt_subscribers_aiu, PSUBS);
bis_events.register_event(bis_events.evnt_subs_histories, PSUBS);
DBMS_OUTPUT.put_line('SYNC WITH BRT SUBS='||PSUBS);
end;

bis_events.register_serv_hist_event(:new.subs_subs_id, :new.srls_srls_id);

create table aak_test2 (subs_subs_id number(30))

select * from aak_test2 
for update

begin
  UPDATE_SUBS_INFO(PSUBS => 7673);
end;

select distinct srls_srls_id from bis.serv_histories where subs_subs_id in (select distinct subs_subs_id from aak_test2)


select * from call_credits where subs_subs_id = 7673 for update

select * from preference_tariffication_types
select * from trafics_by_directions 
--where pack_pack_id = 113 
where rtpl_rtpl_id = 228
and navi_user like 'AAK'
for update

select * from calls_unknown

select *
from trafics_by_directions tf
where 1=1
and drct_drct_id = 48 and rtpl_rtpl_id = 227 and rpdr_rpdr_id = 1

create table AAK_FOR_ROLLBACK as select * from pstn_calls_00_072018 where 1=2

select * from scaled_price
select * from scaled_price_parts

begin 
bis.re_post_rating.rollback_from_table(1, 'pstn_calls_00_072018', 
'rowid in (select row_id from kolesnik_a.doubles_calls where in_balance_$>0 and dctv_dctv_id is not null) and rec_type in ( 70,71,74) and MOD(MAIN_CLNT_ID,32)
in (28,29,30,31) and insert_date<sysdate-3'); 
end;





select rowid,pp.dctv_dctv_id, pp.rsta_rsta_id, round((case when lcal_lcal_id in (3,5) then pp.duration/60 end),2) DURATION2, pp.in_balance_$, pp.lcal_lcal_id, 
pp.start_time, pp.dialed, pp.* from pstn_calls_00_072018 pp where subs_subs_id = 7678



create table AAK_FOR_ROLLBACK as select * from pstn_calls_00_072018 where 1=2
