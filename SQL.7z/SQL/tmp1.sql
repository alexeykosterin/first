select * from directions where name_r not like 'RN%'
and name_r not like '%�����%'
and name_r not like '%���%'
and name_r not like '%����%'
and name_r not like '%�����%'
and name_r not like '%�������%'
and name_r not like '%IFS%'
and name_r not like '%ISF%'
and drct_id not in (0,1000,1001,1002,1003,1004,1005,1007,1008,1009,1030,2362,177,2357)


declare
v_name varchar2(100);
v_name_DEF varchar2(100);
begin
  for rec in (select * from directions where name_r not like 'RN%'
and name_r not like '%�����%'
and name_r not like '%���%'
and name_r not like '%����%'
and name_r not like '%�����%'
and name_r not like '%�������%'
and name_r not like '%IFS%'
and name_r not like '%ISF%'
and drct_id not in (0,1000,1001,1002,1003,1004,1005,1007,1008,1009,1030,2362,177,2357)) loop
    
    if rec.name_r like '%ABC%' then
      select REPLACE(rec.name_r, 'ABC', '') into v_name from dual;
      dbms_output.put_line(rec.name_r||' - ���� DEF ���');
      insert into directions (drct_id, name_e, name_r, name_1, name_2, rndt_rndt_id, navi_user, navi_date)
      select drct_seq.nextval, translit(REPLACE(rec.name_r, 'ABC', ''))||' DEF', REPLACE(rec.name_r, 'ABC', '')||' DEF', 'RTGF-6004', NULL,1, 'AAK', 
        trunc(sysdate) from dual;
      
      for rec2 in (select REPLACE(name_r, 'DEF', '') as nn, name_r from directions where name_r like '%DEF%'
        and name_r not like 'RN%'
and name_r not like '%�����%'
and name_r not like '%���%'
and name_r not like '%����%'
and name_r not like '%�����%'
and name_r not like '%�������%'
and name_r not like '%IFS%'
and name_r not like '%ISF%'
and drct_id not in (0,1000,1001,1002,1003,1004,1005,1007,1008,1009,1030,2362,177,2357)
        ) loop
     
      if v_name like rec2.nn then 
        dbms_output.put_line(rec.name_r||' '||rec2.name_r||' - ��� ���� ���� ABC+DEF');
      end if;
      
      end loop;
      
      
    elsif rec.name_r like '%DEF%' then
       dbms_output.put_line(rec.drct_id||' '||rec.name_r||' - ���� ABC ���');
        insert into directions (drct_id, name_e, name_r, name_1, name_2, rndt_rndt_id, navi_user, navi_date)
        select drct_seq.nextval, translit(REPLACE(rec.name_r, 'DEF', ''))||' ABC', REPLACE(rec.name_r, 'DEF', '')||' ABC', 'RTGF-6004', NULL,1, 'AAK', 
        trunc(sysdate) from dual;
    else
      dbms_output.put_line(rec.name_r||' - ������� ABC');
    update directions set name_r = rec.name_r||' ABC', name_2 = 'RTGF-6004', navi_date = trunc(sysdate) where name_r = rec.name_r;
    insert into directions (drct_id, name_e, name_r, name_1, name_2, rndt_rndt_id, navi_user, navi_date)
    select drct_seq.nextval, translit(rec.name_r), rec.name_r||' DEF', 'RTGF-6004', NULL,1, 'AAK', 
    trunc(sysdate) from dual;
    end if;
    
  end loop;
end;



with t1 as (
select REPLACE(name_r, 'ABC', '') as nn1, name_r, drct_id from directions where name_r like '%ABC%'
and navi_date = trunc(sysdate)
), t2 as (select REPLACE(name_r, 'DEF', '') as nn2, name_r, drct_id from directions where name_r like '%DEF%'
and navi_date = trunc(sysdate))
select tt1.*, tt2.*, pd.*, rpd.*--, tbd.* 
from t1 tt1
join t2 tt2 on lower(tt1.nn1) like lower(tt2.nn2)
join pset_directions pd on pd.drct_drct_id = tt1.drct_id 
join rate_plan_directions rpd on rpd.rpdr_id = pd.rpdr_rpdr_id 
--join trafics_by_directions tbd on tbd.rpdr_rpdr_id = pd.rpdr_rpdr_id 




declare
v_rpdr_id number(10);
begin
  for rec in (
with t1 as (
select REPLACE(name_r, 'ABC', '') as nn1, name_r as name_r1, drct_id as drct_id1 from directions where name_r like '%ABC%'
and navi_date = trunc(sysdate)-1
), t2 as (select REPLACE(name_r, 'DEF', '') as nn2, name_r as name_r2, drct_id as drct_id2 from directions where name_r like '%DEF%'
and navi_date = trunc(sysdate)-1)
select tt1.*, tt2.*, pd.*--, rpd.*, tbd.* 
from t1 tt1
join t2 tt2 on lower(tt1.nn1) like lower(tt2.nn2)
join pset_directions pd on pd.drct_drct_id = tt1.drct_id1 ) loop
select rpdr_seq.nextval into v_rpdr_id from dual;
    insert into pset_directions (psdr_id, number_history, pset_pset_id, rpdr_rpdr_id, start_date, end_date, navi_user, navi_date, drct_drct_id, tmpl_rpdr_id)
    select psdr_seq.nextval, rec.number_history,rec.pset_pset_id, v_rpdr_id, rec.start_date, rec.end_date, 'AAK', trunc(sysdate), rec.drct_id2,rec.tmpl_rpdr_id from dual;
  
  insert into rate_plan_directions (rpdr_id, rtpl_rtpl_id, rndt_rndt_id, name_e, name_r, name_1, name_2, navi_user, navi_date, drtp_drtp_id, pack_pack_id, mtxl_mtxl_id)
  select v_rpdr_id, 228,0, translit(rec.nn2), rec.nn2, rec.rpdr_rpdr_id, rec.drct_id1,'AAK', trunc(sysdate),1, null,null from dual;
  
  end loop;
end;


select * from rate_plan_directions where navi_date = trunc(sysdate);
select * from pset_directions where navi_date = trunc(sysdate);



select * from rate_plan_directions r, rate_plan_directions rr
where r.rpdr_id = to_char(rr.name_1)
and rr.name_1 LIKE '[0-9]%'

-------------
with t as (
select to_char(r.name_1) as CHAR_1, r.* from rate_plan_directions r 
where REGEXP_LIKE (r.name_1, '^[0-9]+')
and navi_date = trunc(sysdate)
)
select rt.*, rr.* from t rt
join rate_plan_directions rr on  rr.rpdr_id = rt.char_1
-------------



begin
  for rec in (with t as (
select to_char(r.name_1) as CHAR_1, r.* from rate_plan_directions r 
where REGEXP_LIKE (r.name_1, '^[0-9]+')
and navi_date = trunc(sysdate)
)
select rt.char_1, rt.rpdr_id, rr.pack_pack_id from t rt
join rate_plan_directions rr on  rr.rpdr_id = rt.char_1) loop
  execute immediate 'update rate_plan_directions set pack_pack_id = '||rec.pack_pack_id||' where rpdr_id = '||rec.rpdr_id;
  end loop;
end;


with t as (
select to_char(r.name_1) as CHAR_1, r.* from rate_plan_directions r 
where REGEXP_LIKE (r.name_1, '^[0-9]+')
and navi_date = trunc(sysdate)
)
select rt.char_1, rt.rpdr_id, tbd.* from t rt
join rate_plan_directions rr on  rr.rpdr_id = rt.char_1
join trafics_by_directions tbd on tbd.rpdr_rpdr_id = rt.char_1


begin
  for rec in (with t as (
select to_char(r.name_1) as CHAR_1, r.* from rate_plan_directions r 
where REGEXP_LIKE (r.name_1, '^[0-9]+')
and navi_date = trunc(sysdate)
)
select rt.char_1, rt.rpdr_id, tbd.* from t rt
join rate_plan_directions rr on  rr.rpdr_id = rt.char_1
join trafics_by_directions tbd on tbd.rpdr_rpdr_id = rt.char_1) loop
    insert into trafics_by_directions (tmcl_tmcl_id, number_history, price_$, pphm_pphm_id, drct_drct_id, rpdr_rpdr_id, function_name, start_date, end_date, navi_user, navi_date, 
    cur_cur_id, xtyp_xtyp_id, lcal_lcal_id, connection_$, enable_faf, scpr_scpr_id, pttp_pttp_id, srls_srls_id, cou_cou_id, rmop_rmop_id, aob_aob_id, add_drct_id, add_rpdr_id, 
    pack_pack_id, rtcm_rtcm_id, flag_cs, zone_zone_id, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, rtpl_rtpl_id)
    select rec.tmcl_tmcl_id, rec.number_history, rec.price_$, rec.pphm_pphm_id, rec.drct_drct_id, rec.rpdr_id, rec.function_name, rec.start_date, rec.end_date,
    'AAK', trunc(sysdate), rec.cur_cur_id, rec.xtyp_xtyp_id, rec.lcal_lcal_id, rec.connection_$, rec.enable_faf, rec.scpr_scpr_id, rec.pttp_pttp_id, rec.srls_srls_id, 
    rec.cou_cou_id,
    rec.rmop_rmop_id, rec.aob_aob_id, rec.add_drct_id, rec.add_rpdr_id, rec.pack_pack_id,rec.rtcm_rtcm_id, rec.flag_cs, rec.zone_zone_id, rec.tfrg_tfrg_id, rec.home_tfrg_id, 
    rec.home_rmop_id, rec.rmtp_rmtp_id, rec.rtpl_rtpl_id
    from dual;
  end loop;
end;







select * From mth_tarif_histories where navi_user like 'AAK'

select * from trafics_by_directions where navi_date = trunc(sysdate)





delete from rate_plan_directions where navi_date = trunc(sysdate)-1;
delete from pset_directions where navi_date = trunc(sysdate)-1;

select * from rate_plan_directions where navi_date = trunc(sysdate)-1 
for update

SELECT Segment_Name,
SUM(Bytes / 1024 / 1024) MBytes
FROM   DBA_Extents
WHERE  lower(Segment_Name) like 'rate_plan_directions'
GROUP BY Segment_Name




select r.* from rate_plan_directions r
where r.navi_date = trunc(sysdate)

select r.* from rate_plan_directions r
where r.navi_date = trunc(sysdate)

select * from pset_directions where navi_date = trunc(sysdate)

select r.*, rp.* from rate_plan_directions r, rate_plan_directions rp
where rp.pack_pack_id = r.pack_pack_id
and rp.rtpl_rtpl_id = r.rtpl_rtpl_id
and r.navi_date = trunc(sysdate)
and rp.name_r = r.name_r
and rp.navi_user = 'AAK'
--and rp.navi_date != trunc(sysdate)
and r.navi_user != 'AAK'




with t1 as (
select REPLACE(name_r, 'ABC', '') as nn1, name_r, drct_id from directions where name_r like '%ABC%'
and navi_date = trunc(sysdate)
), t2 as (select REPLACE(name_r, 'DEF', '') as nn2, name_r, drct_id from directions where name_r like '%DEF%'
and navi_date = trunc(sysdate))
select tt1.*, tt2.*, pd.*, rpd.*--, tbd.* 
from t1 tt1
join t2 tt2 on lower(tt1.nn1) like lower(tt2.nn2)
join pset_directions pd on pd.drct_drct_id = tt1.drct_id 
join rate_plan_directions rpd on rpd.rpdr_id = pd.rpdr_rpdr_id 
order by rpd.name_r











select * from dba_constraints where constraint_name like '%PSDR_RPDR_FK%'


begin
  for rec in (select * from dba_constraints where constraint_name like 'PSDR_RPDR_FK') loop
  execute immediate 'ALTER TABLE '||rec.table_name||' DISABLE CONSTRAINT '||rec.constraint_name;
end loop;
end;


begin
  for rec in (select * from dba_constraints where constraint_name like 'PSDR_RPDR_FK') loop
  execute immediate 'ALTER TABLE '||rec.table_name||' ENABLE CONSTRAINT '||rec.constraint_name;
end loop;
end;





select psdr_seq.nextval from dual

select max(psdr_id) from pset_directions


select max(length(name_r)) from directions
select length(name_r), t.* from directions t






select drct_seq.nextval from dual
select max(drct_id) from directions
select * from directions where navi_date = trunc(sysdate);

select * from directions where drct_id in (2380,2381,2444,2445)


select * from pstn_calls_00_092019 where zone_zone_id in (358)
update directions set name_2 = 'TEST', name_r = name_r||' ABC' where name_r like '����%'


select REPLACE(name_r, 'DEF', '') from directions where name_r like '%DEF%'
select * from directions where drct_id in (2358,2359)



SELECT
   owner, 
   table_name, 
   TRUNC(sum(bytes)/1024/1024) Meg,
   ROUND( ratio_to_report( sum(bytes) ) over () * 100) Percent
FROM
(SELECT segment_name table_name, owner, bytes
 FROM dba_segments
 WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
 UNION ALL
 SELECT i.table_name, i.owner, s.bytes
 FROM dba_indexes i, dba_segments s
 WHERE s.segment_name = i.index_name
 AND   s.owner = i.owner
 AND   s.segment_type IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION')
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.segment_name
 AND   s.owner = l.owner
 AND   s.segment_type IN ('LOBSEGMENT', 'LOB PARTITION')
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.index_name
 AND   s.owner = l.owner
 AND   s.segment_type = 'LOBINDEX')
WHERE owner in UPPER('bis')
--AND lower(TABLE_NAME) = 'rate_plan_directions'
GROUP BY table_name, owner
HAVING SUM(bytes)/1024/1024 > 10  /* Ignore really small tables */
ORDER BY SUM(bytes) desc

