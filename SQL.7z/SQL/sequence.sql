CREATE SEQUENCE test_aak1
START WITH 1
INCREMENT BY 1
MAXVALUE 1000
MINVALUE 1
CYCLE
ORDER
CACHE 2;

select test_aak1.nextval from dual;
select test_aak1.currval from dual;

declare
val number(38);
begin
--execute immediate 'select test_aak1.nextval from dual';
select test_aak1.nextval into val from dual;
dbms_output.put_line(val);
end;

 select *
    from trafic_histories2
   where rtpl_rtpl_id = 217
   and tmcl_tmcl_id not in (0, 1)

select max(tmcl_id)+1 from time_classes
select * from user_sequences
where sequence_name like '%TM%'
select TMCL_SEQ.Nextval from dual

select max(tmcl_id) from time_classes 


select * from sys_logs where lower(message) like '%7673%'

select * from directions


select * from logic_calls
