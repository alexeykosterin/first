insert into rtk_migr_input_ftr
select account, 'NEW', sysdate, user, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
from t_users where user_id in
(select /*+ parallel(s,10)*/ distinct user_id from t_services s where date_end is null
and svc_id in (select svc_id from tmp_dsok_ftr_svc))
and iscorp = 'Y'
and user_id not in (select user_id from t_services where date_end is null and svc_id not in (select svc_id from tmp_dsok_ftr_svc))


select distinct account From rtk_migr_input_ftr
where account in (select distinct acc from aak_account where acc is not null
and rtpl like '__L%')



select * from aak_account

and account in (654000040287,
654000051748,
654000057437,
654000116424
)
----79/66
select distinct * from aak_account where acc is not null
and rtpl like '__L%'
----498/192 �� ���

select distinct acc from aak_account where acc is not null
and rtpl like '__L%' and exists (select 1 from rtk_migr_input_ftr tt where acc = tt.account)


80LART_203897 3870 
80LFRT_203898 3870
80LART_70060 100 
80LART_70061 200
80LART_70062 500
80LFRT_700510 100
80LFRT_700511 200
80LGRT_72013



