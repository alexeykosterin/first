select * from directions 

67  ������������� �������, ���. �����
68  ������������� �������, ����.�����

select * from rate_plan_directions
where navi_user like '%AAK%'


select * from trafics_by_directions
where rpdr_rpdr_id in (
select rpdr_id from rate_plan_directions
where navi_user like '%AAK%'
and name_e like '%ABC'
)

select * 
from trafics_by_directions 
where rpdr_rpdr_id in (select rpdr_id From rate_plan_directions di where pack_pack_id = 301211)

select * From rate_plan_directions di where pack_pack_id = 301211


select * from rating_groups

drop table aak_rating
create table aak_rating (
RO  varchar2(300), TFP_CODE	 varchar2(300),TFP_NAME	 varchar2(300),TFP_DESC	 varchar2(300),SRD_CODE	 varchar2(300),SRD_INT_CODE	 varchar2(300),SRD_NAME	 varchar2(300),
TRS_BASE_COST number(10,5))

select * from aak_rating 
for update

select * from rating_groups




create table aak1 as






with table1 as (
select 
(case when RO='���������' then 60699
when RO='�����������' then 60799
  when RO='�������' then 61099
    when RO='������������' then 69905
      when RO='������' then 60999
        when RO='� �������' then 60299
          when RO='�������' then 60399
            when RO='������ �����' then 60101
              when RO='���������' then 60499
                 when RO='�������������' then 60899
end) as RO
,SRD_INT_CODE,TFP_CODE,(regexp_replace(TFP_NAME, '[^[:digit:]]')) as TFP_NAME,TRS_BASE_COST from aak_rating 
group by RO,SRD_INT_CODE,TFP_CODE,TRS_BASE_COST,TFP_NAME)
,
table2 as 
(select distinct rtgr_id, regexp_replace(REGEXP_SUBSTR(def, '\([^)]*\)'), ('[+ ., �-� �-� ()-]*'), '') as def  from rating_groups)
,
table3 as (select distinct pack_id, regexp_replace(name_r, '[^[:digit:]]') as name_r  from packs where name_r like '%Webstre%'
and navi_user like '%AAK%'
and name_r like '%(��)%')
select RO,SRD_INT_CODE,TFP_CODE,TRS_BASE_COST,ttt.name_r,ttt.pack_id, 
--(case when TFP_NAME is not null then 1 when TFP_NAME is null then 50 end) 
TFP_NAME, tt.rtgr_id from table1 t
left join table2 tt on tt.def = t.SRD_INT_CODE
left join table3 ttt on t.tfp_name = ttt.name_r
where def is not null
--and tfp_name is not null
and TFP_CODE like '%LA%'
order by RO, SRD_INT_CODE, RTGR_ID, TFP_NAME






select * 
from trafics_by_directions 
where rpdr_rpdr_id in (select rpdr_id From rate_plan_directions di where pack_pack_id = 301211)
and navi_user not like '%AAK%'


select * From rate_plan_directions di
where rpdr_id in
(31140,
31256,
31322)

select * From rate_plan_directions di where 
--pack_pack_id = 3795
navi_user like '%AAK%'
and trunc(navi_date) = to_date('31.07.2018','dd.mm.yyyy')

select * from prefix_sets where prefix like '81096078%'
select * from pset_directions
select * from directions 
where name_r like '%������� %'



select * from trafic_histories



select * from zones

select * from packs where name_r like 'Webstream%'

select * from trafic_histories where pack_pack_id = 3778 and rtgr_rtgr_id = 15
16
12
13

J_Z01_VL 11
NET_I_1_VL 15
select * from rating_groups where def like '%NET_I_1_VL%'




insert into trafic_histories (srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, pack_pack_id, pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, navi_date, faft_faft_id, scpr_scpr_id, rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id)
select 
srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, 0, lcal_lcal_id, rtpl_rtpl_id, 3778, pset_pset_id, 0.15, 
pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, SYSDATE, 
faft_faft_id, scpr_scpr_id, 
15, 
pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, 60599, home_rmop_id, 
rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id
from trafic_histories where pack_pack_id = 3778 and home_tfrg_id = 60599
and rtgr_rtgr_id in (14)





select * from discount_trees
143
select max(dtre_id) from discount_trees 
where dtre_id = 143

select * from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3778)
for update

--14 = 1
select * from zones where def like
'%����������%'

60599
0508 ��.2� ����� ������������
3 ������� ����� (����������)
/*0531 ��.2 �������, �������� (������������ � ������)
0509 ��.2 �.�������� (������������ � ������)
0518 ��.5 ����������ꠠ(������������ � ������)
*/

11-15
0.15----------------
245	�����������
54	���.�����������
260	������-��������
285	��������
43	���.��������
262	��������
243	�������
51	���.�������
52	��.�.����������
62	���.����������

11-15
0.1----------------
57	���.����������
59	��. ����������
53	����������+
230	����������



select * from rating_groups 
where def like '%J_Z99_N_VL%'

select * from packs where name_r like 'Webstream%'
3731 - �����������

















select * from trafic_histories where 1=1 and pack_pack_id = 3731
--delete from trafic_histories where home_tfrg_id not in (60899) and pack_pack_id = 3731


begin
  for rec in (select * from zones where zone_id in (0)) loop
    for rec2 in (select * from rating_groups where rtgr_id in (17,12,16)) loop
    insert into trafic_histories (srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, pack_pack_id, pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, navi_date, faft_faft_id, scpr_scpr_id, rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id)
select 
srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, rec.zone_id, lcal_lcal_id, rtpl_rtpl_id, 3731, pset_pset_id, 1, 
pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, SYSDATE, 
faft_faft_id, scpr_scpr_id, 
rec2.rtgr_id, 
pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, 60899, home_rmop_id, 
rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id
from trafic_histories where pack_pack_id = 3731 and home_tfrg_id = 60899
and rtgr_rtgr_id in (14);
end loop;
  end loop;
end;


17 12 16 ��� 14



select * from trafic_histories where pack_pack_id = 3731
and rtgr_rtgr_id not in (11,28,14)


update trafic_histories set zone_zone_id = 53 
where pack_pack_id = 3778 and rtgr_rtgr_id in (11,15)



select * from trafic_histories where pack_pack_id = 3778
and home_tfrg_id in (60599)

delete from trafic_histories where pack_pack_id = 3778
and home_tfrg_id not in (60599)

select * from packs where pack_id = 3778

select * from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3731)


select * from discount_thread_volumes where dctr_dctr_id in 
(select dctr_id from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3731))
order by dctr_dctr_id, end_value
for update
--393 444 730
select * from discount_plans where pack_pack_id = 3731 for update
select * from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3731) for update
select max(dctv_id) from discount_thread_volumes
select * from discount_plan_histories where dcpl_dcpl_id = 365 for update

1,000000	3000	5000
1,000000	5000	10000
1,000000	10000	12000
1,000000	12000	30000
1,000000	30000	50000
1,000000	50000	100000
1,000000	100000	
1,050000	2000	3000
1,100000	1000	2000
1,150000	500	1000
1,200000	200	500
1,250000	100	200
1,300000	50	100

select * from rating_groups where def like '%J_Z99_N_VL%'









select * from packs where name_r like '%Webstre%'
and navi_user like '%AAK%'
and name_r like '%(��)%'




select RO,SRD_INT_CODE,TFP_CODE,TRS_BASE_COST,TFP_NAME from t where tfp_name is not null
and TFP_CODE like '%LA%'

select * from aak2

create table aak2 as
with tt as
(select distinct rtgr_id, regexp_replace(REGEXP_SUBSTR(def, '\([^)]*\)'), ('[+ ., �-� �-� ()-]*'), '') as def  from rating_groups)
select * from tt
where def is not null







select rg.* from rating_groups rg
SELECT REGEXP_REPLACE(('(123)', '\([^()]*\)') FROM DUAL;

'\([^()]*\)'

select * from packs where name_r like '%Webstre%'
and navi_user like '%AAK%'
and name_r like '%(��)%'


SELECT
REGEXP_REPLACE('(123)','\([^()]*\)','') RESULT
FROM dual

select regexp_replace('(123)', ('[+ ., a-z A-Z ()-]*'), '') from dual;




select * from trafic_histories
where pack_pack_id in (select pack_id from packs where name_r like '%Webstre%'
and navi_user like '%AAK%')



select rg.* from rating_groups rg
join aak_rating on lower(def) like ('%' || lower(SRD_INT_CODE) || '%')



select max(rtgr_id) from rating_groups


select rtgr_seq.nextval from dual;


declare 
v_cnt number(10);
v_cnt2 number(10);
v_cnt3 number(10);
v_cnt4 number(10);
begin
  select max(rtgr_id) into v_cnt2 from rating_groups;
  select rtgr_seq.nextval into v_cnt from dual;
  dbms_output.put_line(v_cnt);
  dbms_output.put_line(v_cnt2);
  v_cnt3 := v_cnt2 - v_cnt;
  dbms_output.put_line(v_cnt3);
  for rec in 1 .. v_cnt3 loop
select rtgr_seq.nextval into v_cnt4 from dual;
dbms_output.put_line(v_cnt4);
end loop;
end;



select * from rating_groups

J_Z03_VL
NET_I_3_VL
NET_I_4_VL
J_Z04_VL
NETFLOW
NET_I_1_VL
J_Z01_VL
J_Z02_VL
NET_I_2_VL


begin
  for rec in (select distinct SRD_INT_CODE from aak_rating aa
join rating_groups on lower(def) not like ('%' || lower(SRD_INT_CODE) || '%')) loop
insert into rating_groups (rtgr_id, def, navi_user, navi_date)
select rtgr_seq.nextval, rec.srd_int_code, 'AAK', trunc(sysdate) from dual;
end loop;
end;






select * from pset_directions 
where drct_drct_id in (67,68)

select * from prefix_sets
select * from matrix_dir_histories
where drct_drct_id in (67,68)

select * from packs where name_r like '%Webstre%'
and navi_user like '%AAK%'
for update



create table aak_dir (number_id number(30), name_coun varchar2(300))

select * from aak_dir for update

select distinct * from aak_dir where 
lower(name_coun) like '%�������%'










