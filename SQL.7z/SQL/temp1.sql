select * from discount_depend_types
select * from discount_plans where pack_pack_id
select * from discount_plan_histories
select * from discount_threads where dcpl_dcpl_id
select * from discount_thread_volumes where dctv_id  
select * from pack_rtpl
select * from TARIF_HISTORIES
select * from TRAFIC_HISTORIES

select * from packs where pack_id = 3731
---PACK_ID
select pack_id + 1 from (SELECT pack_id, LEAD(pack_id) over(order by pack_id) LAST_NUM
FROM packs)
where pack_id + 1 != LAST_NUM
and pack_id > 3700
ORDER BY pack_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
---DCPL_ID
select dcpl_id + 1 from (SELECT dcpl_id, LEAD(dcpl_id) over(order by dcpl_id) LAST_NUM
FROM discount_plans)
where dcpl_id + 1 != LAST_NUM
ORDER BY dcpl_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
---DCTR_ID
select dctr_id + 1 from (SELECT dctr_id, LEAD(dctr_id) over(order by dctr_id) LAST_NUM
FROM discount_threads)
where dctr_id + 1 != LAST_NUM
ORDER BY dctr_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
---DCTV_ID
select dctv_id + 1 from (SELECT dctv_id, LEAD(dctv_id) over(order by dctv_id) LAST_NUM
FROM discount_thread_volumes)
where dctv_id + 1 != LAST_NUM
ORDER BY dctv_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;


create table aak_name_ro (name_r varchar2(250))
select * from aak_name_ro for update
drop table aak_name_ro

select * from aak_name_ro

declare
PPACK number(10) :=3731;
PDCPL number(10);
p_pack number(10);
--p_name_r varchar2(50) := 'Webstream 50 �� ��������� ���� (��)';
begin
for rec2 in (select * from aak_name_ro) loop
for rec in (select * from packs where pack_id = ppack) loop
select pack_id + 1 
into p_pack
from (SELECT pack_id, LEAD(pack_id) over(order by pack_id) LAST_NUM
FROM packs)
where pack_id + 1 != LAST_NUM
and pack_id > 3700
ORDER BY pack_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
dbms_output.put_line(p_pack ||' ' || rec2.name_r);
    insert into packs (pack_id, rtpl_rtpl_id, name_e, name_r, expire_date, navi_user, navi_date, ptyp_ptyp_id, avail_date, duration_limit_date, duration_months, duration_days, poty_poty_id, pcct_pcct_id, switch_pack_id, pack_code, recurring_flag, check_rtpl_charge)
    select p_pack, rtpl_rtpl_id, name_e, rec2.name_r, expire_date, navi_user, sysdate, ptyp_ptyp_id, avail_date, duration_limit_date, duration_months, duration_days, 
    poty_poty_id, pcct_pcct_id, switch_pack_id, pack_code, recurring_flag, check_rtpl_charge from packs where pack_id = PPACK;

  insert into pack_rtpl (pack_pack_id, rtpl_rtpl_id, del_date)
  select p_pack, rtpl_rtpl_id, del_date from pack_rtpl where pack_pack_id = ppack;

end loop;
end loop;
end;

select * from trafic_histories where pack_pack_id = 3731
select * from tarif_histories where pack_pack_id = 3733
select distinct home_tfrg_id from trafic_histories where pack_pack_id = 3723 and home_tfrg_id not in (60899)


begin
  for rec in (select pack_id from packs where pack_id between 3773 and 3782) loop

insert into trafic_histories (srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, pack_pack_id, pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, navi_date, faft_faft_id, scpr_scpr_id, rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, home_tfrg_id, home_rmop_id, rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id)
select srls_srls_id, zntp_zntp_id, number_history, tmcl_tmcl_id, bss_bss_id, zone_zone_id, lcal_lcal_id, rtpl_rtpl_id, rec.pack_id, 
pset_pset_id, price_$, pset_cost_$, connection_$, function_name, start_date, end_date, navi_user, sysdate, faft_faft_id, scpr_scpr_id, 
rtgr_rtgr_id, pttp_pttp_id, cou_cou_id, rmop_rmop_id, aob_aob_id, rtcm_rtcm_id, vunt_vunt_id, flag_cs, tfrg_tfrg_id, 
home_tfrg_id, home_rmop_id, 
rmtp_rmtp_id, actn_actn_id, munt_munt_id, msru_msru_id
from trafic_histories where pack_pack_id = 3731;
end loop;
end;





select * from trafic_histories where pack_pack_id  in (select pack_id from packs where pack_id between 3773 and 3782)
select * from packs where pack_id between 3773 and 3782

select * from pack_rtpl where pack_pack_id = 3774

3773 Webstream 50 �� ��������� ���� (��) (113 114) 403 404 405 
3774 Webstream 50 �� ������ ����� (��) (115 116) 406 407 408 
3775 Webstream 50 �� ������� (��) (117 118) 409 410 411
3776 Webstream 50 �� ������������� ���� (��) (119 120) 412 413 414
3777 Webstream 50 �� ������� 1 (��) (121 122) 415 416 417
3782 Webstream 50 �� ������� 2 (��)   --- 3733 127 97
3778 Webstream 50 �� ���������� (��) ---3733 128  98 
3779 Webstream 50 �� ������� (��) ---3733 129 99
3780 Webstream 50 �� ���� (��) (123 124) 418 419 420
3781 Webstream 50 �� ����� (��) (125 126) 421 422 423---���� �����������


select * from DISCOUNT_THREAD_DEPEND
for update

select * from discount_thread_volumes where dctr_dctr_id  in (403,406,409,412,415,418,421)
for update
select * from discount_threads where dctr_id  in (404)
for update
select * from discount_plan_histories where dcpl_dcpl_id = 367 for update
select * from discount_plans where pack_pack_id = 3733 for update
--127

select * from packs where name_R like '%��%'
select * from discount_thread_volumes where dctr_dctr_id in (374)
order by dctr_dctr_id, end_value

---371 ---403 406 409 412 415 418 421
begin
for rec in (select dctv from aak_dctv) loop
insert into discount_thread_volumes (dctv_id, dctr_dctr_id, value_#, start_value, end_value, navi_user, navi_date, del_user, del_date, value_connection_#, value_in_balance_#, connection_$, price_$, dvcn_dvcn_id, next_dctv_id, child_dctv_id, break_$, join_$, report_threshold)
select DCTV_SEQ.Nextval, rec.dctv, value_#, start_value, end_value, navi_user, navi_date, del_user, del_date, value_connection_#, value_in_balance_#, connection_$, price_$, dvcn_dvcn_id, next_dctv_id, child_dctv_id, break_$, join_$, report_threshold
from discount_thread_volumes where dctr_dctr_id = 374;
end loop;
end;

create table aak_dctv (dctv number(10))

select * from aak_dctv for update



select * from aak_disk order by dctr_dctr_id, end_value

select dctv_id + 7 from (SELECT dctv_id, LEAD(dctv_id) over(order by dctv_id) LAST_NUM
FROM discount_thread_volumes)
where dctv_id + 1 != LAST_NUM
ORDER BY dctv_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY

select * from user_sequences
where sequence_name like '%DCTV%'

select max(dctv_id) from discount_thread_volumes

select DCTV_SEQ.Nextval from dual


create table aak_disk as select * from discount_thread_volumes where 1=2







select * from discount_plans where pack_pack_id = 3731 
for update;
---DCPL_ID
select dcpl_id + 1,dcpl_id + 2 from (SELECT dcpl_id, LEAD(dcpl_id) over(order by dcpl_id) LAST_NUM
FROM discount_plans)
where dcpl_id + 1 != LAST_NUM
and dcpl_id + 2 != LAST_NUM
ORDER BY dcpl_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;



select * from packs where Pack_id = 3777 for update
select * from discount_plan_histories 
where dcpl_dcpl_id in (365,366)
for update
select * from discount_threads where dcpl_dcpl_id in (365, 366) for update
select dctr_id + 1 from (SELECT dctr_id, LEAD(dctr_id) over(order by dctr_id) LAST_NUM
FROM discount_threads)
where dctr_id + 1 != LAST_NUM
ORDER BY dctr_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;



select * from discount_plans where pack_pack_id = 3731
select * from pack_rtpl where pack_pack_id = 3773;
select * from discount_plan_histories where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3731)


begin
for rec2 in (select * from pack_rtpl where pack_pack_id = 3731) loop
  insert into pack_rtpl (pack_pack_id, rtpl_rtpl_id, del_date)
  select 3773, rec2.rtpl_rtpl_id, rec2.del_date from pack_rtpl where pack_pack_id = 3731;
  end loop;
end;


---403
---423


select * from rtpl_srls_substitution where navi_user like '%AAK%'
and result_rtpl_id = 228
order by source_rtpl_id, srls_srls_id

select count(1),srls_srls_id, source_rtpl_id from rtpl_srls_substitution where result_rtpl_id = 228 and navi_user like '%AAK%'
group by srls_srls_id, source_rtpl_id
having(count(1)) > 1

delete rtpl_srls_substitution where rowid in (select max(rowid) from rtpl_srls_substitution where navi_user like '%AAK%' )



create table rtpl_srls_substitution2 as select * from rtpl_srls_substitution


drop table rtpl_srls_substitution2
select * from rtpl_srls_substitution2

alter table rtpl_srls_substitution2
add constraint TEST_AAK unique (srls_srls_id,source_rtpl_id,result_rtpl_id,end_date) 
exceptions into aak_exceptions;

create table aak_exceptions(row_id rowid,
                            owner varchar2(30),
	                          table_name varchar2(30),
                 		        constraint varchar2(30));
                            
truncate table aak_exceptions
select * from trafic_histories
select * from aak_exceptions
select * from rtpl_srls_substitution2 where rowid = 'AAEjKAAACAALqneABN'
select rowid from rtpl_srls_substitution2 where srls_srls_id = 104 and result_rtpl_id = 228 and navi_user like '%AAK%' and source_rtpl_id = 98
select * from aak_exceptions where row_id = 'AAEjKAAACAALqneABN'


delete from rtpl_srls_substitution2 where rowid in 
(select row_id from our_exceptions);




delete from rtpl_srls_substitution t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by srls_srls_id,source_rtpl_id,result_rtpl_id,end_date) as min_rw
from rtpl_srls_substitution
) where rw <> min_rw)


select count(1),srls_srls_id, source_rtpl_id,result_rtpl_id,end_date from rtpl_srls_substitution
group by srls_srls_id, source_rtpl_id,result_rtpl_id,end_date
having(count(1)) > 1

---80

select count(1) from rtpl_srls_substitution where navi_user like '%AAK%'
---318

select * from rtpl_srls_substitution where rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by srls_srls_id,source_rtpl_id,result_rtpl_id,end_date) as min_rw
from rtpl_srls_substitution
) where rw <> min_rw)




