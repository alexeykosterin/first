select * from packs where pack_id in (3683) for update
navi_user like 'AAK'
pack_id = 3681 for update
select * from discount_plans where pack_pack_id in (select pack_id from packs where name_r like '%���%')
select * from discount_plan_histories where dcpl_dcpl_id = 372

3681 -514 559
select dctv_seq.nextval from dual
select * from discount_plans where pack_pack_id in (3683	) for update
select * from discount_plan_histories where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (3683	))  for update
select * from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (3683	))  
for update
select * From discount_thread_volumes where dctr_dctr_id in 
(select dctr_id from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (3683	)))
for update
  
select * from pack_rtpl where pack_pack_id = 3681
for update

select * from packs where navi_user like 'AAK'
result = (lcal in (5,6,9,10)
                : 592 :           and srls = 104)

select * from logic_calls where lcal_id in (5,6,9,10)
select * from serv_lists where srls_id in (105,104)




begin
  for rec in (select * from packs where pack_id in (3683)) loop
insert into discount_plans (dcpl_id, def, rtpl_rtpl_id, pack_pack_id, dctp_dctp_id, dcmr_dcmr_id, dcmr_dcmr_id1, dcmr_dcmr_id2, datp_datp_id, dccl_dccl_id, dcst_dcst_id, dcpa_dcpa_id, dcca_dcca_id, dcpl_comment, dcgr_dcgr_id, automatic_yn, brt_inform, brt_action, priority, brt_min_quota, dpct_dpct_id, dbsl_dbsl_id, history_period, delete_unused, deny_pack_id, align_tunt_id, rndt_rndt_id, common_clcr_dctr_volume_yn, bis_inform, msrr_msrr_id, dmct_dmct_id, ignore_subs_pack_charges, align_quota_by_dctv, is_final, roll_over_allowed, roll_over_pack_id)
select 
dcpl_seq.nextval, substr(rec.name_r,1,32), rtpl_rtpl_id, rec.pack_id, dctp_dctp_id, dcmr_dcmr_id, dcmr_dcmr_id1, dcmr_dcmr_id2, datp_datp_id, dccl_dccl_id, dcst_dcst_id, dcpa_dcpa_id, dcca_dcca_id, dcpl_comment, dcgr_dcgr_id, automatic_yn, brt_inform, brt_action, priority, brt_min_quota, dpct_dpct_id, dbsl_dbsl_id, history_period, delete_unused, deny_pack_id, align_tunt_id, rndt_rndt_id, common_clcr_dctr_volume_yn, bis_inform, msrr_msrr_id, dmct_dmct_id, ignore_subs_pack_charges, align_quota_by_dctv, is_final, roll_over_allowed, roll_over_pack_id
from discount_plans where pack_pack_id = 3681;
end loop;
end;
/
begin
  for rec in (select * from discount_plans where pack_pack_id in (3683)) loop
    insert into discount_plan_histories (dcpl_dcpl_id, number_history, duration, duration_wait, start_use, end_use, start_date, end_date, navi_user, navi_date, clcr_volume)
    select rec.dcpl_id, number_history, duration, duration_wait, start_use, end_use, start_date, end_date, navi_user, navi_date, clcr_volume 
    from discount_plan_histories where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3681);
  end loop;
end;
/

begin
  for rec in (select * from discount_plans where pack_pack_id in (3683)) loop
    insert into discount_threads (dctr_id, phone_number, circuit_in, circuit_out, srls_srls_id, zntp_zntp_id, lcal_lcal_id, zone_zone_id, tmcl_tmcl_id, dctc_dctc_id, dcpl_dcpl_id, function_name, discount_zero_price, mth_srls_id, brt_warning, navi_user, navi_date, del_user, del_date, brt_priority, def, dtre_dtre_id, dvcn_dvcn_id, dvcn_volume, no_reserve, ignore_debet, ignore_balance_lock)
  select 
  dctr_seq.nextval, phone_number, circuit_in, circuit_out, srls_srls_id, zntp_zntp_id, lcal_lcal_id, zone_zone_id, tmcl_tmcl_id, dctc_dctc_id, rec.dcpl_id, function_name, discount_zero_price, mth_srls_id, brt_warning, navi_user, navi_date, del_user, del_date, brt_priority, rec.def, dtre_dtre_id, dvcn_dvcn_id, dvcn_volume, no_reserve, ignore_debet, ignore_balance_lock
  from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3681);
  end loop;
end;
/


begin
  for rec in (select * from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id in (3683))) loop
    insert into discount_thread_volumes (dctv_id, dctr_dctr_id, value_#, start_value, end_value, navi_user, navi_date, del_user, del_date, value_connection_#, value_in_balance_#, connection_$, price_$, dvcn_dvcn_id, next_dctv_id, child_dctv_id, break_$, join_$, report_threshold)
select 
dctv_seq.nextval, rec.dctr_id, value_#, start_value, end_value, rec.def, navi_date, del_user, del_date, value_connection_#, value_in_balance_#, connection_$, price_$, dvcn_dvcn_id, next_dctv_id, child_dctv_id, break_$, join_$, report_threshold
from discount_thread_volumes where dctr_dctr_id in (select dctr_id from discount_threads where dcpl_dcpl_id in (select dcpl_id from discount_plans where pack_pack_id = 3681));
  end loop;
end;

/

















