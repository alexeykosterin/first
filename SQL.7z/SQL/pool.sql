
begin
---create table aak_tmp (beg_ium varchar2(100), beg_ros varchar2(100), end_ium varchar2(100), end_ros varchar2(100), vsp1 varchar2(10), vsp2 varchar2(10), vsp3 varchar2(10), vsp4 varchar2(10))
execute immediate 'truncate table aak_tmp';
  for rec in (select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)) loop
    for rec1 in (select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 not like 'D%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)) loop
      if (rec.beg >= rec1.value_1 and rec.en <= rec1.value_2) then
       -- dbms_output.put_line(rec.beg||' '||rec1.value_1||' '||rec1.value_2||' '||rec.en);
       insert into aak_tmp (beg_ium, beg_ros, end_ium, end_ros, vsp1) select rec.beg, rec1.value_1, rec.en, rec1.value_2, 'FIRST STEP' from dual;
/*       elsif (rec.beg >= rec1.value_1 and rec.en > rec1.value_2) then
         insert into aak_tmp (beg_ium, beg_ros, end_ium, end_ros, vsp1) select rec.beg, rec1.value_1, rec.en, rec1.value_2, 'SECOND STEP' from dual;
       elsif (rec.beg < rec1.value_1) then
       insert into aak_tmp (beg_ium, beg_ros, end_ium, end_ros, vsp1) select rec.beg, rec1.value_1, rec.en, rec1.value_2, 'THIRD STEP' from dual;*/
       end if;
    end loop;
  end loop;
  

execute immediate 'update aak_tmp set vsp2 = ''��� �������� ����������� IUM'' where (to_char(beg_ros)-to_char(beg_ium)) <= 0 and (to_char(end_ros)-to_char(end_ium)) >= 0';

for rec2 in (select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate) loop
insert into aak_tmp (beg_ros, end_ros, vsp2) select rec2.beg, rec2.en, '����� ���' from dual;
end loop;
end;




---2 ������

3835552500 3835552628 -
---������ �������� IUM ����������� ���������� ��������
select * from aak_tmp 
where (to_char(beg_ros)-to_char(beg_ium)) = 0
and (to_char(end_ros)-to_char(end_ium)) >= 0


select (case when (to_char(beg_ros)-to_char(beg_ium)) = 0 then beg_ros||' '||beg_ium||' 0' 
when (to_char(beg_ros)-to_char(beg_ium)) > 0 then beg_ros||' '||beg_ium||' +'
when (to_char(beg_ros)-to_char(beg_ium)) < 0 then beg_ros||' '||beg_ium||' -'
end) from aak_tmp

select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate

---create table aak_tmp (beg_ium varchar2(100), beg_ros varchar2(100), end_ium varchar2(100), end_ros varchar2(100), vsp1 varchar2(10), vsp2 varchar2(10), vsp3 varchar2(10), vsp4 varchar2(10))
select * from aak_tmp where vsp2 is null and vsp3 is null





select distinct * from aak_number_pool_values
where value_1 not like '3%' and end_date > sysdate







---����� ���
select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate
---����������� ��� � IUM 1147
select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate);
---����������� ��� � �������� 35792
--select value_1, value_2 from aak_number_pool_values where end_date > sysdate and uniq_id not in (select number_id From aak_tmp) and value_1 not like 'D%'
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 not like 'D%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate);


select * from aak_number_pool where beginn like '%3952440000'
select * from aak_number_pool_values where '3952409000' between value_1 and value_2

3952409000
3952431000
3952440000 3952449999
3952450000 3952454049
3952454150
3952490000
3952690000

with t as (
select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool)
select * from t
where beg between 3012285000 and 3012285899

3012285000	3012285499 --��������
3012285000  3012285899 --IUM

begin
  for rec in (select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)) loop
    for rec1 in (select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 not like 'D%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)) loop
      if rec.beg between rec1.value_1 and rec1.value_2 then 
        if rec.en between rec1.value_1 and rec1.value_2 then
        dbms_output.put_line(rec.beg||' '||rec.en);
        else
        dbms_output.put_line(rec.beg);
       end if;
      end if;
    end loop;
  end loop;
end;



-----�����
select * from aak_number_pool_values t
where t.rowid in (select rw from (select rowid as rw,
min(rowid) over(partition by npol_npol_id, nplt_nplt_id, zone_zone_id, number_ton, value_1, value_2, start_date, end_date) as min_rw
from aak_number_pool_values
) where rw <> min_rw)



declare
v_ varchar2(100);
v_pool number(10) := 1;
type record_type is RECORD (val1 VARCHAR2(50), val2 VARCHAR2(50));
begin 
---create table aak_tmp (number_id number(30));
  execute immediate 'truncate table aak_tmp';
  for rec in (select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 not like 'D%') loop
---��������� ��������� ����������� uniq_id �� �������� IUM � aak_number_pool_values
insert into aak_tmp select uniq_id from aak_number_pool_values where value_1 = rec.beg and value_2 = rec.en;

  end loop;
  for rec2 in (select value_1, value_2, uniq_id from aak_number_pool_values where end_date > sysdate and uniq_id not in (select number_id From aak_tmp) and value_1 not like 'D%') loop
/*        select uniq_id into v_pool from aak_number_pool_values where v_pref between value_1 and value_2;
        if v_pool is not null then
          dbms_output.put_line(rec.value_1 || ' ������ � �������� aak_number_pool_values.UNIQ_ID='||v_pool);
        end if;
        EXCEPTION WHEN NO_DATA_FOUND THEN
          dbms_output.put_line(rec.value_1 || ' �� ������ �� � 1 �������� aak_number_pool_values');
        end;*/

  end loop;
end loop;
end;








select * From aak_tmp
---4604
---35764


select distinct uniq_id from aak_number_pool_values where value_1 in (
select (case when beginn like '7%' then substr(beginn,2) end) beg From aak_number_pool
INTERSECT
select value_1 from aak_number_pool_values where end_date > sysdate)
and value_2 in (
select (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool
INTERSECT
select value_2 from aak_number_pool_values where end_date > sysdate
)
;







-----[][][][][][][][][][][][]




select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 like '381%'
----543


select * from aak_number_pool_values where value_1 like '381%';
--596
select * from aak_number_pool where beginn like '7381%';
--663

---����������� ��� � IUM 1147
select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 like '381%');
----120
---����������� ��� � �������� 35792
--select value_1, value_2 from aak_number_pool_values where end_date > sysdate and uniq_id not in (select number_id From aak_tmp) and value_1 not like 'D%'
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 not like 'D%' and value_1 like '381%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 like '381%');
----53









select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 like '381%')








create table aak_number_pool_tmp as 
with t as (
 select (case when beginn like '7%' then substr(beginn,2) end) beg From aak_number_pool where beginn like '7381%'
minus
(select (case when beginn like '7%' then substr(beginn,2) end) beg From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_1 from aak_number_pool_values where end_date > sysdate and value_1 like '381%')
union all
select (case when endd like '7%' then substr(endd,2) end) beg From aak_number_pool where beginn like '7381%'
minus
(select (case when endd like '7%' then substr(endd,2) end) beg From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_2 from aak_number_pool_values where end_date > sysdate and value_1 like '381%')
          ),
     x as (
           select  regexp_replace(beg,'\d+$') alpha,
                   to_number(regexp_replace(beg,'^[[:alpha:]]+')) num
             from  t
             where beg is not null
          ),
     y as (
           select  num,
                   alpha || (num - row_number() over(partition by alpha order by num)) grp
             FROM  x
          )
select  --rtrim(xmlagg(xmlelement(i,min(alpha) || min(num) || '-' || min(alpha) || max(num),',').extract('//text()') order by grp),',') grp_list
num, grp, count(num) OVER (PARTITION BY grp) count_num  
from y
--group by grp

--create table aak_number_pool_2 as select * from aak_number_pool where 1=2
---create table aak_number_pool_2 as select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'

---drop table aak_number_pool_2
select * from aak_number_pool_2
select * from aak_number_pool_tmp

select min(num), max(num) from aak_number_pool_tmp where count_num > 1
group by grp

begin 
  for rec in (with t as (select min(num) a , max(num) b from aak_number_pool_tmp where count_num > 1 group by grp) select * from t) loop
    execute immediate 'update aak_number_pool_2 set en = '|| rec.b ||' where en between '|| rec.a||' and '||rec.b;
    execute immediate 'update aak_number_pool_2 set beg = '||rec.b ||' where beg between '|| rec.a||' and '||rec.b;
  end loop;
end;

3812220000	3812220107
3812220108	3812220108
3812220109	3812220110
3812220111	3812220111
3812220112	3812271999

3812220000	3812220112
3812220112	3812220112
3812220112	3812220112
3812220112	3812220112
3812220112	3812271999

select distinct * from aak_number_pool_2 order by beg

begin
  for rec in (select distinct * from aak_number_pool_2 order by beg) loop
    
  for rec1 in (select distinct beg from aak_number_pool_2 where beg = rec.en) loop
      execute immediate 'update aak_number_pool_2 set beg = '||rec.beg||' where beg = '||rec.en;
  end loop;
  end loop;
end;

3812220000	3812220112
3812220000	3812271999

select distinct beg, max(en) from aak_number_pool_2
group by beg
order by beg

3812220000	3812271999

select (case when beginn like '7%' then substr(beginn,2) end) beg, (case when endd like '7%' then substr(endd,2) end) en From aak_number_pool where beginn like '7381%'
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate and value_1 like '381%';
---543

with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select * from t 
join aak_number_pool_values on beg = value_1
where en = value_2
---575



select * from aak_number_pool_values where value_1 like '381%' 
and uniq_id not in (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select uniq_id from t 
join aak_number_pool_values on beg = value_1
where en = value_2);
--596 - 21
select * from aak_number_pool_2 where beg like '381%';
--663


select distinct * from aak_number_pool_2 where beg like '381%' and beg between
'3812289000' and	'3812289299'


select * from aak_number_pool_2 
outer join (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select value_1, value_2 from t 
join aak_number_pool_values on beg = value_1
where en = value_2) t  on beg = t.value_1
where beg like '381%' and en != t.value_2
;
---35 ������� � ������� EN > VALUE_2

begin
  for rec in (select * from aak_number_pool_2 
outer join (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select value_1, value_2 from t 
join aak_number_pool_values on beg = value_1
where en = value_2) t  on beg = t.value_1
where beg like '381%' and en != t.value_2) loop
    if (rec.beg = rec.value_1 and rec.en < rec.value_2 )then
      execute immediate 'update aak_number_pool_2 set en = '|| rec.value_2||' where beg = '|| rec.beg;
    elsif (rec.beg = rec.value_1 and rec.en > rec.value_2 ) then
      execute immediate 'update aak_number_pool_2 set value_2 = '|| rec.en||' where beg = '|| rec.beg;---�������� �� number_pool
    end if;
  end loop;
end;

---��������� ��� 35 �������
select * from aak_number_pool_2 
outer join (with t as (
select * From aak_number_pool_2
INTERSECT
select distinct value_1, value_2 from aak_number_pool_values where end_date > sysdate)
select value_1, value_2 from t 
join aak_number_pool_values on beg = value_1
where en = value_2) t  on beg = t.value_1
and beg like '381%' and en != t.value_2
--and beg like '3816554100'
---��������� = �����

---��������������� ������, ���� ���������
select * from aak_number_pool_2 as of scn timestamp_to_scn(sysdate-INTERVAL '1000' SECOND)

select * from aak_number_pool_2 for update

select (sysdate-INTERVAL '900' SECOND) from dual


---������� 50 �������, ������� ��� � aak_number_pool_values
select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate)


---13 �������, � ������� ��������� VALUE_2 � EN, �� ������ BEGIN
with t as (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate))
select * from t
join aak_number_pool_values on en = value_2
and beg != value_1


begin
  for rec in (with t as (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate))
select * from t
join aak_number_pool_values on en = value_2
and beg != value_1) loop
if rec.beg > rec.value_1 then
    execute immediate 'update aak_number_pool_2 set beg = '|| rec.value_1 ||' where en = '||rec.value_2;
end if;
  end loop;
end;

---������� 37 �������, ������� ��� � aak_number_pool_values
select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate)


3812366914	3812370005
3812360000	3812377999



select * from aak_number_pool_values where end_date > sysdate
and '3812366914' between value_1 and value_2

begin
  for rec in (with t as (select distinct * From aak_number_pool_2
minus 
(select distinct * From aak_number_pool_2
INTERSECT
select value_1, value_2 from aak_number_pool_values where end_date > sysdate))
select * from t
join aak_number_pool_values on beg = value_1
and en != value_2) loop
    if (rec.beg = rec.value_1 and rec.en < rec.value_2) then
      execute immediate 'update aak_number_pool_2 set en = '|| rec.value_2 ||' where beg ='|| rec.beg;
    elsif (rec.beg = rec.value_1 and rec.en > rec.value_2) then
      execute immediate 'update aak_number_pool_values set value_2 = '||rec.en||' where value_1 = ''3816221000''';--�������� �� number_pool
    end if;
  end loop;
end;












