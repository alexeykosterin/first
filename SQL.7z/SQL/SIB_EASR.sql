create or replace package SIB_EASR is
  procedure RATE_PLAN_CLONE(P_OLD_RTPL_ID in number,
                            P_NAME        RATE_PLANS.NAME_R%TYPE,
                            P_NAVI_USER   RATE_PLANS.NAVI_USER%TYPE,
                            P_RTPL_ID     OUT NUMBER);
  procedure PACK_CLONE(P_PACK_NAME       IN PACKS.NAME_R%TYPE,
                       P_NAVI_USER       IN BIS.TARIF_HISTORIES.NAVI_USER%TYPE,
                       P_PACK_PROTOTYPE  IN BIS.PACKS.PACK_ID%TYPE,
                       P_AVAIL_DATE      IN BIS.PACKS.AVAIL_DATE%TYPE default NULL,
                       P_PACK_ID         OUT NUMBER,
                       P_EXPIRE_DATE     IN BIS.PACKS.EXPIRE_DATE%TYPE DEFAULT to_date('31.12.2999',
                                                                                       'dd.mm.yyyy'),
                       P_DURATION_DAYS   IN BIS.PACKS.DURATION_DAYS%TYPE DEFAULT NULL,
                       P_DURATION_MONTH  IN BIS.PACKS.DURATION_MONTHS%TYPE DEFAULT NULL,
                       P_PTYP_ID         IN BIS.PACKS.PTYP_PTYP_ID%TYPE DEFAULT NULL,
                       P_NEW_PTYP_NAME   IN PACK_TYPES.DEF%TYPE DEFAULT NULL,
                       P_TARIF_COPY      IN VARCHAR2 DEFAULT 'Y',
                       P_TRAFIC_COPY     IN VARCHAR2 DEFAULT 'Y',
                       P_NEW_PRICE_W_TAX IN BIS.PRICE_ITEMS.PRICE_$_WITH_TAX%TYPE DEFAULT NULL,
                       P_ZONE_ID         IN NUMBER DEFAULT NULL);
end SIB_EASR;
/
CREATE OR REPLACE package BODY SIB_EASR is
  procedure RATE_PLAN_CLONE(P_OLD_RTPL_ID in number,
                            P_NAME        RATE_PLANS.NAME_R%TYPE,
                            P_NAVI_USER   RATE_PLANS.NAVI_USER%TYPE,
                            P_RTPL_ID     OUT NUMBER) IS
    warning varchar2(150);
    val     number(10);
    v_cnt   number(10) := 0;
  BEGIN
    P_RTPL_ID := BIS.RTPL_SEQ.NEXTVAL;
    insert into BIS.RATE_PLANS2 ---�������� ��� ����
      (RTPL_ID,
       NUMBER_HISTORY,
       SCLS_SCLS_ID,
       NAME_E,
       NAME_R,
       NAME_1,
       NAME_2,
       START_DATE,
       END_DATE,
       NAVI_USER,
       NAVI_DATE,
       TRAF_BY_DIR_#,
       CTYP_CTYP_ID,
       CCAT_CCAT_ID,
       CUR_CUR_ID,
       STND_STND_ID,
       XTYP_XTYP_ID,
       RPTP_RPTP_ID,
       ACTIVE_START,
       ACTIVE_END,
       IS_COMPLECT,
       BRNC_BRNC_ID,
       IS_EQUIPMENT,
       FLAG_MIX,
       FLAG_ALL_STND,
       FLAG_ADD_EQPM,
       ALL_QUANTITY_EQPM,
       RECURRING_FLAG)
      SELECT P_RTPL_ID,
             1,
             SCLS_SCLS_ID,
             'quick search',
             P_NAME,
             NAME_1,
             NAME_2,
             TRUNC(SYSDATE),
             END_DATE,
             P_NAVI_USER,
             SYSDATE,
             TRAF_BY_DIR_#,
             CTYP_CTYP_ID,
             CCAT_CCAT_ID,
             CUR_CUR_ID,
             STND_STND_ID,
             XTYP_XTYP_ID,
             RPTP_RPTP_ID,
             TRUNC(SYSDATE),
             ACTIVE_END,
             IS_COMPLECT,
             BRNC_BRNC_ID,
             IS_EQUIPMENT,
             FLAG_MIX,
             FLAG_ALL_STND,
             FLAG_ADD_EQPM,
             ALL_QUANTITY_EQPM,
             RECURRING_FLAG
        from rate_plans
       where RTPL_ID = P_OLD_RTPL_ID;
    insert into BIS.tarif_histories2 ---�������� ��� ����
      (RTPL_RTPL_ID,
       NUMBER_HISTORY,
       SRLS_SRLS_ID,
       RNDT_RNDT_ID,
       MTCG_MTCG_ID,
       FIRST_RATE,
       MONTH_RATE,
       WARNING_$,
       BREAK_$,
       START_DATE,
       END_DATE,
       NAVI_USER,
       NAVI_DATE,
       XPNS_XPNS_ID,
       PACK_PACK_ID,
       MIN_VOLUME,
       MAX_VOLUME,
       MSRU_MSRU_ID,
       CUR_CUR_ID,
       XTYP_XTYP_ID,
       TRAF_BY_DIR_#,
       TAX_INCLUDED,
       TAX_TAX_ID,
       REALTIME_YN,
       ACTIVATE_$,
       MAIN_YN,
       TARIF_MODIFY,
       RATE_FOR_ONE_DAY,
       RT_BREAK_$,
       PACK_ORDER_CONNECT,
       PACK_REVOKE_DISCONNECT,
       EVAL_DISC_RATE,
       EVAL_DISC_DAYS,
       TAX_RATE,
       FEE_TAX_INCLUDED,
       FEE_WARNING_$,
       FEE_BREAK_$,
       FEE_ACTIVATE_$,
       FEE_PRIORITY_YN,
       FLOOR_CALC_TYPE,
       FLOOR_VALUE,
       FLOOR_PRICE_$,
       TVTP_TVTP_ID,
       ADVANCE_RATE,
       FLAG_CS)
      select distinct P_RTPL_ID,
                      (case
                        when TRUNC(SYSDATE) >= START_DATE THEN
                         1
                        else
                         NUMBER_HISTORY
                      end),
                      SRLS_SRLS_ID,
                      RNDT_RNDT_ID,
                      MTCG_MTCG_ID,
                      FIRST_RATE,
                      MONTH_RATE,
                      WARNING_$,
                      BREAK_$,
                      TRUNC(SYSDATE),
                      END_DATE,
                      P_NAVI_USER,
                      SYSDATE,
                      XPNS_XPNS_ID,
                      PACK_PACK_ID,
                      MIN_VOLUME,
                      MAX_VOLUME,
                      MSRU_MSRU_ID,
                      CUR_CUR_ID,
                      XTYP_XTYP_ID,
                      TRAF_BY_DIR_#,
                      TAX_INCLUDED,
                      TAX_TAX_ID,
                      REALTIME_YN,
                      ACTIVATE_$,
                      MAIN_YN,
                      TARIF_MODIFY,
                      RATE_FOR_ONE_DAY,
                      RT_BREAK_$,
                      PACK_ORDER_CONNECT,
                      PACK_REVOKE_DISCONNECT,
                      EVAL_DISC_RATE,
                      EVAL_DISC_DAYS,
                      TAX_RATE,
                      FEE_TAX_INCLUDED,
                      FEE_WARNING_$,
                      FEE_BREAK_$,
                      FEE_ACTIVATE_$,
                      FEE_PRIORITY_YN,
                      FLOOR_CALC_TYPE,
                      FLOOR_VALUE,
                      FLOOR_PRICE_$,
                      TVTP_TVTP_ID,
                      ADVANCE_RATE,
                      FLAG_CS
        from tarif_histories
       where rtpl_rtpl_id = P_OLD_RTPL_ID
         and end_date > sysdate;
    INSERT INTO BIS.rtpl_srls_substitution2
      (SRLS_SRLS_ID,
       SOURCE_RTPL_ID,
       RESULT_RTPL_ID,
       START_DATE,
       END_DATE,
       NAVI_USER,
       NAVI_DATE)
      select SRLS_SRLS_ID,
             P_RTPL_ID,
             RESULT_RTPL_ID,
             TRUNC(SYSDATE),
             END_DATE,
             P_NAVI_USER,
             SYSDATE
        from rtpl_srls_substitution
       where SOURCE_RTPL_ID = P_OLD_RTPL_ID
         and end_date > sysdate;
    insert into BIS.TRAFIC_HISTORIES2 ---�������� ��� ����
      (SRLS_SRLS_ID,
       ZNTP_ZNTP_ID,
       NUMBER_HISTORY,
       TMCL_TMCL_ID,
       BSS_BSS_ID,
       ZONE_ZONE_ID,
       LCAL_LCAL_ID,
       RTPL_RTPL_ID,
       PACK_PACK_ID,
       PSET_PSET_ID,
       PRICE_$,
       PSET_COST_$,
       CONNECTION_$,
       FUNCTION_NAME,
       START_DATE,
       END_DATE,
       NAVI_USER,
       NAVI_DATE,
       FAFT_FAFT_ID,
       SCPR_SCPR_ID,
       RTGR_RTGR_ID,
       PTTP_PTTP_ID,
       COU_COU_ID,
       RMOP_RMOP_ID,
       AOB_AOB_ID,
       RTCM_RTCM_ID,
       VUNT_VUNT_ID,
       FLAG_CS,
       TFRG_TFRG_ID,
       HOME_TFRG_ID,
       HOME_RMOP_ID,
       RMTP_RMTP_ID,
       ACTN_ACTN_ID,
       MUNT_MUNT_ID,
       MSRU_MSRU_ID)
      select distinct srls_srls_id,
                      zntp_zntp_id,
                      (case
                        when trunc(sysdate) > start_date then
                         1
                        else
                         number_history
                      end) NUMBER_HISTORY,
                      TMCL_TMCL_ID,
                      BSS_BSS_ID,
                      ZONE_ZONE_ID,
                      LCAL_LCAL_ID,
                      P_RTPL_ID,
                      PACK_PACK_ID,
                      PSET_PSET_ID,
                      PRICE_$,
                      PSET_COST_$,
                      CONNECTION_$,
                      FUNCTION_NAME,
                      (case
                        when TRUNC(SYSDATE) < START_DATE then
                         start_date
                        else
                         TRUNC(SYSDATE)
                      end) START_DATE,
                      END_DATE,
                      P_NAVI_USER,
                      SYSDATE,
                      FAFT_FAFT_ID,
                      SCPR_SCPR_ID,
                      RTGR_RTGR_ID,
                      PTTP_PTTP_ID,
                      COU_COU_ID,
                      RMOP_RMOP_ID,
                      AOB_AOB_ID,
                      RTCM_RTCM_ID,
                      VUNT_VUNT_ID,
                      FLAG_CS,
                      TFRG_TFRG_ID,
                      HOME_TFRG_ID,
                      HOME_RMOP_ID,
                      RMTP_RMTP_ID,
                      ACTN_ACTN_ID,
                      MUNT_MUNT_ID,
                      MSRU_MSRU_ID
        from trafic_histories
       where rtpl_rtpl_id = P_OLD_RTPL_ID
         and END_DATE > SYSDATE;
    select count(1)
      into val
      from trafic_histories
     where rtpl_rtpl_id = P_OLD_RTPL_ID
       and tmcl_tmcl_id not in (0, 1); ---���� ����� �� ������� � ������� ����
    if val = 0 then
      warning := '�������������� ������ � time_classes �� ���������';
    end if;
    if val > 0 then
      warning := '��������� �������������� ������ � time_classes ��� trafic_histories';
    end if;

    ------TMCL_SEQ ������ ��� tmcl_id/time_classes, �� �� ������������; ���� ���� ����� �����, ���� ������������ TMCL_ID ����������� (��� ��� ���������� � ����� ����������� � TMCL �� ������� ��) + �������� TMCL_ID ��� times;
    /*if val > 0 then
    begin
      for rec in (select * from time_classes where tmcl_id not in (0, 1)
    and rtpl_rtpl_id = P_OLD_RTPL_ID) loop
    insert into bis.time_classes2  ---�������� ��� �����
          (TMCL_ID,
           DEF,
           DEF_E,
           DEF_1,
           DEF_2,
           RTPL_RTPL_ID,
           RPDR_RPDR_ID,
           OPER_OPER_ID,
           ODRC_ODRC_ID,
           NAVI_USER,
           NAVI_DATE,
           DCPL_DCPL_ID)
          select distinct (select nvl(max(tmcl_id)+1,0) from time_classes2) TMCL_ID,
                DEF,
                DEF_E,
                DEF_1,
                DEF_2,
                P_RTPL_ID,
                RPDR_RPDR_ID,
                OPER_OPER_ID,
                ODRC_ODRC_ID,
                P_NAVI_USER,
                SYSDATE,
                DCPL_DCPL_ID
            from time_classes
           where tmcl_id not in (0, 1)
             and rtpl_rtpl_id = 217
             ORDER BY TMCL_ID
             OFFSET v_cnt ROWS FETCH NEXT 1 ROWS ONLY;
             v_cnt:=v_cnt+1;
            -- dbms_output.put_line(v_cnt);
             commit;
    end loop;
    end;
      end if;*/
    dbms_output.put_line(warning);
    insert into bis.rtpl_ntyp2 ---�������� ��� ����
      (RTPL_RTPL_ID, NCAT_NCAT_ID, NTYP_NTYP_ID)
      select P_RTPL_ID, NCAT_NCAT_ID, NTYP_NTYP_ID
        from rtpl_ntyp
       where rtpl_rtpl_id = P_OLD_RTPL_ID;
    insert into pack_rtpl2 ---�������� ��� ����
      (PACK_PACK_ID, RTPL_RTPL_ID, DEL_DATE)
      select PACK_PACK_ID, P_RTPL_ID, DEL_DATE
        from pack_rtpl T1
       where rtpl_rtpl_id = P_OLD_RTPL_ID
         and DEL_DATE > SYSDATE
         and pack_pack_id in
             (select pack_id from packs where rtpl_rtpl_id = 0)
         and not exists (select 1
                from pack_rtpl
               where rtpl_rtpl_id = P_RTPL_ID
                 and pack_pack_id = T1.Pack_Pack_Id);
    insert into bis.dcpl_rtpl_histories2
      (DCPL_DCPL_ID, RTPL_RTPL_ID, START_DATE, END_DATE, UNIQ_ID)
      select DCPL_DCPL_ID, P_RTPL_ID, TRUNC(SYSDATE), END_DATE, NULL
        from dcpl_rtpl_histories T3
       where rtpl_rtpl_id = P_OLD_RTPL_ID
         and not exists (select 1
                from pack_rtpl T1, discount_plans T2
               where t1.rtpl_rtpl_id = P_RTPL_ID
                 and T1.Pack_Pack_Id = t2.pack_pack_id
                 and t2.rtpl_rtpl_id = 0
                 and t2.dcpl_id = t3.dcpl_dcpl_id)
         and not exists (select 1
                from dcpl_rtpl_histories
               where rtpl_rtpl_id = P_RTPL_ID
                 and dcpl_dcpl_id = t3.dcpl_dcpl_id);
  end RATE_PLAN_CLONE;
  procedure PACK_CLONE(P_PACK_NAME       IN PACKS.NAME_R%TYPE,
                       P_NAVI_USER       IN BIS.TARIF_HISTORIES.NAVI_USER%TYPE,
                       P_PACK_PROTOTYPE  IN BIS.PACKS.PACK_ID%TYPE,
                       P_AVAIL_DATE      IN BIS.PACKS.AVAIL_DATE%TYPE default NULL,
                       P_PACK_ID         OUT NUMBER,
                       P_EXPIRE_DATE     IN BIS.PACKS.EXPIRE_DATE%TYPE DEFAULT to_date('31.12.2999',
                                                                                       'dd.mm.yyyy'),
                       P_DURATION_DAYS   IN BIS.PACKS.DURATION_DAYS%TYPE DEFAULT NULL,
                       P_DURATION_MONTH  IN BIS.PACKS.DURATION_MONTHS%TYPE DEFAULT NULL,
                       P_PTYP_ID         IN BIS.PACKS.PTYP_PTYP_ID%TYPE DEFAULT NULL,
                       P_NEW_PTYP_NAME   IN PACK_TYPES.DEF%TYPE DEFAULT NULL,
                       P_TARIF_COPY      IN VARCHAR2 DEFAULT 'Y',
                       P_TRAFIC_COPY     IN VARCHAR2 DEFAULT 'Y',
                       P_NEW_PRICE_W_TAX IN BIS.PRICE_ITEMS.PRICE_$_WITH_TAX%TYPE DEFAULT NULL,
                       P_ZONE_ID         IN NUMBER DEFAULT NULL) AS
    V_PTYP_ID BIS.PACK_TYPES.PTYP_ID%TYPE := P_PTYP_ID;
    ---V_PACK_ID BIS.PACKS.PACK_ID%TYPE := BIS.PACK_SEQ.NEXTVAl; --- ���������, ���� ������� �� PACK_SEQ; ������ ����� ������ ��� ������ 2*
    V_PACK_ID BIS.PACKS.PACK_ID%TYPE;
    V_PRCL_ID BIS.PRICE_LIST.PRCL_ID%TYPE;
  begin
    ---2* start
    select pack_id + 1
      into V_PACK_ID
      from (SELECT pack_id, LEAD(pack_id) over(order by pack_id) LAST_NUM
              FROM packs)
     where pack_id + 1 != LAST_NUM
     ORDER BY pack_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
    if V_PACK_ID is NULL then
      select max(pack_id) + 1 into V_PACK_ID from packs;
    end if;
    ---2* end
    IF NVL(P_PTYP_ID, NULL) IS NULL THEN
      ---V_PTYP_ID := BIS.PTYP_SEQ.NEXTVAl; --- ���������, ���� ������� �� PTYP_SEQ; ������ ����� ������ ��� ������ 3*
      ----3* start
      select ptyp_id + 1
        into V_PTYP_ID
        from (SELECT ptyp_id, LEAD(ptyp_id) over(order by ptyp_id) LAST_NUM
                FROM pack_types)
       where ptyp_id + 1 != LAST_NUM
       ORDER BY ptyp_id OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
      ----3* end
      if V_PTYP_ID is NULL then
        select max(ptyp_id) + 1 into V_PTYP_ID from PACK_TYPES;
      end if;
      ------------
      insert into bis.pack_types2
        (PTYP_ID, DEF, TARIF_MODIFY)
      values
        (V_PTYP_ID,
         case when P_NEW_PTYP_NAME IS NULL THEN P_PACK_NAME ELSE
         P_NEW_PTYP_NAME end,
         'Y');
    end if;
    ------------
    INSERT INTO BIS.PACKS2
      (PACK_ID,
       RTPL_RTPL_ID,
       NAME_E,
       NAME_R,
       EXPIRE_DATE,
       NAVI_USER,
       NAVI_DATE,
       PTYP_PTYP_ID,
       AVAIL_DATE,
       DURATION_LIMIT_DATE,
       DURATION_MONTHS,
       DURATION_DAYS,
       POTY_POTY_ID,
       CHECK_RTPL_CHARGE)
    VALUES
      (V_PACK_ID,
       0,
       BIS.TRANSLIT(P_PACK_NAME || Case when P_ZONE_ID IS NOT NULL THEN
                    (SELECT '(' || DEF || ')'
                       from BIS.ZONES
                      where ZONE_ID = P_ZONE_ID) END),
       P_PACK_NAME || case when P_ZONE_ID IS NOT NULL THEN
       (SELECT '(' || DEF || ')' FROM BIS.ZONES where zone_id = P_ZONE_ID) end,
       P_EXPIRE_DATE,
       P_NAVI_USER,
       SYSDATE,
       V_PTYP_ID,
       P_AVAIL_DATE,
       P_EXPIRE_DATE,
       CASE WHEN P_DURATION_MONTH IS NOT NULL THEN P_DURATION_MONTH
       when(P_DURATION_DAYS IS NOT NULL and P_DURATION_MONTH IS NULL) then 0 else NULL end,
       CASE WHEN P_DURATION_DAYS IS NOT NULL THEN P_DURATION_DAYS
       when(P_DURATION_MONTH IS NOT NULL AND P_DURATION_DAYS IS NULL) then 0 else NULL end,
       1,
       0)
    returning pack_id INTO P_PACK_ID;
    dbms_output.put_line(P_PACK_ID);
    ------------
    INSERT INTO BIS.PACK_RTPL2
      (PACK_PACK_ID, RTPL_RTPL_ID, DEL_DATE)
      select V_PACK_ID, RTPL_RTPL_ID, DEL_DATE
        from BIS.PACK_RTPL
       where PACK_PACK_ID = P_PACK_PROTOTYPE
         and DEL_DATE > SYSDATE;
    IF NVL(P_TARIF_COPY, 'N') = 'Y' THEN
      ------------
      INSERT INTO BIS.TARIF_HISTORIES2
        (RTPL_RTPL_ID,
         NUMBER_HISTORY,
         SRLS_SRLS_ID,
         RNDT_RNDT_ID,
         MTCG_MTCG_ID,
         FIRST_RATE,
         MONTH_RATE,
         WARNING_$,
         BREAK_$,
         START_DATE,
         END_DATE,
         NAVI_USER,
         NAVI_DATE,
         XPNS_XPNS_ID,
         PACK_PACK_ID,
         MIN_VOLUME,
         MAX_VOLUME,
         MSRU_MSRU_ID,
         CUR_CUR_ID,
         XTYP_XTYP_ID,
         TRAF_BY_DIR_#,
         TAX_INCLUDED,
         TAX_TAX_ID,
         REALTIME_YN,
         ACTIVATE_$,
         MAIN_YN,
         TARIF_MODIFY,
         RATE_FOR_ONE_DAY,
         RT_BREAK_$,
         PACK_ORDER_CONNECT,
         PACK_REVOKE_DISCONNECT,
         EVAL_DISC_RATE,
         EVAL_DISC_DAYS,
         TAX_RATE,
         FEE_TAX_INCLUDED,
         FEE_WARNING_$,
         FEE_BREAK_$,
         FEE_ACTIVATE_$,
         FEE_PRIORITY_YN,
         FLOOR_CALC_TYPE,
         FLOOR_VALUE,
         FLOOR_PRICE_$,
         TVTP_TVTP_ID,
         ADVANCE_RATE,
         FLAG_CS)
        SELECT RTPL_RTPL_ID,
               1,
               SRLS_SRLS_ID,
               RNDT_RNDT_ID,
               MTCG_MTCG_ID,
               FIRST_RATE,
               MONTH_RATE,
               WARNING_$,
               BREAK_$,
               TRUNC(SYSDATE),
               P_EXPIRE_DATE,
               P_NAVI_USER,
               SYSDATE,
               XPNS_XPNS_ID,
               V_PACK_ID,
               MIN_VOLUME,
               MAX_VOLUME,
               MSRU_MSRU_ID,
               CUR_CUR_ID,
               XTYP_XTYP_ID,
               TRAF_BY_DIR_#,
               TAX_INCLUDED,
               TAX_TAX_ID,
               REALTIME_YN,
               ACTIVATE_$,
               MAIN_YN,
               TARIF_MODIFY,
               RATE_FOR_ONE_DAY,
               RT_BREAK_$,
               PACK_ORDER_CONNECT,
               PACK_REVOKE_DISCONNECT,
               EVAL_DISC_RATE,
               EVAL_DISC_DAYS,
               TAX_RATE,
               FEE_TAX_INCLUDED,
               FEE_WARNING_$,
               FEE_BREAK_$,
               FEE_ACTIVATE_$,
               FEE_PRIORITY_YN,
               FLOOR_CALC_TYPE,
               FLOOR_VALUE,
               FLOOR_PRICE_$,
               TVTP_TVTP_ID,
               ADVANCE_RATE,
               FLAG_CS
          from BIS.TARIF_HISTORIES
         where pack_pack_id = P_PACK_PROTOTYPE
           and end_date > sysdate;
    end if;
    IF NVL(P_TRAFIC_COPY, 'N') = 'Y' THEN
      ------------
      INSERT INTO BIS.TRAFIC_HISTORIES2
        (SRLS_SRLS_ID,
         ZNTP_ZNTP_ID,
         NUMBER_HISTORY,
         TMCL_TMCL_ID,
         BSS_BSS_ID,
         ZONE_ZONE_ID,
         LCAL_LCAL_ID,
         RTPL_RTPL_ID,
         PACK_PACK_ID,
         PSET_PSET_ID,
         PRICE_$,
         PSET_COST_$,
         CONNECTION_$,
         FUNCTION_NAME,
         START_DATE,
         END_DATE,
         NAVI_USER,
         NAVI_DATE,
         FAFT_FAFT_ID,
         SCPR_SCPR_ID,
         RTGR_RTGR_ID,
         PTTP_PTTP_ID,
         COU_COU_ID,
         RMOP_RMOP_ID,
         AOB_AOB_ID,
         RTCM_RTCM_ID,
         VUNT_VUNT_ID,
         FLAG_CS,
         TFRG_TFRG_ID,
         HOME_TFRG_ID,
         HOME_RMOP_ID,
         RMTP_RMTP_ID,
         ACTN_ACTN_ID,
         MUNT_MUNT_ID,
         MSRU_MSRU_ID)
        SELECT SRLS_SRLS_ID,
               ZNTP_ZNTP_ID,
               1,
               TMCL_TMCL_ID,
               BSS_BSS_ID,
               ZONE_ZONE_ID,
               LCAL_LCAL_ID,
               RTPL_RTPL_ID,
               V_PACK_ID,
               PSET_PSET_ID,
               PRICE_$,
               PSET_COST_$,
               CONNECTION_$,
               FUNCTION_NAME,
               TRUNC(SYSDATE),
               END_DATE,
               P_NAVI_USER,
               SYSDATE,
               FAFT_FAFT_ID,
               SCPR_SCPR_ID,
               RTGR_RTGR_ID,
               PTTP_PTTP_ID,
               COU_COU_ID,
               RMOP_RMOP_ID,
               AOB_AOB_ID,
               RTCM_RTCM_ID,
               VUNT_VUNT_ID,
               FLAG_CS,
               TFRG_TFRG_ID,
               HOME_TFRG_ID,
               HOME_RMOP_ID,
               RMTP_RMTP_ID,
               ACTN_ACTN_ID,
               MUNT_MUNT_ID,
               MSRU_MSRU_ID
          from BIS.TRAFIC_HISTORIES
         where PACK_PACK_ID = P_PACK_PROTOTYPE
           AND END_DATE > SYSDATE;
    END IF;
    if nvl(P_ZONE_ID, NULL) is null then
      ------------
      INSERT INTO BIS.PACK_ZONE_HISTORIES2
        (PACK_PACK_ID,
         ZONE_ZONE_ID,
         START_DATE,
         END_DATE,
         NAVI_USER,
         NAVI_DATE)
        SELECT V_PACK_ID,
               ZONE_ZONE_ID,
               TRUNC(SYSDATE),
               P_EXPIRE_DATE,
               P_NAVI_USER,
               SYSDATE
          from BIS.PACK_ZONE_HISTORIES
         where pack_pack_id = P_pack_prototype
           and end_date > sysdate;
    ELSE
      ------------
      INSERT INTO BIS.Pack_Zone_Histories2
        (PACK_PACK_ID,
         ZONE_ZONE_ID,
         START_DATE,
         END_DATE,
         NAVI_USER,
         NAVI_DATE)
      VALUES
        (V_PACK_ID,
         P_ZONE_ID,
         TRUNC(SYSDATE),
         P_EXPIRE_DATE,
         P_NAVI_USER,
         SYSDATE);
    end if;
    ------------
    INSERT INTO BIS.PACK_PRIORITY_HISTORIES2
      (PACK_PACK_ID,
       PPRI_PPRI_ID,
       START_DATE,
       END_DATE,
       NAVI_DATE,
       NAVI_USER)
      SELECT V_PACK_ID,
             PPRI_PPRI_ID,
             TRUNC(SYSDATE),
             END_DATE,
             SYSDATE,
             P_NAVI_USER
        from BIS.PACK_PRIORITY_HISTORIES2
       where pack_pack_id = P_pack_PROTOTYPE
         and end_date > sysdate;
    IF NVL(P_PTYP_ID, NULL) IS NULL THEN
      ------------
      INSERT INTO BIS.PACK_TYPES_RESTRICTIONS2
        (PTYP_PTYP_ID, PTYP_PTYP_ID_1, CHECK_RULES)
      VALUES
        (V_PTYP_ID, V_PTYP_ID, 1);
      FOR REC_PTYP in (select PTYP_PTYP_ID_1
                         from BIS.PACK_TYPES_RESTRICTIONS
                        where PTYP_PTYP_ID in
                              (select PTYP_PTYP_ID
                                 FROM BIS.PACKS
                                where PACK_ID = P_PACK_PROTOTYPE)) loop
        ------------
        insert into BIS.PACK_TYPES_RESTRICTIONS2
          (PTYP_PTYP_ID, PTYP_PTYP_ID_1, CHECK_RULES)
        values
          (REC_PTYP.PTYP_PTYP_ID_1, V_PTYP_ID, 1);
        INSERT INTO BIS.PACK_TYPES_RESTRICTIONS2
          (PTYP_PTYP_ID, PTYP_PTYP_ID_1, CHECK_RULES)
        VALUES
          (V_PTYP_ID, REC_PTYP.PTYP_PTYP_ID_1, 1);
      end loop REC_PTYP;
    end if;
    DBMS_OUTPUT.put_line('NEW PACK "' || P_PACK_NAME || '" pack_id= ' ||
                         V_PACK_ID || ' with PTYP= ' || V_PTYP_ID ||
                         ' created.');
  END PACK_CLONE;
end SIB_EASR;
/
