select * from subscribers where 1=1
and sbst_sbst_id in (2,3)
and macr_macr_id = 600

for update
and curr_zone_id = 356
--and subs_id = 7673
---select * from subs_statuses
select * from standarts
-------------------------------------------
select * from subscribers where subs_id in (7673,1129,35943) for update
select * from subs_histories
where subs_subs_id in (7673,1129,35943) for update
select * from number_sets where nset_id in (30000001,1369,18484,41331)-- for update
select * from number_set_histories where nset_nset_id in (30000001,1369,41331,18484)-- for update
select * from subs_clnt_histories where subs_subs_id in (7673,1129,35943,118186)
select * from phone_histories where subs_subs_id in (7673,1129,35943,118186)-- for update
-------------------------------------------

select * from number_sets where nset_id not in (select nset_nset_id from phone_histories)
and msisdn like '383%'


create table aak_calls (AB_LR_LEGAL_STATUS varchar2(300),	AB_ACCOUNT varchar2(300),	AB_ID number(30),	US_UC_CODE varchar2(300),	US_TFP_CODE varchar2(300),	
US_USER_NAME varchar2(300),
TWSC_SESSION_DATE date,	TWSC_SESSION_TIME	number(30,8),
TWSC_SESSION_ID varchar2(300),	TWSC_CALLING_STATION varchar2(300),	TWSC_CALLED_STATION varchar2(300),	TWSC_INPUTOCTETS number(30),	
TWSC_OUTPUTOCTETS number(30),	TWSC_LOGNAME varchar2(300),	TWSC_COST number(30,8)
)

select * from aak_calls for update



select AB_ID as subs_subs_id, US_TFP_CODE as rtpl_id,  (TWSC_INPUTOCTETS+TWSC_INPUTOCTETS) as duration, TWSC_COST as price from aak_calls




with t as (
select AB_ID as subs_subs_id, US_TFP_CODE as pack_pack_id, (TWSC_INPUTOCTETS+TWSC_INPUTOCTETS) as duration, 
ADD_MONTHS(trunc(TWSC_SESSION_DATE,'HH'),+1) as start_date, TWSC_COST as price, 
(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%D%' then 12
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end) as rtgr_rtgr_id
from aak_calls)
select subs_subs_id,
(case 
when pack_pack_id like '%70060' then 3723 
when pack_pack_id like '%70061' then 3719 
when pack_pack_id like '%70063' then 3721 
when pack_pack_id like '%70066' then 3726
when pack_pack_id like '%70068' then 3731
when pack_pack_id like '%700500' then 3731 
when pack_pack_id like '%700510' then 3723 
end)
as pack_pack_id, start_date, rtgr_rtgr_id
, sum(duration), round(sum(price),2) from t rr
where rr.duration > 0
and subs_subs_id = 1249570
--and to_char(start_date, 'hh24') between 1 and 8
group by subs_subs_id, pack_pack_id, start_date,rtgr_rtgr_id
order by start_date









NSK_Z99_D_M 12
NSK_Z99_N_M 13
NSK_Z01_FULL 11
NSK_Z00_FULL 27
STC_Z77_U_FULL 33

select * from rating_groups
where def like '%Z99%'

70,,4224,,,3832111111,internet,20180809,1000000,,,,,,,07,07,,,,,,,,,,,14,,,,,,,,,,,,,,




c 1 �� 8
select TRUNC(sysdate, 'HH') from dual

SELECT to_char(sysdate, 'yyyymmddhh24miss') FROM dual


select * from aak_calls
where ab_id = 1249570



select * from discount_plans where pack_pack_id = 3731

select * from discount_threads where dcpl_dcpl_id = 365





select * from packs where name_r like 'Webstre%'
and navi_user like '%AAK%'






