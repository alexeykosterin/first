
SELECT * FROM TABLE (stc_deb_online.gGetDecodeCalcOnline(11278846680,271004000209,to_date('05092018','ddmmyyyy'),11350694537))




select (select name from t_svc_ref@billnsk r where r.svc_id = s.svc_id), 
(select service_type_id from t_svc_ref@billnsk r where r.svc_id = s.svc_id), s.* 
from t_services@billnsk s
where s.user_id = (select user_id from t_users@billnsk where account = '654000073649')
and svc_id = 105143 


select * from t_vendors
select * from t_vnd_cod_rtk
