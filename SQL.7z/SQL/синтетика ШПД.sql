select * From SUBS_BRD_IDENTIFICATIONS where navi_user not like '%1165%'


select * from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS where navi_user like '%1165%') --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')



select distinct pack_pack_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS where navi_user like '%1165%') --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')


AAK_CDR3723
AAK_CDR3870
AAK_CDR3719
AAK_CDR3720
AAK_CDR3731
AAK_CDR3721

-----����
3719 Webstream 200 �� (��) ---
3720 Webstream 500 �� (��) ---
3721 Webstream 1000 �� (��)
3723 Webstream 100 �� (��) --- ������ RTGR = 30
3724 Webstream 5000 �� (��) ---
3726 Webstream 10000 �� (��)
3731 Webstream 50 �� ����������� (��)
3870 Webstream Drive "���������"
-----���
3722 Webstream 3000 �� (��)
3725 Webstream 7500 �� (��)
3727 Webstream 12000 �� (��)
3728 Webstream 30000 �� (��)
3729 Webstream 50000 �� (��)
3730 Webstream 100000 �� (��)

145815
145816
145817
145818
145819
145820
145821
145822
145823
145824
145825
145826
145827
145828


----------------------1)
----������
declare
v_cnt number(30);
v_cnt1 number(10);
v_cnt2 number(10);
v_cnt3 number(30);
table_not_exists exception;
pragma exception_init(table_not_exists,-942);
begin
execute immediate 'drop table aak_sintetic2 purge';
execute immediate 'truncate table aak_sintetic';
  for rec1 in (select distinct subs_subs_id, pack_pack_id from subs_packs where subs_subs_id in (select subs_subs_id From SUBS_BRD_IDENTIFICATIONS) --where navi_user like '%1165%')
and end_date > sysdate
and pack_pack_id in (select pack_id from packs where name_r like '%Webstrea%' and navi_user like '%AAK%')
) loop 
--50
if rec1.pack_pack_id in (3870,3731) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(0, 10)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--100_200_500
elsif rec1.pack_pack_id in (3723,3719,3720) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(100, 150)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--1000_3000
elsif rec1.pack_pack_id in (3721,3722) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(100, 300)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--7500_12000_30000
elsif rec1.pack_pack_id in (3725,3727,3728) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(100, 300)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
--50000_100000
elsif rec1.pack_pack_id in (3729,100000) then
for rec2 in 1..200 loop
SELECT trunc(dbms_random.VALUE(100, 300)) into v_cnt FROM dual;
insert into aak_sintetic (subs_id, duration, pack_id) select rec1.subs_subs_id, v_cnt*1048576, rec1.pack_pack_id from dual;
end loop;
end if;
select count(1) into v_cnt1 from aak_sintetic
where subs_id = rec1.subs_subs_id;
v_cnt1 := round(v_cnt1/10,0);
v_cnt2 := v_cnt1;
update aak_sintetic set DURATION = DURATION/2 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/3 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/4 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/5 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/7 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/10 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/30 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/50 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
update aak_sintetic set DURATION = DURATION/100 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = rec1.subs_subs_id ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
end loop;
commit;
begin
select count(1) into v_cnt3 from aak_sintetic;
dbms_output.put_line(v_cnt3);
dbms_output.put_line(v_cnt3);
execute immediate 'create table aak_sintetic2 as with t as (SELECT ''201808''||LPAD(trunc(dbms_random.VALUE(1, 32)), 2, ''0'')||
LPAD(trunc(dbms_random.VALUE(0, 60)), 2, ''0'')||
LPAD(trunc(dbms_random.VALUE(0, 60)), 2, ''0'') random_date 
FROM dual 
CONNECT BY LEVEL <= 500000)
select distinct random_date
from t
FETCH FIRST '|| v_cnt3 ||' ROWS ONLY';
dbms_output.put_line(v_cnt3);
end;
exception 
when table_not_exists then 
execute immediate 'create table aak_sintetic2 (id_id number(10))'
;
end;


select count(1) from aak_sintetic;
select count(1) from aak_sintetic2;

select ak.* from aak_sintetic ak
union all select ak2.random_date from aak_sintetic2 ak2


-----1835 ���������������� �����
select in_balance_$, c.* from bba_calls_00_082018 c order by start_time desc


---21270 ��
select * from aak_sintetic
where duration > 1835
order by subs_id, duration
--create table aak_sintetic (subs_id number(30), duration number(30), pack_id number(30))



select distinct pack_id from aak_sintetic



where duration > 1835
order by subs_id, duration


select /*+parallel (ut,9)*/ count(1) from user_tables ut
where lower(table_name) like 'aak_cdr%'


----------------------2)
declare
v_cnt1 number(10);
table_not_exists exception;
pragma exception_init(table_not_exists,-942);
begin
  
for rec2 in (select distinct pack_id from aak_sintetic) loop
dbms_output.put_line(v_cnt1 || rec2.pack_id);

select /*+parallel (ut,9)*/ count(1) into v_cnt1 from user_tables ut where lower(table_name) like 'aak_cdr%';
dbms_output.put_line(v_cnt1 || rec2.pack_id);
if v_cnt1 != 0 then
execute immediate 'drop table aak_cdr'||rec2.pack_id;
dbms_output.put_line(v_cnt1 || rec2.pack_id);
end if;
end loop;

for rec3 in (select distinct pack_id from aak_sintetic) loop
execute immediate 'create table aak_cdr'||rec3.pack_id||' (cdr varchar2(300))';
end loop;

for rec in (SELECT a.subs_id, original_ids, duration, pack_id, b.RANDOM_DATE
  FROM (SELECT rownum rn
          FROM dual
        CONNECT BY LEVEL <= greatest((SELECT COUNT(*) FROM aak_sintetic),
                                     (SELECT COUNT(*) FROM aak_sintetic2))) pivot,
       (SELECT rownum rn, subs_id, duration, pack_id,original_ids FROM aak_sintetic, SUBS_BRD_IDENTIFICATIONS where subs_id = subs_subs_id) a,
       (SELECT rownum rn, RANDOM_DATE FROM aak_sintetic2) b
 WHERE pivot.rn = a.rn(+) AND
       pivot.rn = b.rn(+)) loop
execute immediate
'insert into aak_cdr'||rec.pack_id||' (cdr) select ''70,,,,,,,'||rec.RANDOM_DATE||','||rec.duration||',,,,,,,07,07,,,,,,,,,,,30,,,,,,,,,0101201808021732260000060000C,10.143.58.122,,,, SID=474:475-1533199962 Framed-IP-Address=176.211.255.45 Framed-IP-Vendor=Juniper ParentSID=474,,,,,,,,,,30,,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||rec.original_ids||',,'' from dual';
end loop;
exception 
when table_not_exists then null;
end;



select * from aak_cdr3870

select * from aak_sintetic where pack_id = 3870


declare
v_cnt number(10) :=1;
begin

for rec3 in (select distinct pack_id from aak_sintetic) loop
execute immediate 'create table aak_cdr'||rec3.pack_id||' (cdr varchar2(300))';
end loop;
end;

select * from aak_cdr1

select * from aak_cdr3870


select * from aak_cdr


create table aak_cdr (cdr varchar2(400))
aak_sintetic,aak_sintetic2




with t as (SELECT '201808'||LPAD(trunc(dbms_random.VALUE(1, 32)), 2, '0')||
LPAD(trunc(dbms_random.VALUE(0, 60)), 2, '0')||
LPAD(trunc(dbms_random.VALUE(0, 60)), 2, '0') random_val 
FROM dual 
CONNECT BY LEVEL <= 100000)
select distinct random_val
from t
FETCH FIRST 1000 ROWS ONLY;











select 
'70,,,,,,,'||to_char(ADD_MONTHS(TWSC_SESSION_DATE,+1),'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,07,,,,,,,,,,,'||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end)||',,,,,,,,,0101201808021732260000060000C,10.143.58.122,,,, SID=474:475-1533199962 Framed-IP-Address=176.211.255.45 Framed-IP-Vendor=Juniper ParentSID=474,,,,,,,,,,'
||(case 
when TWSC_CALLED_STATION like '%Z01%' then 11
when TWSC_CALLED_STATION like '%Z00%' then 27
when TWSC_CALLED_STATION like '%Z77%' then 33
when TWSC_CALLED_STATION like '%Z99%' then 14
when TWSC_CALLED_STATION like '%Z99%N%' then 13
end)||',,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||
(case 
when ab_id=1139941 then 'Webstream103'
when ab_id=964159 then 'Webstream101'
when ab_id=1066354 then 'Webstream97'
when ab_id=1069417 then 'Webstream99'
when ab_id=2113725 then 'Webstream96'
when ab_id=1007791 then 'Webstream105'
when ab_id=1679362 then 'Webstream102'
when ab_id=1249570 then 'Webstream107'
when ab_id=987030 then 'Webstream92'
when ab_id=991655 then 'Webstream106'
when ab_id=1223068 then 'Webstream100'
when ab_id=1239143 then 'Webstream95'
when ab_id=2000032 then 'Webstream98'
when ab_id=995938 then 'Webstream104'
when ab_id=971705 then 'Webstream94'
when ab_id=1015970 then 'Webstream93'
end
)
||',,'
from aak_calls
order by TWSC_SESSION_DATE





























declare
v_cnt1 number(10);
v_cnt2 number(10);
begin
select count(1) into v_cnt1 from aak_sintetic
where subs_id = 145817;
v_cnt1 := round(v_cnt1/5,0);
v_cnt2 := v_cnt1;
dbms_output.put_line(v_cnt1);
update aak_sintetic set DURATION = DURATION/2 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = 145817 ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
dbms_output.put_line(v_cnt1);
update aak_sintetic set DURATION = DURATION/3 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = 145817 ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
dbms_output.put_line(v_cnt1);
update aak_sintetic set DURATION = DURATION/5 where rowid in 
(SELECT rowid FROM aak_sintetic where subs_id = 145817 ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
v_cnt1 := v_cnt1+v_cnt2;
dbms_output.put_line(v_cnt1);
update aak_sintetic set DURATION = DURATION/10 where rowid in
(SELECT rowid FROM aak_sintetic where subs_id = 145817 ORDER BY pack_id OFFSET v_cnt1 ROWS FETCH NEXT v_cnt2 ROWS ONLY);
end;

---10
---52
select * from aak_sintetic
where subs_id = 145817
order by duration desc

SELECT * FROM aak_sintetic where subs_id = 145817 ORDER BY pack_id OFFSET 40 ROWS FETCH NEXT 10 ROWS ONLY


SELECT rowid FROM   aak_sintetic where subs_id = 145817 ORDER BY pack_id OFFSET 34 ROWS FETCH NEXT 34 ROWS ONLY;
