with t as (
select 
a.ab_id,
c.US_TFP_CODE,
sc.twsc_session_date,
sc.twsc_called_station,
(case 
when sc.twsc_called_station like '%Local%' then 20
when sc.twsc_called_station like '%_X(%' then 30
when sc.twsc_called_station like '%_X_0822%' then 30
when sc.twsc_called_station like '%Internet_Sym_X(%' then 30
when sc.twsc_called_station like 'Internet' then 30
when sc.twsc_called_station like '%Internet_Sym_X_0012(%' then 35  
end) as RTGR_ID,
sc.twsc_outputoctets,
sc.twsc_logname,
TWSC_COST
from sip_w.abonent a,
sip_ibs.ct_users c,
sip_w.providers p,
sip_w.ct_users ct,
sip_w.ct_user_services us,
sip_w.tb_wtmps_session_charges sc
where a.ab_prv_id=p.prv_id
and (select prv_id from sip_w.providers ppp where CONNECT_BY_ISLEAF=1 connect by prv_id=prior prv_prv_id and prv_id<>1 start with ppp.prv_id=p.prv_id)=28
and a.ab_id=ct.us_ab_id and ct.us_user_name=us.uss_us_user_name and us.uss_sl_type='RADIUS'
and a.ab_lr_legal_status='LEGAL'
and a.ab_id = c.us_ab_id
and exists(select 1 from sip_w.tb_tariff_services ts where ts.trs_to_date is null and ts.trs_tfp_code=ct.us_tfp_code and ts.trs_base_cost<>0)
and sc.twsc_session_date between to_date('01.02.2019','dd.mm.yyyy') and to_date('28.02.2019 23:59:59','dd.mm.yyyy hh24:mi:ss')
and sc.twsc_abid=a.ab_id and sc.twsc_us_user_name=ct.us_user_name
and c.us_close_date is null
and TWSC_OUTPUTOCTETS != 0
)

select 
--ac.*,ca.IBS_CHARGE_TYPE_ID as svc_id 
'70,,,,,,,'||to_char(TWSC_SESSION_DATE,'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,00,,,,,,,,,,,'||ac.RTGR_ID||',,,,,,,,,0101201808021732260000060XXXC,XXX.XXX.XXX.XXX,,,,'||TWSC_COST||';'||ca.IBS_CHARGE_TYPE_ID||',,,,,,,,,,'
||ac.RTGR_ID||',,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||TWSC_LOGNAME||',,'
from t ac
join
(
select distinct * from (select (case 
when ABS_SRD_INT_CODE like '%Z99_D%' then 30
when ABS_SRD_INT_CODE like '%Z99_N%' then 35
when ABS_SRD_INT_CODE like '%Z77%' then 20
when ABS_SRD_INT_CODE like '%Z99_V%' then 30  
when ABS_SRD_INT_CODE like '%Z0%' then 20
when ABS_SRD_INT_CODE like '%Z99%night%' then 35
end) as RTGR_ID, a.ABS_TFP_CODE, a.IBS_CHARGE_TYPE_ID from sip_ibs.ibs_abs_serv_codes a)
where 1=1
and RTGR_ID is not null
and IBS_CHARGE_TYPE_ID is not null
) ca
on ac.US_TFP_CODE = ca.ABS_TFP_CODE
where ca.rtgr_id = ac.rtgr_id





select to_char(TWSC_SESSION_DATE,'yyyymmddhh24miss'), sc.* From sip_w.tb_wtmps_session_charges sc 
where sc.twsc_session_date between to_date('01.02.2019','dd.mm.yyyy') and to_date('28.02.2019 23:59:59','dd.mm.yyyy hh24:mi:ss')



select '70,,,,,,,'||to_char(TWSC_SESSION_DATE,'yyyymmddhh24miss')||','||TWSC_OUTPUTOCTETS||',,,,,,,07,00,,,,,,,,,,,'||RTGR_ID||',,,,,,,,,0101201808021732260000060XXXC,XXX.XXX.XXX.XXX,,,,'||TWSC_COST||';'||ca.IBS_CHARGE_TYPE_ID||',,,,,,,,,,'
||RTGR_ID||',,,,,,,,1002:5984|1006:905740|1007:833840,600,,,,,'||TWSC_LOGNAME||',,'
from t where twsc_outputoctets != 0



select * from sip_ibs.ibs_abs_serv_codes
select * From sip_ibs.ct_users
where us_ab_id = 1224320 and us_close_date is null



select distinct * from (select (case 
when ABS_SRD_INT_CODE like '%Z99%' then 20
when ABS_SRD_INT_CODE like '%Z0%' then 30
when ABS_SRD_INT_CODE like '%Z99%night%' then 35
end) as RTGR_ID, a.ABS_TFP_CODE, a.IBS_CHARGE_TYPE_ID from sip_ibs.ibs_abs_serv_codes a)
where RTGR_ID is not null
and IBS_CHARGE_TYPE_ID is not null

--������� ������������ � ������
--select t.src_text,f.* from sip_w.tb_input_flows f,SIP_W.STD_PRG_SOURCES t where f.int_clause_src_id=t.src_id order by 2 
