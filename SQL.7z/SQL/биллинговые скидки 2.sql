-----][][][][][ ����� ��������


select b.detg_detg_id, bb.BVDH_ID, bv.bvdt_bvdt_id, cl.clnt_clnt_id from bvd_bvdh_detg b
join BVD_DISCOUNT_TABLE_HISTORIES bb on b.BVDH_BVDH_ID = bb.BVDH_ID
join bvd_clnt_bvdt bv on bv.bvdt_bvdt_id = bb.bvdt_bvdt_id
join client_histories cl on cl.clnt_clnt_id = bv.clnt_clnt_id
where account in (SELECT account FROM UBS_BIL_RECON_BILLDISC t)
and bb.end_date > sysdate
and bv.end_date > sysdate
and cl.end_date > sysdate
and bb.CLOSE_DISCOUNT_DATE > sysdate

-----�������� ����� �� ������� ����������� ������
with table1 as (
SELECT distinct bl.account 
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL))
)
select d.*, cl.account From table1 b
join client_histories cl on cl.account = b.account
join bvd_clnt_bvdt d on cl.clnt_clnt_id = d.clnt_clnt_id
where d.end_date >= to_date('31.07.2020','dd.mm.yyyy')



with table1 as (
SELECT distinct bl.account 
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL))
)
select distinct d.bvdt_bvdt_id, dt.name From table1 b
join client_histories cl on cl.account = b.account
join bvd_clnt_bvdt d on cl.clnt_clnt_id = d.clnt_clnt_id
join bvd_discount_tables dt on dt.bvdt_id = d.bvdt_bvdt_id 
where d.end_date >= to_date('31.07.2020','dd.mm.yyyy')



where d.end_date > sysdate




select * From bvd_discount_tables where bvdt_id in (41,126,55,33,242)




with table1 as (
SELECT distinct bl.account 
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL))
)
select sh.*, sp.pack_pack_id From table1 b
join client_histories cl on cl.account = b.account
join subscribers s on s.clnt_clnt_id = cl.clnt_clnt_id
join subs_histories sh on sh.subs_subs_id = s.subs_id
join subs_packs sp on sp.subs_subs_id = s.subs_id
where 1=1
and sh.rtpl_rtpl_id in (select rtpl_id from rate_plans where name_r like '%����%')
and sh.end_date > sysdate


select * from subs_packs 









/*
select b.detg_detg_id, c.detg_detg_id, bb.BVDH_ID, bv.bvdt_bvdt_id, cl.clnt_clnt_id, c.* from bvd_bvdh_detg b
join BVD_DISCOUNT_TABLE_HISTORIES bb on b.BVDH_BVDH_ID = bb.BVDH_ID
join bvd_clnt_bvdt bv on bv.bvdt_bvdt_id = bb.bvdt_bvdt_id
join client_histories cl on cl.clnt_clnt_id = bv.clnt_clnt_id
join charges c on c.clnt_clnt_id = cl.clnt_clnt_id 
where account in (SELECT account FROM UBS_BIL_RECON_BILLDISC t)
and bb.end_date > sysdate
and bv.end_date > sysdate
and cl.end_date > sysdate
and bb.CLOSE_DISCOUNT_DATE > sysdate
and c.detg_detg_id = b.detg_detg_id
and c.amount_$ > 0*/



select * from bvd_values bv ; ---�����������, ���� ������ ����������������
select * from bvd_clnt_bvdt bcb;-- where clnt_clnt_id in (select clnt_clnt_id from subscribers where subs_id in (48088,48089)); 
select * from bvd_discount_tables bdt where bvdt_id = 55;
select * from bvd_discount_table_histories bdth where bvdh_id = 45 ;-- where bvdt_bvdt_id in (select bvdt_bvdt_id from bvd_clnt_bvdt bcb where clnt_clnt_id in (select clnt_clnt_id from subscribers where subs_id in (48088,48089)));
select * from BVD_DISCOUNT_APPLIED;
select * from BVD_ASSC_BVDT;
select * from bvd_discount_table_values bdtv where bvdh_bvdh_id = 45 
in (select bvdh_id from bvd_discount_table_histories bdth where bvdt_bvdt_id in (select bvdt_bvdt_id from bvd_clnt_bvdt bcb where clnt_clnt_id in (select clnt_clnt_id from subscribers where subs_id in (48088,48089)))); ---��������� ���������� "�� ��"
select * from branches where brnc_id = 1609;
select * from BVD_VALUES_DESCS;
select * from BVD_BVVD_DETG;

select * from bvd_bvdh_detg where bvdh_bvdh_id = 45
and detg_detg_id in (61807,75127,75497,75555)


select * from BVD_DISCOUNT_TABLE_VALUES
select bvtv_seq.nextval from dual
 bdth for update


select g.name_r, bd.* from bill_details bd 
join detail_groups g on detg_id = detg_detg_id
where bill_bill_id = 180302388369001
order by bldt_id desc;

select * from charges where bill_bill_id is not null and bill_bill_id in (180302388369001)--(select bill_bill_id from bill_details)
select * from subscribers where 
clnt_clnt_id = 9663
or subs_id = 7659;
select * from charges where subs_subs_id in (48088,48089)


select distinct g.detg_id from bill_details bd 
join detail_groups g on detg_id = detg_detg_id
where bill_bill_id = 180302388369001





/*
begin
  PACK_BILLING_DISC_PARAMS.calculate_disc_pars(IP_BVDT_ID => 3);
end;


select c.bill_bill_id, c.* from bba_calls_00_012019 c*/

select * From BVD_DISCOUNT_TABLES;
select * From BVD_DISCOUNT_TABLE_HISTORIES;
select * From BVD_BVDH_DETG;



select * from bvd_values bv ;
select * from bvd_clnt_bvdt bcb; 
select * from bvd_values_descs;
select * from bvd_discount_tables bdt where name like '�������%'; ---bvdt_id = 41
select * from bvd_discount_table_histories bdth where bvdt_bvdt_id = 41;
select * from bill_cycle_types; ---��� ����� (�����������; ������������)
--select * from BVD_DISCOUNT_APPLIED;
--select * from BVD_ASSC_BVDT;
select * from bvd_discount_table_values bdtv where bvdh_bvdh_id = 58; 
select * from branches where brnc_id = 1609;
select * from BVD_VALUES_DESCS;
select * from BVD_BVVD_DETG; ---����������� ��� ������� ������� ������������, ���� ������ ������� �� ������ �������������� �����
select * from bvd_bvdh_detg where bvdh_bvdh_id = 21; ---���������� ������ � ������������ ������ �������


select * from bvd_discount_tables bdt where name like '������ 10%  �� ������ ��������';
select * from bvd_discount_table_histories bdth where bvdt_bvdt_id = 34;
select * from bvd_discount_table_values bdtv where bvdh_bvdh_id = 21; 
select * from BVD_VALUES_DESCS;
select * from bvd_bvdh_detg where bvdh_bvdh_id = 21
for update
;


select distinct g.detg_id, d.������������_������--, d.*, g.*
from detail_groups g
join aak_bill d on lower(name_r) like lower(������������_���)
where ������������_������ like '%����� 10%������%'
and detg_id not in (select detg_detg_id from bvd_bvdh_detg where bvdh_bvdh_id = 21)

select * from detail_charges where pack_pack_id = 215
select * from price_list


select * from bvd_clnt_bvdt bcb for update
-----------------------[][][][][]
select * From charges order by navi_date desc

begin
  bis_month_charge.bis_subs_charges(startdate => TRUNC(SYSDATE,'MM'), enddate => last_day(TRUNC(SYSDATE,'MM')),subsid => 219376);
end;

select * from subscribers where subs_id = 219376
select (select name_r from packs where pack_id = pack_pack_id), sp.* From subs_packs sp where subs_subs_id = 219376
select * from adjustments
select * From bills 
where clnt_clnt_id in (select clnt_clnt_id from subscribers where subs_id = 219376)
--where bill_id in (select bill_bill_id From charges where subs_subs_id = 219376)



----������������ ������� �� �������
select * from bill_cycles where navi_user like 'AAK' for update
INSERT INTO BILL_CYCLES(BLCL_ID, CLST_CLST_ID, BCT_BCT_ID, CYCLE_NUM, CYCLE_DATE, NAVI_USER)
VALUES (/*BLCL_seq.nextval*/181231000001290, 1, 2, 1110, trunc(sysdate), 'AAK');
SELECT NVL(MAX(BLCL_ID),0)+1 FROM BILL_CYCLES;
--select BLCL_seq.nextval from dual;
select * from BILL_CYCLE_DETAILS where bcd_id = 1164 for update
INSERT INTO BILL_CYCLE_DETAILS(BCD_ID, BLCL_BLCL_ID, CLNT_CLNT_ID)
VALUES (1164, 181231000001290, 67220);

SELECT NVL(MAX(BCD_ID),0)+1 FROM BILL_CYCLE_DETAILS;

begin
  PACK_BILLING.BILL_SPEC(V_BLCL_ID=> 181231000001290, V_REQUIRED_CALC=>FALSE);
end;


begin 
  bill_posting.start_bill_posting(cycleid=>1164,what=>0,ip_recalc_pay=>1,ip_clnt_id_from => 67220,ip_clnt_id_to => 67220);
end;

select * from adjustments where clnt_clnt_id=67220 order by 1 desc

begin
bis.lite_upd_clients.run_billing(pclnt_id => 67220);
end;

select * From app_parameters where prmt_id in (1109, 10261)
for update

-----����� �������� �� 1 �������
begin
bis.pack_billing.bill_rollback_one_client(v_clnt_id => 67220, v_blcl_id => 181231000001290);
end;

select * from PARTITIONED_TABLES


select * from bill_cycles bc, bill_cycle_details bcd where bcd.blcl_blcl_id=bc.blcl_id and bcd.clnt_clnt_id in (67220)-- and bc.clst_clst_id in (3, 9);
select b.post_blcl_id from bills b where b.clnt_clnt_id in (67220) and b.post_blcl_id is not null
select * from bills b where clnt_clnt_id = 67220
b.post_blcl_id is null


api_part_pg.GET_NEXT_ID('BILL_CYCLES', OPERATION_DATE) 


--- ������ ���
SELECT d.* FROM t_discounts@nsk4al d where name like '%������ �����%';

-- ������� �� ������� ds.svc_id
SELECT ds.discount_id, d.name, dg.name, ds.svc_id, dg.detg_id FROM t_discount_svc_package@nsk4al ds 
join detail_groups@nsk4al dg on dg.svc_id = ds.svc_id
join t_discounts@nsk4al d on d.discount_id = ds.discount_id
WHERE ds.discount_id in (SELECT d.DISCOUNT_ID FROM t_discounts@nsk4al d) 
--and ds.discount_id in (SELECT d.discount_id FROM t_discounts@nsk4al d where name like '%������ �����%')
and (d.date_end is null or d.date_end > sysdate)






select * From t_discounts@nsk4al d

-- ������ ����� ��� �� ����
SELECT dg.detg_id, dg.svc_id, dg.* FROM detail_groups@nsk4al dg;


create table aak_t (name_r varchar2(300))
select * from aak_t for update
select distinct name_r from aak_t

----------------------
with t as (
SELECT distinct dg.* FROM t_discounts@nsk4al dg
join aak_t t on lower(t.name_r) like lower(dg.NAME)
where  (date_end is null or date_end > sysdate)
)
select tt.discount_id, tt.name, w.svc_id, w.detg_id  from t tt
join
(SELECT ds.discount_id, ds.svc_id, dg.detg_id FROM t_discount_svc_package@nsk4al ds 
join detail_groups@nsk4al dg on dg.svc_id = ds.svc_id
WHERE ds.discount_id in (SELECT d.DISCOUNT_ID FROM t_discounts@nsk4al d)
) w
on tt.discount_id = w.discount_id


SELECT d.* FROM t_discounts@nsk4al d
where (date_end is null or date_end > sysdate)
and d.name like '%�� ONT ��� SIP, ��'
---238

---������� �� ������� ds.svc_id
with t as (SELECT distinct (select d.name From t_discounts@nsk4al d where d.discount_id = ds.discount_id) as NAME_R, ds.discount_id, ds.svc_id, dg.detg_id FROM t_discount_svc_package@nsk4al ds 
join detail_groups@nsk4al dg on dg.svc_id = ds.svc_id
WHERE ds.discount_id in (SELECT d.discount_id FROM t_discounts@nsk4al d
where date_end is null or date_end > sysdate)
)
select tt.* from t tt
where name_r in (select ������������_������ from aak_bill)
and not exists (
select 1 from bvd_discount_tables bdt 
join bvd_discount_table_histories bdth on bdth.bvdt_bvdt_id = bdt.bvdt_id
join bvd_discount_table_values bdtv on bdtv.bvdh_bvdh_id = bdth.bvdh_id
join bvd_bvdh_detg bg on bg.bvdh_bvdh_id = bdth.bvdh_id
and bg.detg_detg_id = tt.detg_id
and tt.name_r like bdt.name
)






---5531


declare 
v_var varchar2(300);
begin
  for rec in (with t as (SELECT distinct (select d.name From t_discounts@nsk4al d where d.discount_id = ds.discount_id) as NAME_R, ds.discount_id, ds.svc_id, dg.detg_id FROM t_discount_svc_package@nsk4al ds 
join detail_groups@nsk4al dg on dg.svc_id = ds.svc_id
WHERE ds.discount_id in (SELECT d.discount_id FROM t_discounts@nsk4al d
where date_end is null or date_end > sysdate)
)
select tt.* from t tt
where name_r in (select ������������_������ from aak_bill)) loop

    select distinct bdt.name into v_var from bvd_discount_tables bdt 
join bvd_discount_table_histories bdth on bdth.bvdt_bvdt_id = bdt.bvdt_id
join bvd_discount_table_values bdtv on bdtv.bvdh_bvdh_id = bdth.bvdh_id
join bvd_bvdh_detg bg on bg.bvdh_bvdh_id = bdth.bvdh_id 
where bdt.name like rec.name_r
and bg.detg_detg_id = rec.detg_id;
if v_var is null then
  dbms_output.put_line('1 '||rec.name_r||' '||v_var);
else 
  dbms_output.put_line('2 '||rec.name_r||' '||v_var);
end if;
  end loop;
end;





where name like '������ 10%  �� ������ ��������'


with t as (SELECT distinct (select d.name From t_discounts@nsk4al d where d.discount_id = ds.discount_id) as NAME_R, ds.discount_id, ds.svc_id, dg.detg_id FROM t_discount_svc_package@nsk4al ds 
join detail_groups@nsk4al dg on dg.svc_id = ds.svc_id
WHERE ds.discount_id in (SELECT d.discount_id FROM t_discounts@nsk4al d
where date_end is null or date_end > sysdate)
)
select tt.* from t tt
where name_r in (select ������������_������ from aak_bill)
and name_r like '������ 40%  �� ������ ������� ����������  �����'
and detg_id in (65064,63757,76020)


select * from bvd_discount_tables bdt 
join bvd_discount_table_histories bdth on bdth.bvdt_bvdt_id = bdt.bvdt_id
join bvd_discount_table_values bdtv on bdtv.bvdh_bvdh_id = bdth.bvdh_id
join bvd_bvdh_detg bg on bg.bvdh_bvdh_id = bdth.bvdh_id
where bdt.name like '������ 40%  �� ������ ������� ����������  �����'
and detg_detg_id in (65064,63757,76020)


-- ������ ����� ��� �� ����
SELECT dg.detg_id, dg.svc_id FROM detail_groups@nsk4al dg







select * from bvd_discount_tables bdt 
join bvd_discount_table_histories bdth on bdth.bvdt_bvdt_id = bdt.bvdt_id
join bvd_discount_table_values bdtv on bdtv.bvdh_bvdh_id = bdth.bvdh_id
join bvd_bvdh_detg bg on bg.bvdh_bvdh_id = bdth.bvdh_id
where not exists (
with t as (SELECT distinct (select d.name From t_discounts@nsk4al d where d.discount_id = ds.discount_id) as NAME_R, ds.discount_id, ds.svc_id, dg.detg_id FROM t_discount_svc_package@nsk4al ds 
join detail_groups@nsk4al dg on dg.svc_id = ds.svc_id
WHERE ds.discount_id in (SELECT d.discount_id FROM t_discounts@nsk4al d
where date_end is null or date_end > sysdate)
)
select 1 from t tt
where name_r in (select ������������_������ from aak_bill)
and bg.detg_detg_id = tt.detg_id
and tt.name_r like bdt.name
)


-----���������� ������
select s.clnt_clnt_id,
bd.bvdh_id, 
bb.bvdt_bvdt_id, 
ch.subs_subs_id,
ch.chrg_id,
b.amount_$,
b.amount_$_orig,
'������� ������: '||bv.value_#||' %', 
b.amount_$_orig*bv.value_#/100 as DISCOUNT,
b.amount_$_orig-b.amount_$_orig*bv.value_#/100 as ITOG,
b.bvtv_bvtv_id,
b.* from bill_details b 
join charges ch on ch.bill_bill_id = b.bill_bill_id
join subscribers s on ch.subs_subs_id = subs_id
join bvd_clnt_bvdt bb on bb.clnt_clnt_id = s.clnt_clnt_id
join bvd_discount_table_histories bd on bd.bvdt_bvdt_id = bb.bvdt_bvdt_id
join bvd_bvdh_detg bg on bg.bvdh_bvdh_id = bd.bvdh_id
join bvd_discount_table_values bv on bv.bvdh_bvdh_id = bg.bvdh_bvdh_id
 
where b.bill_bill_id in (select tt.bill_bill_id from charges tt
left join bvd_clnt_bvdt t on t.clnt_clnt_id = tt.clnt_clnt_id
where 1=1
and detg_detg_id in (select detg_detg_id from BVD_BVVD_DETG)
--and t.navi_user like 'PS_MIGR173'
)
and ch.amount_$ = b.amount_$_orig
and b.detg_detg_id = bg.detg_detg_id 
and s.clnt_clnt_id in (SELECT bl.clnt_clnt_id
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL)) )

select * From bvd_clnt_bvdt

select * from client_histories where clnt_clnt_id in (SELECT *
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = &pBatchId 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL)))
        
        
select * from client_histories where clnt_clnt_id in (SELECT (select gf_clnt_id from ps_migr.key_clients where lg_clnt_id = bl.clnt_clnt_id and batch_batch_id = 186)--bl.clnt_clnt_id
    FROM rtk_migr_batch_lists@nsk4al bl
       LEFT JOIN bis.clnt_migration cm on cm.ext_clnt_id = bl.clnt_clnt_id and cm.mist_mist_id in (2,4)
    WHERE bl.batch_batch_id = 2702 
        AND  bl.fin_export_status = 'OK'
        AND  (('ALL'='ALL'/*&pALL*/) OR (cm.clnt_clnt_id IS NULL)))
