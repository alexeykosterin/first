select /*+paralle (t,9)*/ t.table_name, RTRIM(XMLAGG(XMLELEMENT(E,column_name||' '||data_type||'('||data_length||')',',').EXTRACT('//text()') 
  ORDER BY column_name).GetClobVal(),',') as list
from user_tab_columns t 
join user_tables tt on tt.TABLE_NAME like t.TABLE_NAME
where num_rows > 0 and status like 'VALID'
and lower(tt.table_name) not like '%calls_00_%'
and lower(tt.table_name) not like '%tmp%'
and lower(tt.table_name) not like '%aak%'
and lower(tt.table_name) not like 'sys_logs'
and lower(tt.table_name) not like '%call_parts_00_%'
and t.table_name like 'RATE_PLANS'
group by t.table_name


select table_name, LISTAGG(column_name, '^|^|'';''^|^|') WITHIN GROUP (order by column_id) as list from user_tab_columns t where table_name = 'RATE_PLANS' group by table_name;






create table aak_table_name (name_r varchar2(300))
select * from aak_table_name for update


select * from rate_plan_directions 
select * from matrix_dir_histories 

select * from discount_trees







