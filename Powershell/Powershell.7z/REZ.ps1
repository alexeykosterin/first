﻿$path = "X:\Akosterin\Backup\txt"
$pathsql = "X:\Akosterin\Backup\SQL"
$pathwhat = "C:\Users\A.Kosterin\Desktop\*txt"
$pathwhatsql = "C:\Users\A.Kosterin\Desktop\SQL\*"
If(!(test-path $path))
{
New-Item -ItemType Directory -Force -Path $path
}

If(!(test-path $pathsql))
{
New-Item -ItemType Directory -Force -Path $pathsql
}

Copy-Item -Path "$pathwhat" -Destination "$path" -Recurse
Copy-Item -Path "$pathwhatsql" -Destination "$pathsql" -Recurse