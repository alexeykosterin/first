﻿cd "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Notepad++"
.\notepad++.lnk

cd "C:\ProgramData\Microsoft\Windows\Start Menu\Programs"
.\"Google Chrome.lnk"

cd "C:\ProgramData\Microsoft\Windows\Start Menu\Programs"
.\"Outlook 2016.lnk"

cd "C:\Users\A.Kosterin\Desktop\Applications\KeePass-2.39.1"
.\KeePass.exe

cd "C:\Program Files (x86)\PLSQL Developer"
.\plsqldev.exe

cd "C:\Users\A.Kosterin\Desktop\Applications\MobaXterm_Portable_v10.6"
.\"MobaXterm_Personal_10.6.exe"


$path = "X:\Akosterin\Backup\txt"
$pathsql = "X:\Akosterin\Backup\SQL"
$pathwhat = "C:\Users\A.Kosterin\Desktop\*txt"
$pathwhatsql = "C:\Users\A.Kosterin\Desktop\SQL\*"
If(!(test-path $path))
{
New-Item -ItemType Directory -Force -Path $path
}

If(!(test-path $pathsql))
{
New-Item -ItemType Directory -Force -Path $pathsql
}

Copy-Item -Path "$pathwhat" -Destination "$path" -Recurse
Copy-Item -Path "$pathwhatsql" -Destination "$pathsql" -Recurse


cls
$paths= @(
'Applications'
'2017.06.14_Матричные_направления'
'CAMERA'
'CSDB'
'Excel'
'MNP'
'notepad'
'ORACLE'
'PRC'
'Rez'
'SH'
'SPOOL'
'Word'
'Биллинг проведение'
'Биллинговые скидки'
'ЕАСР'
'Конфиги'
'Телефония'
'ВНД (Внутренние нормативные документы)'
)
$date = Get-Date -Format dd_MM_yyyy
$ExcludeFileTypes=@('*.mp4*','*.exe','*.bat')
foreach ($path in $paths) {
$path_count = Get-ChildItem -Path $path | Measure-Object  
    if ($path_count.Count -eq 0) 
       {write-host "нет элементов в папке"}
    else 
       {write-host "копирую файлы из $path"
        $path_copy = ("X:\Akosterin\Backup\Directory\"+$path)
          robocopy $path $path_copy /S /MAXAGE:50 /MT:5 /R:3 /Z /XD dirs /xf $ExcludeFileTypes $path_copy
       }
}